import numpy as np
import pandas as pd

def assert_no_zero_rows_cols(df: pd.DataFrame, name: str):
    if (df.sum(axis=0) == 0).any() or (df.sum(axis=1) == 0).any():
        raise SystemExit(f"{name} has zero-sum rows or columns")
def sector_index_labels(n=15):
    return [f"S{i+1}" for i in range(n)]

def style_axes(ax,
               label_size=12,
               tick_size=10,
               spine_width=1.5,
               tick_width=1.3):
    ax.tick_params(axis="both", labelsize=tick_size, width=tick_width, length=5)
    for lbl in ax.get_xticklabels() + ax.get_yticklabels():
        lbl.set_fontweight("bold")
    for spine in ax.spines.values():
        spine.set_linewidth(spine_width)
    ax.xaxis.label.set_size(label_size)
    ax.yaxis.label.set_size(label_size)
    ax.xaxis.label.set_weight("bold")
    ax.yaxis.label.set_weight("bold")

def assert_sector_shares_ok(shares_df: pd.DataFrame):
    if shares_df.isna().any().any():
        raise SystemExit("Shares contain NaN")
    s = shares_df.sum(axis=0)
    if (s == 0).any():
        raise SystemExit(f"Zero sum share columns: {list(s[s==0].index)}")
    if not np.allclose(s.values, np.ones_like(s.values), atol=1e-6):
        raise SystemExit("Share columns do not sum to 1")

def run(a_national: pd.DataFrame, a_h: pd.DataFrame, z_h: pd.DataFrame, shares_df: pd.DataFrame):
    assert_no_zero_rows_cols(a_national, "A_national")
    assert_no_zero_rows_cols(a_h, "A_H")
    assert_no_zero_rows_cols(z_h, "Z_H")
    assert_sector_shares_ok(shares_df)
    return True

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def _ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

# -----------------------------------------------------------
# 1. MODE SHARE EVOLUTION (stacked area)
# -----------------------------------------------------------
def plot_mode_shares(results, save_dir):
    _ensure_dir(save_dir)

    modes = results["modes"]   # W × 15 (mode codes 0–3)
    W, S = modes.shape

    mode_labels = ["Wait/Water", "Rail", "Truck", "Mixed"]

    shares = pd.DataFrame(index=range(W), columns=mode_labels, dtype=float)
    shares[:] = 0.0

    for m in range(4):
        shares[mode_labels[m]] = (modes == m).sum(axis=1) / S

    fig, ax = plt.subplots(figsize=(12, 6))

    gray_colors = ["#e0e0e0", "#bdbdbd", "#969696", "#636363"]

    ax.stackplot(
        shares.index,
        shares["Wait/Water"],
        shares["Rail"],
        shares["Truck"],
        shares["Mixed"],
        labels=mode_labels,
        colors=gray_colors,
        alpha=1.0,
        linewidth=0.8,
        edgecolor="black"
    )

    # -----------------------------
    # Axis formatting (match heatmaps)
    # -----------------------------
    ax.set_xlabel("Week", fontsize=15, fontweight="bold")
    ax.set_ylabel("Share", fontsize=15, fontweight="bold")

    ax.set_xlim(shares.index.min(), shares.index.max())
    ax.set_ylim(0.0, 1.0)

    ax.tick_params(
        axis="both",
        labelsize=15,
        width=2.0,
        length=6
    )
    # make tick labels bold
    for spine in ax.spines.values():
        spine.set_linewidth(2.0)

    # Remove default margins (kills white space)
    ax.margins(x=0, y=0)

    # -----------------------------
    # Legend: centered at bottom, inside plot
    # -----------------------------
    leg = ax.legend(
        loc="lower center",
        bbox_to_anchor=(0.5, 0.05),
        ncol=4,
        frameon=True,
        fontsize=18
    )

    leg.get_frame().set_facecolor("white")
    leg.get_frame().set_alpha(0.85)
    leg.get_frame().set_linewidth(1.5)

    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, "mode_shares.pdf"))
    plt.close(fig)




# -----------------------------------------------------------
# 2. CONGESTION BUILDUP (port + rail)
# -----------------------------------------------------------
def plot_congestion(results, save_dir):
    _ensure_dir(save_dir)
    cong = results["congestion"]  # W × 2

    fig, ax = plt.subplots(figsize=(10, 6))

    ax.plot(
        cong.index,
        cong["port_load"],
        label="Port Load",
        linewidth=2.0
    )
    ax.plot(
        cong.index,
        cong["rail_load"],
        label="Rail Load",
        linewidth=2.0
    )

    ax.set_title("Weekly Congestion Levels", fontsize=14, fontweight="bold")
    ax.set_xlabel("Week")
    ax.set_ylabel("Load (tons/day)")
    ax.legend()

    style_axes(ax)

    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, "congestion.pdf"), dpi=300)
    plt.close()



# -----------------------------------------------------------
# 3. UTILITY DISTRIBUTIONS (box or violin)
# -----------------------------------------------------------
def plot_utility_distributions(results, save_dir):
    _ensure_dir(save_dir)

    utils = results["utilities"]  # W × 15 (each entry = [u_wait, u_rail, u_truck, u_mixed])
    W = utils.shape[0]

    data = []
    for w in range(W):
        for s, uvec in enumerate(utils.iloc[w]):
            data.append(["Rail", uvec[1]])
            data.append(["Truck", uvec[2]])
            data.append(["Mixed", uvec[3]])

    df = pd.DataFrame(data, columns=["Mode", "Utility"])

    fig, ax = plt.subplots(figsize=(10, 6))

    sns.violinplot(
        data=df,
        x="Mode",
        y="Utility",
        ax=ax,
        inner="quartile",
        cut=0
    )

    ax.set_title("Utility Distributions Across Weeks", fontsize=14, fontweight="bold")
    ax.set_xlabel("Mode")
    ax.set_ylabel("Utility")

    style_axes(ax)

    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, "utility_distributions.pdf"), dpi=300)
    plt.close()



# -----------------------------------------------------------
# 4. COST ACCUMULATION (per sector)
# -----------------------------------------------------------
def plot_cost_accumulation(results, save_dir):
    _ensure_dir(save_dir)

    costs = results["costs"]  # W × 15

    fig, ax = plt.subplots(figsize=(12, 6))

    for i, col in enumerate(costs.columns):
        ax.plot(
            costs.index,
            costs[col],
            linewidth=1.5,
            label=f"S{i+1}"
        )

    ax.set_title("Weekly Sector Losses", fontsize=14, fontweight="bold")
    ax.set_xlabel("Week")
    ax.set_ylabel("Weekly Loss (USD)")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left")

    style_axes(ax)

    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, "cost_accumulation.pdf"), dpi=300)
    plt.close()



# -----------------------------------------------------------
# 5. FINAL MRIIM SHOCK BAR PLOT (15 sectors)
# -----------------------------------------------------------
def plot_abm_shock_bar(results, save_dir):
    _ensure_dir(save_dir)

    shock = results["shock"]
    sns.barplot(
        x=sector_index_labels(len(shock)),
        y=shock
    )

    plt.title("Final Sectoral Cost Shock (ABM → MRIIM)")
    plt.xlabel("Sector Index")
    plt.ylabel("Shock Magnitude (USD)")
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, "abm_shock_bar.pdf"), dpi=300)
    plt.close()


# -----------------------------------------------------------
# 6. HEATMAP OF MODE CHOICES (time × sector)
# -----------------------------------------------------------
def plot_mode_heatmap(results, save_dir):
    _ensure_dir(save_dir)

    modes = results["modes"]   # W × 15, values in {0,1,2,3}
    M = modes.T + 1            # convert to {1,2,3,4} for display

    from matplotlib.colors import ListedColormap, BoundaryNorm

    # Discrete colormap: exactly 4 categories
    cmap = ListedColormap([
    "#f0f0f0",  # Wait
    "#bdbdbd",  # Rail
    "#737373",  # Truck
    "#252525",  # Mixed
])

    bounds = [0.5, 1.5, 2.5, 3.5, 4.5]
    norm = BoundaryNorm(bounds, cmap.N)

    fig, ax = plt.subplots(figsize=(10, 8))

    im = ax.imshow(
        M.values,
        aspect="auto",
        cmap=cmap,
        norm=norm,
        interpolation="nearest"
    )

    # -----------------------------
    # Colorbar (DISCRETE, meaningful)
    # -----------------------------
    cbar = plt.colorbar(
        im,
        ax=ax,
        ticks=[1, 2, 3, 4],
        fraction=0.046,
        pad=0.04
    )

    cbar.set_label(
        "Mode Choice",
        fontsize=13,
        fontweight="bold",
        labelpad=12
    )

    cbar.ax.tick_params(
        labelsize=13,
        width=2.0,
        length=6
    )

    for spine in cbar.ax.spines.values():
        spine.set_linewidth(2.0)

    # -----------------------------
    # Axes ticks & labels
    # -----------------------------
    # -----------------------------
    # X-axis: weeks 1–52, label every 3 weeks
    # -----------------------------
    n_weeks = M.shape[1]

    tick_pos = np.arange(0, n_weeks, 3)
    tick_lbl = tick_pos + 1  # convert 0-based → 1-based weeks

    ax.set_xticks(tick_pos)

    ax.set_xticklabels(tick_lbl, fontsize=13)
    ax.set_yticks(range(len(M.index)))
    ax.set_yticklabels(range(1, len(M.index) + 1), fontsize=13)


    ax.set_xlabel("Week", fontsize=13, fontweight="bold")
    ax.set_ylabel("Sector #", fontsize=13, fontweight="bold")

    # -----------------------------
    # Gridlines to separate cells
    # -----------------------------
    ax.set_xticks(np.arange(-0.5, M.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, M.shape[0], 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=0.8)
    ax.tick_params(which="minor", bottom=False, left=False)

    # -----------------------------
    # Thicker frame
    # -----------------------------
    for spine in ax.spines.values():
        spine.set_linewidth(2.0)

    fig.tight_layout()
    fig.savefig(os.path.join(save_dir, "mode_heatmap.pdf"),
            dpi=600,
            bbox_inches="tight")
    plt.close(fig)




# -----------------------------------------------------------
# 7. ROUTE DIVERSITY INDEX (Shannon entropy)
# -----------------------------------------------------------
def plot_route_diversity(results, save_dir):
    _ensure_dir(save_dir)

    modes = results["modes"]   # W × 15
    W = modes.shape[0]

    diversity = []
    for w in range(W):
        vals, counts = np.unique(modes.iloc[w], return_counts=True)
        p = counts / counts.sum()
        H = -(p * np.log(p)).sum()
        diversity.append(H)

    plt.figure(figsize=(10,6))
    plt.plot(range(W), diversity, marker="o")
    plt.title("Route Diversity (Shannon Entropy)")
    plt.xlabel("Week")
    plt.ylabel("Entropy")
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, "route_diversity.pdf"), dpi=300)
    plt.close()
