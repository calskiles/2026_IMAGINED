from pathlib import Path
# Default diagnostic outputs are relative to the repository.
# diagnostics_all.py
# Full-stack diagnostics for the MRIIM + freight ABM + RL + climate pipeline.
# Works standalone (reads Excel outputs) or attached to a running main() via globals().

import os, json, math, warnings
warnings.filterwarnings("ignore")
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Tuple, Optional, Union

import numpy as np
import pandas as pd

# ---------------------------- Helpers ----------------------------

def _nn(x) -> bool:
    return x is not None

def _nz(x) -> bool:
    try:
        return float(x) != 0.0
    except Exception:
        return False

def _repr_list(xs, k=8):
    xs = list(xs)
    return xs[:k] + (["…"] if len(xs) > k else [])

def _safe_xl(path) -> Optional[pd.ExcelFile]:
    try:
        return pd.ExcelFile(path)
    except Exception as e:
        return None

def _try_parse(xl: pd.ExcelFile, sheet: str, usecols=None, nrows=None):
    try:
        kw = {}
        if usecols is not None: kw["usecols"] = usecols
        if nrows   is not None: kw["nrows"] = nrows
        return xl.parse(sheet, **kw)
    except Exception:
        try:
            return xl.parse(sheet)  # full fallback
        except Exception as e:
            return f"ERROR: {e}"

def _dfnum(df: pd.DataFrame) -> pd.DataFrame:
    return df.select_dtypes(include=[np.number]) if isinstance(df, pd.DataFrame) else pd.DataFrame()

def _frac(v: int, n: int) -> float:
    return (v / n) if n else 0.0

def _summ_stats(df: pd.DataFrame) -> Dict[str, Any]:
    if not isinstance(df, pd.DataFrame):
        return {"error": str(df)}
    num = _dfnum(df)
    zeros = int((num == 0).sum().sum()) if not num.empty else 0
    negs  = int((num < 0).sum().sum()) if not num.empty else 0
    return {
        "rows": int(df.shape[0]),
        "cols": int(df.shape[1]),
        "numeric_cols": int(num.shape[1]),
        "NaNs": int(df.isna().sum().sum()),
        "zeros": zeros,
        "negatives": negs,
        "heavy_zeros": (zeros / max(1, df.shape[0]*max(1,num.shape[1]))) > 0.5 if not num.empty else False,
    }

def _ensure_dir(d: str):
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)

# --------------------------- Data Pack ---------------------------

@dataclass
class LiveObjects:
    UM: Optional[Dict[str, Any]] = None              # build_national_A() dict
    REG: Optional[Dict[str, Any]] = None             # build_regional_IO() dict
    SCTG2_TO_SECTOR: Optional[Dict[str, str]] = None
    faf: Optional[pd.DataFrame] = None
    state_sector_shares: Optional[pd.DataFrame] = None
    sector_usd_per_ton: Optional[Union[Dict[str,float], pd.Series]] = None
    OD22: Optional[Any] = None
    port_agents: Optional[pd.DataFrame] = None
    RL_returns: Optional[pd.Series] = None
    by_state_base: Optional[pd.DataFrame] = None
    by_state_res: Optional[pd.DataFrame] = None
    by_sector_base: Optional[pd.DataFrame] = None

@dataclass
class Paths:
    core_path: str
    res_path: str
    fig_dir: str

# ------------------------- Core Diagnostics -------------------------

def diag_use_make_io(UM: Optional[Dict[str,Any]], core_xl: Optional[pd.ExcelFile]) -> Dict[str, Any]:
    out = {"section": "Use/Make/IO"}
    # Live
    if UM:
        for k in ("use_matrix","make_matrix","A_national","total_output"):
            out[f"live_has_{k}"] = k in UM and isinstance(UM[k], (pd.DataFrame, pd.Series, np.ndarray))
        # Shape & content checks
        for name in ("use_matrix","make_matrix","A_national"):
            if name in UM and isinstance(UM[name], pd.DataFrame):
                df = UM[name]
                stats = _summ_stats(df)
                stats["row_sums_zero_frac"] = float((np.nansum(df.values, axis=1) == 0).mean())
                stats["col_sums_zero_frac"] = float((np.nansum(df.values, axis=0) == 0).mean())
                out[f"live_stats_{name}"] = stats
    # From workbook
    if core_xl:
        for sheet in ("Use_15_from42","Make_15_from42","A_H_matrix","Z_H_matrix","Leontief_Inverse","Output_Multipliers"):
            df = _try_parse(core_xl, sheet)
            out[f"file_stats_{sheet}"] = _summ_stats(df)
            if isinstance(df, pd.DataFrame):
                num = _dfnum(df)
                if not num.empty and sheet.lower().startswith("leontief"):
                    out["leontief_negative_frac"] = float((num.values < 0).mean())
    return out

def diag_mapping(SCTG2_TO_SECTOR: Optional[Dict[str,str]], sector_names: Optional[List[str]]) -> Dict[str, Any]:
    out = {"section": "SCTG→Sector Mapping"}
    if not SCTG2_TO_SECTOR:
        out["error"] = "mapping_missing"
        return out
    keys = list(SCTG2_TO_SECTOR.keys())
    vals = list(SCTG2_TO_SECTOR.values())
    out["num_keys"] = len(keys)
    out["example_keys"] = _repr_list(sorted(keys))
    out["unique_targets"] = len(set(vals))
    if sector_names:
        diff = sorted(set(vals) - set(sector_names))
        out["targets_not_in_sector_names"] = diff
    # coverage for 01..43
    missing = []
    for i in range(1,44):
        k = str(i).zfill(2)
        if k not in SCTG2_TO_SECTOR:
            missing.append(k)
    out["missing_SCTG2_codes"] = missing
    return out

def diag_faf(faf: Optional[pd.DataFrame]) -> Dict[str, Any]:
    out = {"section": "FAF"}
    if faf is None or not isinstance(faf, pd.DataFrame) or faf.empty:
        out["error"] = "faf_missing_or_empty"
        return out
    out.update(_summ_stats(faf))
    # try infer mode columns
    cols = set(map(str.lower, map(str, faf.columns)))
    mode_candidates = {c for c in faf.columns if str(c).lower() in {"truck","rail","barge","water","ocean","air"}}
    out["modes_found"] = list(map(str, mode_candidates))
    sums = {}
    for c in mode_candidates:
        try: sums[str(c)] = float(pd.to_numeric(faf[c], errors="coerce").fillna(0).sum())
        except Exception: pass
    out["mode_sums"] = sums
    sector_col = next((c for c in faf.columns if str(c).lower() in {"sector","industry","agg_sector","sctg_sector"}), None)
    out["sector_col"] = str(sector_col) if sector_col else None
    return out

def diag_state_sector_shares(shares: Optional[pd.DataFrame], sector_names: Optional[List[str]]) -> Dict[str, Any]:
    out = {"section": "State×Sector Shares"}
    if shares is None or not isinstance(shares, pd.DataFrame) or shares.empty:
        out["error"] = "shares_missing_or_empty"
        return out
    out.update(_summ_stats(shares))
    per_col_sum = {}
    zero_cols = []
    for col in shares.columns:
        s = float(pd.to_numeric(shares[col], errors="coerce").fillna(0).sum())
        per_col_sum[str(col)] = s
        if s <= 0: zero_cols.append(str(col))
    out["col_sums"] = per_col_sum
    out["zero_sum_columns"] = zero_cols
    if sector_names:
        out["missing_sector_columns"] = [s for s in sector_names if s not in shares.columns]
    return out

def diag_usd_per_ton(usd: Optional[Union[Dict[str,float], pd.Series]]) -> Dict[str, Any]:
    out = {"section": "$ per ton by sector"}
    if usd is None:
        out["error"] = "usd_per_ton_missing"
        return out
    if isinstance(usd, dict):
        s = pd.Series(usd, dtype=float)
    else:
        s = pd.to_numeric(pd.Series(usd), errors="coerce")
        if s.index.dtype != object: s.index = s.index.astype(str)
    out["n"] = int(s.size)
    out["num_nonzero"] = int((s.fillna(0) > 0).sum())
    out["num_zero_or_nan"] = int((s.fillna(0) <= 0).sum())
    out["zeros_or_nan_labels"] = _repr_list(list(s[(s.fillna(0) <= 0)].index))
    out["median_value"] = float(np.nanmedian(s.values)) if s.size else None
    return out

def diag_od22(OD22: Any) -> Dict[str, Any]:
    out = {"section": "OD22"}
    if OD22 is None:
        out["error"] = "od22_missing"
        return out
    # best-effort type introspection
    if isinstance(OD22, pd.DataFrame):
        out["type"] = "DataFrame"
        out.update(_summ_stats(OD22))
        # try infer origin/dest columns
        cols = [c for c in OD22.columns if str(c).lower() in {"origin","orig","o","source","from"}]
        cold = [c for c in OD22.columns if str(c).lower() in {"dest","destination","d","to","target"}]
        out["origin_col_guess"] = cols[:1]
        out["dest_col_guess"] = cold[:1]
    elif isinstance(OD22, dict):
        out["type"] = "dict"
        out["keys"] = _repr_list(list(OD22.keys()))
    else:
        out["type"] = str(type(OD22))
    return out

def diag_port_agents(port_agents: Optional[pd.DataFrame]) -> Dict[str, Any]:
    out = {"section": "Port Agents"}
    if port_agents is None or not isinstance(port_agents, pd.DataFrame) or port_agents.empty:
        out["error"] = "port_agents_missing_or_empty"
        return out
    out.update(_summ_stats(port_agents))
    needed = {"Sector","Mode","DailyValue_M"}
    out["has_columns"] = {c: (c in port_agents.columns) for c in needed}
    if needed.issubset(port_agents.columns):
        dv = pd.to_numeric(port_agents["DailyValue_M"], errors="coerce").fillna(0)
        out["nonzero_rows"] = int((dv > 0).sum())
        by_mode = (port_agents.assign(DailyValue_M=dv)
                   .groupby("Mode")["DailyValue_M"].sum().sort_values(ascending=False))
        by_sector = (port_agents.assign(DailyValue_M=dv)
                     .groupby("Sector")["DailyValue_M"].sum().sort_values(ascending=False))
        out["mode_totals_M"] = {str(k): float(v) for k, v in by_mode.items()}
        out["sector_totals_M"] = {str(k): float(v) for k, v in by_sector.items()}
        # Missing critical modes?
        crit = {"truck","rail","barge","water","ocean"}
        out["critical_modes_present"] = sorted(list(crit.intersection({str(x).lower() for x in port_agents["Mode"].unique()})))
    return out

def diag_resilience_workbook(res_xl: Optional[pd.ExcelFile], fig_dir: str) -> Dict[str, Any]:
    out = {"section": "Resilience_Results.xlsx"}
    if res_xl is None:
        out["error"] = "workbook_unreadable"
        return out

    # RL
    rl = _try_parse(res_xl, "RL_LearningCurve")
    if isinstance(rl, pd.DataFrame) and "EpisodeReturn" in rl.columns:
        r = pd.to_numeric(rl["EpisodeReturn"], errors="coerce").dropna()
        out["RL_n"] = int(r.size)
        out["RL_frac_nonpos"] = float((r <= 0).mean())
        out["RL_median"] = float(np.median(r.values)) if r.size else None

    # Dynamic MRIIM
    dm = _try_parse(res_xl, "DynamicMRIIM_CA")
    if isinstance(dm, pd.DataFrame) and "DeltaOutput_M_per_day" in dm.columns:
        y = pd.to_numeric(dm["DeltaOutput_M_per_day"], errors="coerce").dropna()
        out["DynMRIIM_frac_neg"] = float((y < 0).mean())
        out["DynMRIIM_median_abs"] = float(np.median(np.abs(y))) if y.size else None

    # Port Agents
    pa = _try_parse(res_xl, "Port_Agents")
    out["Port_Agents_stats"] = _summ_stats(pa)
    if isinstance(pa, pd.DataFrame) and {"Sector","Mode","DailyValue_M"}.issubset(pa.columns):
        dv = pd.to_numeric(pa["DailyValue_M"], errors="coerce").fillna(0)
        out["Port_Agents_nonzero_rows"] = int((dv > 0).sum())

    # Zeros/flags sheets if present
    for s in ("Zero_AgentDailyValue","Zero_AgentDailyValue_Flags","Zero_StateSectorShares"):
        df = _try_parse(res_xl, s)
        out[f"{s}_stats"] = _summ_stats(df)

    # Climate by state (base/resil)
    neg_csvs = []
    def _climate_block(name: str):
        df = _try_parse(res_xl, name)
        out[f"{name}_stats"] = _summ_stats(df)
        if isinstance(df, pd.DataFrame) and {"SSP","RP","State","Loss_M"}.issubset(df.columns):
            D = df.copy()
            D["Loss_M"] = pd.to_numeric(D["Loss_M"], errors="coerce")
            agg = []
            for (ssp, rp), g in D.groupby(["SSP","RP"]):
                n = int(g["Loss_M"].notna().sum())
                neg = int((g["Loss_M"] < 0).sum())
                med = float(np.nanmedian(g["Loss_M"].values)) if n else np.nan
                agg.append({"SSP": ssp, "RP": int(rp), "n": n, "neg": neg, "pct_neg": 100.0*_frac(neg, n), "median": med})
            agg_df = pd.DataFrame(agg).sort_values(["SSP","RP"])
            p = os.path.join(fig_dir, f"neg_stats_{name}.csv")
            agg_df.to_csv(p, index=False)
            neg_csvs.append(p)
            # national per-scenario sum (SSP585 only)
            D = D[D["SSP"]=="SSP585"]
            if "scenario" in D.columns and not D.empty:
                nat = D.groupby(["RP","scenario"])["Loss_M"].sum().reset_index()
                out[f"{name}_national_median_by_RP"] = {int(rp): float(np.median(nat.loc[nat["RP"]==rp, "Loss_M"].values))
                                                       for rp in sorted(nat["RP"].unique())}
        return df

    base_state = _climate_block("Climate_ByState_Base")
    res_state  = _climate_block("Climate_ByState_Resil")
    base_sect  = _try_parse(res_xl, "Climate_BySector_Base")
    out["neg_csvs_written"] = neg_csvs

    # Savings sanity if both present
    if isinstance(base_state, pd.DataFrame) and isinstance(res_state, pd.DataFrame):
        need = {"SSP","RP","State","Loss_M","scenario"}
        if need.issubset(base_state.columns) and need.issubset(res_state.columns):
            B = base_state.copy(); R = res_state.copy()
            for d in (B, R):
                d["Loss_M"] = pd.to_numeric(d["Loss_M"], errors="coerce")
                d["scenario"] = pd.to_numeric(d["scenario"], errors="coerce")
            M = B.merge(R, on=["SSP","RP","State","scenario"], suffixes=("_base","_res")).dropna(subset=["Loss_M_base","Loss_M_res"])
            if not M.empty:
                M["Savings"] = (M["Loss_M_base"].clip(lower=0) - M["Loss_M_res"].clip(lower=0))
                out["Savings_median_by_RP_SSP585"] = {
                    int(rp): float(np.median(M.loc[(M["SSP"]=="SSP585") & (M["RP"]==rp), "Savings"].values))
                    for rp in sorted(M["RP"].unique())
                }

    return out

def diag_core_workbook(core_xl: Optional[pd.ExcelFile]) -> Dict[str, Any]:
    out = {"section": "ZH one step.xlsx"}
    if core_xl is None:
        out["error"] = "workbook_unreadable"
        return out
    for sheet in ("A_H_matrix","Z_H_matrix","Leontief_Inverse","Output_Multipliers","Use_15_from42","Make_15_from42","ModalShares_byState_Sector"):
        df = _try_parse(core_xl, sheet)
        out[f"{sheet}_stats"] = _summ_stats(df)
    return out

# ------------------------- Root Runner -------------------------

def run_all_diagnostics(CFG: Dict[str, Any], live_globals: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Run diagnostics across inputs, live objects (if provided), and Excel outputs.
    Writes diagnostics_report.json/txt and CSVs into CFG["fig_dir"].
    Returns the full diagnostics dict.
    """
    # Paths
    core_path = CFG.get("core_output_path") or CFG.get("core_path") or CFG.get("CORE_PATH") or str(Path(__file__).resolve().parent / "outputs" / "ZH one step.xlsx")
    res_path  = CFG.get("resilience_output_path") or CFG.get("res_path") or CFG.get("RES_PATH") or str(Path(__file__).resolve().parent / "outputs" / "Resilience_Results.xlsx")
    fig_dir   = CFG.get("fig_dir") or CFG.get("FIG_DIR") or str(Path(__file__).resolve().parent / "outputs" / "Resilience_Figures")
    _ensure_dir(fig_dir)

    # Excel workbooks
    core_xl = _safe_xl(core_path)
    res_xl  = _safe_xl(res_path)

    # Live objects (optional)
    L = LiveObjects()
    if live_globals:
        # best-effort grab
        L.UM = live_globals.get("UM")
        L.REG = live_globals.get("REG")
        L.SCTG2_TO_SECTOR = live_globals.get("SCTG2_TO_SECTOR")
        L.faf = live_globals.get("faf")
        L.state_sector_shares = live_globals.get("state_sector_shares")
        L.sector_usd_per_ton = live_globals.get("sector_usd_per_ton")
        L.OD22 = live_globals.get("OD22")
        L.port_agents = live_globals.get("port_agents")
        returns = live_globals.get("returns")
        if isinstance(returns, (list, np.ndarray, pd.Series)):
            L.RL_returns = pd.Series(returns)
        L.by_state_base = live_globals.get("by_state_base")
        L.by_state_res  = live_globals.get("by_state_res")
        L.by_sector_base = live_globals.get("by_sector_base")
        sector_names = live_globals.get("sector_names")
    else:
        sector_names = None

    # ---- Run diagnostics ----
    report: Dict[str, Any] = {"paths": asdict(Paths(core_path, res_path, fig_dir))}

    # Use/Make/IO
    report["use_make_io"] = diag_use_make_io(L.UM, core_xl)

    # Mapping
    report["mapping"] = diag_mapping(L.SCTG2_TO_SECTOR, sector_names)

    # FAF
    report["faf"] = diag_faf(L.faf)

    # State-sector shares
    report["state_sector_shares"] = diag_state_sector_shares(L.state_sector_shares, sector_names)

    # $ per ton
    report["usd_per_ton"] = diag_usd_per_ton(L.sector_usd_per_ton)

    # OD22
    report["od22"] = diag_od22(L.OD22)

    # Port agents
    report["port_agents"] = diag_port_agents(L.port_agents)

    # Resilience workbook & climate
    report["resilience_workbook"] = diag_resilience_workbook(res_xl, fig_dir)

    # Core workbook snapshot
    report["core_workbook"] = diag_core_workbook(core_xl)

    # ---- High-level findings & actions ----
    findings = []
    actions  = []

    # 1) Shares columns with zero sum
    zero_cols = report.get("state_sector_shares", {}).get("zero_sum_columns", [])
    if zero_cols:
        findings.append(f"{len(zero_cols)} sector columns in state_sector_shares sum to 0: {zero_cols[:8]}{' …' if len(zero_cols)>8 else ''}")
        actions.append("Normalize each sector column; if sum==0, replace with uniform 1/N across states before climate runs.")

    # 2) Port agents with zero value
    pa_stats = report.get("port_agents", {})
    if pa_stats.get("error") == "port_agents_missing_or_empty" or pa_stats.get("nonzero_rows", 1) == 0:
        findings.append("Port_Agents DailyValue_M is all zeros or missing.")
        actions.append("Check port name filter (e.g., 'Los Angeles' vs 'Port of Los Angeles'), include 'water/ocean' mode, "
                       "and fill missing $/ton by sector with median before computing value.")

    # 3) $/ton issues
    usd_bad = report.get("usd_per_ton", {}).get("num_zero_or_nan", 0)
    if usd_bad:
        findings.append(f"{usd_bad} sectors have $/ton <=0 or NaN.")
        actions.append("Impute $/ton for those sectors with sector median (or external default), otherwise flows convert to $0.")

    # 4) FAF mode coverage
    modes_found = set(map(str.lower, report.get("faf", {}).get("modes_found", [])))
    if modes_found and not {"water","ocean"}.intersection(modes_found):
        findings.append("FAF parsed without a 'water/ocean' mode column.")
        actions.append("Ensure FAF has water/ocean tonnage or that your build_port_agents maps maritime flows; "
                       "otherwise POLA value collapses to near-zero.")

    # 5) Climate negatives
    cw = report.get("resilience_workbook", {})
    for tag in ("Climate_ByState_Base_stats","Climate_ByState_Resil_stats"):
        st = cw.get(tag, {})
        if st.get("negatives", 0) > 0:
            findings.append(f"{tag.replace('_stats','')} contains negative Loss_M entries.")
            actions.append("Clip negatives at 0 for headline plots; investigate sign convention in abm_sector_losses if unexpected.")

    # 6) Leontief negatives
    Lneg = report.get("use_make_io", {}).get("leontief_negative_frac", None)
    if _nn(Lneg) and Lneg > 0.0:
        findings.append(f"Leontief_Inverse has {Lneg:.3%} negative entries (may be okay but worth verifying).")
        actions.append("Confirm regionalization and balancing steps; minor negatives can arise from numerical tolerances.")

    # 7) RL curve all nonpositive
    if cw.get("RL_n", 0) > 0 and cw.get("RL_frac_nonpos", 0) >= 0.95:
        findings.append("RL learning curve returns are ~all ≤ 0 (loss-style reward).")
        actions.append("This is expected if reward = −loss. Check magnitude not trivially ~0; if tiny, revisit Port_Agents/$/ton inputs.")

    report["high_level_findings"] = findings
    report["recommended_actions"] = actions

    # ---- Write artifacts ----
    json_path = os.path.join(fig_dir, "diagnostics_report.json")
    txt_path  = os.path.join(fig_dir, "diagnostics_report.txt")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("# MRIIM Diagnostics Report\n\n")
        f.write("## Paths\n")
        for k, v in report["paths"].items():
            f.write(f"- {k}: {v}\n")
        f.write("\n## Key Findings\n")
        if findings:
            for i, msg in enumerate(findings, 1):
                f.write(f"{i}. {msg}\n")
        else:
            f.write("No major red flags detected.\n")
        f.write("\n## Recommended Actions\n")
        if actions:
            for i, msg in enumerate(actions, 1):
                f.write(f"{i}. {msg}\n")
        else:
            f.write("None.\n")
        f.write("\n## Section Summaries (abbrev.)\n")
        for sec in ("use_make_io","mapping","faf","state_sector_shares","usd_per_ton","od22","port_agents"):
            f.write(f"\n### {sec}\n")
            f.write(json.dumps(report.get(sec, {}), indent=2))
            f.write("\n")
        f.write("\n### resilience_workbook\n")
        f.write(json.dumps({k:v for k,v in report.get("resilience_workbook", {}).items()
                            if (isinstance(v, (int,float,str)) or k.endswith("_stats"))}, indent=2))
        f.write("\n\n### core_workbook\n")
        f.write(json.dumps(report.get("core_workbook", {}), indent=2))
        f.write("\n")

    print(f"✅ Diagnostics complete.\n  JSON: {json_path}\n  TXT:  {txt_path}")
    return report

# -------------------------- Standalone --------------------------

if __name__ == "__main__":
    # Minimal fallback paths (override by editing below or by calling from main)
    CFG = {
        "core_output_path": str(Path(__file__).resolve().parent / "outputs" / "ZH one step.xlsx"),
        "resilience_output_path": str(Path(__file__).resolve().parent / "outputs" / "Resilience_Results.xlsx"),
        "fig_dir": str(Path(__file__).resolve().parent / "outputs" / "Resilience_Figures"),
    }
    run_all_diagnostics(CFG)
