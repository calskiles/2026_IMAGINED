from pathlib import Path
# Data files are resolved relative to this module, not a personal desktop.
# freight_abm.py
import numpy as np
import pandas as pd
from scipy.stats import gamma
from tqdm import tqdm
import matplotlib.pyplot as plt
import os
import itertools
import matplotlib
matplotlib.use("Agg")
from matplotlib.colors import LogNorm, Normalize, SymLogNorm

from mriim import initialize_mriim
from mriim import run_mriim_simple
from mriim import (
    map_sctg2_to_sector15,
    sector_names,
    MAP_TO_15
)
from matplotlib.colors import ListedColormap

def _truncated_gray_cmap(n=256, lo=0.12, hi=0.82):
    """
    Grayscale without pure black or pure white.
    lo, hi are positions in matplotlib's 'gray' colormap.
    Higher lo avoids very dark black; lower hi avoids empty-looking white.
    """
    base = plt.cm.gray
    colors = base(np.linspace(lo, hi, n))
    return ListedColormap(colors)
# ---------------------------------------------------------------------------
# MODULE-LEVEL CAPACITY CONSTANTS
# Defined here (not inside run_abm) so that every module-level function —
# including run_rl_paired_comparison() and compute_novelty_metrics() —
# can reference them directly without any dir() tricks or fallback literals.
# To change the port or rail ceiling, edit exactly this one place.
# ---------------------------------------------------------------------------
PORT_CAP = 60_000.0   # tons / week — port throughput ceiling
RAIL_CAP = 90_000.0   # tons / week — rail diversion ceiling
# ---------------------------------------------------------------------------
# Central ABM parameter bundle
# This is the single source of truth for sensitivity, calibration, and
# reproducibility. Anything that may be assumed or calibrated should live here.
# ---------------------------------------------------------------------------
DEFAULT_ABM_PARAMS = {
    # infrastructure
    "port_cap": PORT_CAP,                  # tons/week
    "rail_cap": RAIL_CAP,                  # tons/week
    "truck_cap_sw": 120_000.0,             # tons/week, switching scenario only
    "polb_cap_mult": 1.10,                 # POLB_CAP = port_cap * polb_cap_mult

    # congestion / queue
    "queue_alpha": 0.15,
    "queue_beta": 3.0,
    "queue_max_weeks": 4.0,
    "exp_max_arg": 6.0,

    # behavior / utility
    "alpha_min": 0.05,
    "alpha_max": 0.15,
    "beta_min": 0.20,
    "beta_max": 0.80,
    "belief_shape0": 2.0,
    "belief_scale0": 3.0,
    "belief_lambda_min": 0.2,
    "belief_lambda_max": 0.8,
    "belief_eta_min": 0.5,
    "belief_eta_max": 1.5,
    "belief_nu_min": 0.8,
    "belief_nu_max": 1.2,

    # inventory loss
    "inventory_partial_mult": 3.0,
    "inventory_post_buffer_mult": 2.0,

    # RL diagnostics / surrogate
    "rl_actions": {
        "delta_r_1": {"rail_cost_mult": 0.92, "truck_avail_cap": 0.85},
        "delta_r_2": {"rail_cost_mult": 0.85, "truck_avail_cap": 0.70},
        "delta_b_1": {"barge_cost_mult": 0.93, "truck_avail_cap": 0.88},
        "delta_b_2": {"barge_cost_mult": 0.86, "truck_avail_cap": 0.75},
        "phi_truck": {"truck_cost_mult": 0.94},
        "phi_rail": {"rail_cost_mult": 0.91},
        "phi_barge": {"barge_cost_mult": 0.90},
        "reset": {},
    },

    # reproducibility
    "seed": 42,
}
# RL severity bins — shared by run_rl_paired_comparison() and
# compute_novelty_metrics() so bin definitions are never duplicated.
_RL_SEVERITY_BINS = [
    ("low",      0.00, 0.25),
    ("moderate", 0.25, 0.50),
    ("high",     0.50, 1.00),
]

def _merge_abm_params(overrides=None):
    p = dict(DEFAULT_ABM_PARAMS)
    if overrides:
        for k, v in overrides.items():
            if isinstance(v, dict) and isinstance(p.get(k), dict):
                q = dict(p[k])
                q.update(v)
                p[k] = q
            else:
                p[k] = v
    return p
# ---------------------------------------------------------------------------
# FAF / geography helpers
# ---------------------------------------------------------------------------

def faf_dms_to_state(dms):
    dms = int(dms)
    return {
        1: "AL",  2: "AK",  4: "AZ",  5: "AR",  6: "CA",  8: "CO",  9: "CT",
        10: "DE", 12: "FL", 13: "GA", 15: "HI", 16: "ID", 17: "IL", 18: "IN",
        19: "IA", 20: "KS", 21: "KY", 22: "LA", 23: "ME", 24: "MD", 25: "MA",
        26: "MI", 27: "MN", 28: "MS", 29: "MO", 30: "MT", 31: "NE", 32: "NV",
        33: "NH", 34: "NJ", 35: "NM", 36: "NY", 37: "NC", 38: "ND", 39: "OH",
        40: "OK", 41: "OR", 42: "PA", 44: "RI", 45: "SC", 46: "SD", 47: "TN",
        48: "TX", 49: "UT", 50: "VT", 51: "VA", 53: "WA", 54: "WV",
        55: "WI", 56: "WY",
    }.get(dms, None)


PATH_FAF = str(Path(__file__).resolve().parent / "data" / "FAF5.7.csv")
PATH_POLA_DIST = str(Path(__file__).resolve().parent / "data" / "POLA_Distances.csv")

POLA_CODE = "061"

QUEUE_ALPHA  = 0.15
QUEUE_BETA   = 3.0
CARBON_PRICE = 50.0

FUEL_DEFAULT = {"truck": "diesel", "rail": "diesel", "barge": "diesel"}

SPEED_TRUCK = 55.0
SPEED_RAIL  = 35.0
SPEED_BARGE =  7.5

COST_TKM = {
    "truck": {"diesel": 0.082953, "biodiesel": 0.083202, "electric": 0.076553, "hydrogen": 0.081400},
    "rail":  {"diesel": 0.007891, "biodiesel": 0.007829, "electric": 0.005779, "hydrogen": 0.002361},
    "barge": {"diesel": 0.001883, "biodiesel": 0.001845, "electric": 0.000621, "hydrogen": 0.000920},
}

EF_TKM = {
    "truck": {"diesel": 40.402, "biodiesel": 35.263, "electric": 13.490, "hydrogen": 17.231},
    "rail":  {"diesel": 16.000, "biodiesel": 13.981, "electric":  4.132, "hydrogen":  5.860},
    "barge": {"diesel":  6.767, "biodiesel":  5.915, "electric":  2.044, "hydrogen":  2.485},
}

STATES = [
    "AL", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "ID", "IL", "IN",
    "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT",
    "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA",
    "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY",
]

RAIL_MAX_SHIFT  = 0.25
TRUCK_MAX_SHIFT = 0.40
BARGE_MAX_SHIFT = 0.15


# ---------------------------------------------------------------------------
# Low-level utilities
# ---------------------------------------------------------------------------

def _to_num(s):
    if s is None:
        return np.nan
    if isinstance(s, (int, float, np.integer, np.floating)):
        return float(s)
    x = str(s).strip().replace(",", "")
    if x == "" or x.lower() in ("nan", "none"):
        return np.nan
    try:
        return float(x)
    except Exception:
        return np.nan


def _pick_first_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def _savefig(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    plt.tight_layout()
    plt.savefig(path, dpi=200)
    plt.close()


def _fmt_musd(x):
    x  = float(x)
    ax = abs(x)
    if ax >= 1000: return f"{x:,.0f}"
    if ax >= 10:   return f"{x:,.1f}"
    if ax >= 1:    return f"{x:,.2f}"
    if ax >= 0.01: return f"{x:,.3f}"
    return f"{x:.3e}"


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------

def load_pola_distances(path):
    df = pd.read_csv(path)
    df["faf_code"] = pd.to_numeric(df["faf_code"], errors="coerce")
    df = df.dropna(subset=["faf_code"])
    df["faf_code"] = df["faf_code"].astype(int)
    for c in ["truck_d", "rail_d", "water_d"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.set_index("faf_code")


def _ensure_sector(df):
    if "sector" in df.columns:
        return df
    col = "sctg2" if "sctg2" in df.columns else ("SCTG2" if "SCTG2" in df.columns else None)
    if col is None:
        raise KeyError("FAF file has no sector or SCTG2 column")
    df["sctg2"]  = df[col].astype(str).str.zfill(2)
    df["sector"] = df["sctg2"].apply(map_sctg2_to_sector15)
    return df


def _infer_tons_value_cols(df):
    tons_col = _pick_first_col(df, ["tons_day", "tons_2024", "tons_2023", "tons_2022", "tons_2017", "tons"])
    val_col  = _pick_first_col(df, ["value_day", "value_2024", "value_2023", "value_2022", "value_2017", "value"])
    return tons_col, val_col


def load_faf_pola_bidirectional(path, pola_code=POLA_CODE):
    df = pd.read_csv(path, dtype=str, low_memory=False)
    df["dms_orig"] = df["dms_orig"].astype(str).str.strip()
    df["dms_dest"] = df["dms_dest"].astype(str).str.strip()
    df = _ensure_sector(df)
    tons_col, val_col = _infer_tons_value_cols(df)
    if tons_col is None or val_col is None:
        raise KeyError(
            f"Could not infer tons/value columns. "
            f"Found tons_col={tons_col}, val_col={val_col}"
        )
    df["tons_raw"]  = df[tons_col].map(_to_num).fillna(0.0)
    df["value_raw"] = df[val_col].map(_to_num).fillna(0.0)
    mask = (df["dms_orig"] == str(pola_code)) | (df["dms_dest"] == str(pola_code))
    df   = df[mask].copy()
    df["direction"] = np.where(df["dms_orig"] == str(pola_code), "outbound", "inbound")
    df["tons_day"]  = df["tons_raw"]  if "tons_day"  in tons_col else df["tons_raw"]  / 365.0
    df["value_day"] = df["value_raw"] if "value_day" in val_col  else df["value_raw"] / 365.0
    return df


def load_gdp_state_sector_15(path, year=2023):
    df = pd.read_excel(path, sheet_name="Aggregated")
    df.columns        = df.columns.astype(str).str.strip()
    df["GeoName"]     = df["GeoName"].astype(str).str.strip()
    df["Description"] = df["Description"].astype(str).str.strip()
    if str(year) not in df.columns:
        raise ValueError(f"Year {year} not found in GDP table")
    df["sector15"] = df["Description"].map(MAP_TO_15)
    df = df.dropna(subset=["sector15"])
    gdp = (
        df.pivot_table(index="GeoName", columns="sector15", values=str(year), aggfunc="sum")
        .fillna(0.0)
    )
    state_map = {
        "Alabama": "AL", "Arizona": "AZ", "Arkansas": "AR", "California": "CA",
        "Colorado": "CO", "Connecticut": "CT", "Delaware": "DE", "Florida": "FL",
        "Georgia": "GA", "Idaho": "ID", "Illinois": "IL", "Indiana": "IN",
        "Iowa": "IA", "Kansas": "KS", "Kentucky": "KY", "Louisiana": "LA",
        "Maine": "ME", "Maryland": "MD", "Massachusetts": "MA", "Michigan": "MI",
        "Minnesota": "MN", "Mississippi": "MS", "Missouri": "MO", "Montana": "MT",
        "Nebraska": "NE", "Nevada": "NV", "New Hampshire": "NH", "New Jersey": "NJ",
        "New Mexico": "NM", "New York": "NY", "North Carolina": "NC",
        "North Dakota": "ND", "Ohio": "OH", "Oklahoma": "OK", "Oregon": "OR",
        "Pennsylvania": "PA", "Rhode Island": "RI", "South Carolina": "SC",
        "South Dakota": "SD", "Tennessee": "TN", "Texas": "TX", "Utah": "UT",
        "Vermont": "VT", "Virginia": "VA", "Washington": "WA",
        "West Virginia": "WV", "Wisconsin": "WI", "Wyoming": "WY",
    }
    gdp.index = gdp.index.map(state_map)
    gdp = gdp.reindex(index=STATES, columns=sector_names).fillna(0.0)
    if (gdp.sum(axis=0) == 0).any():
        raise ValueError("GDP table has zero-sum sector columns")
    return gdp


# ---------------------------------------------------------------------------
# Transport physics
# ---------------------------------------------------------------------------

def queue_delay(load, cap, *, queue_alpha=0.15, queue_beta=3.0,
                max_weeks=4.0, exp_max_arg=6.0):
    cap = max(float(cap), 1e-9)
    x = float(load) / cap
    if x <= 1.0:
        return 0.0
    exp_arg = queue_beta * (x - 1.0)
    exp_arg = min(exp_arg, exp_max_arg)
    d = queue_alpha * np.expm1(exp_arg)
    return float(min(d, max_weeks))


def exp_congestion(base, load, cap):
    if load <= cap:
        return base
    return base * np.exp(load / cap - 1)


def generalized_cost(tons_week, distance, mode, fuel, value_time_week):
    cost_tm           = COST_TKM[mode][fuel]
    ef_tm             = EF_TKM[mode][fuel]
    transport_cost    = tons_week * distance * cost_tm
    emissions_cost    = tons_week * distance * ef_tm / 1000.0 * CARBON_PRICE
    speed             = {"truck": SPEED_TRUCK, "rail": SPEED_RAIL, "barge": SPEED_BARGE}[mode]
    time_cost         = value_time_week * (distance / speed / 168.0)
    return transport_cost + emissions_cost + time_cost


def generate_closure_timeseries_weeks(n_weeks=52, shape=2.5, scale=6.0, max_blockage=20):
    return np.clip(gamma(a=shape, scale=scale).rvs(n_weeks), 0.0, max_blockage)


def closure_series(use_existing=True):
    if use_existing:
        return generate_closure_timeseries_weeks()
    return np.maximum(0, gamma(a=2.0, scale=3.0).rvs(14))


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------

class SectorAgent:
    def __init__(self, name, tons_day, value_day, alpha, beta, vot, inv, params=None):
        P = _merge_abm_params(params)
        self.name = name
        self.tons_day = tons_day
        self.value_day = value_day
        self.locked_mode = None
        self.alpha = alpha
        self.beta = beta
        self.vot = vot
        self.inv = inv

        self.belief_shape = P["belief_shape0"]
        self.belief_scale = P["belief_scale0"]
        self.lambda_persist = np.random.uniform(P["belief_lambda_min"], P["belief_lambda_max"])
        self.eta_update = np.random.uniform(P["belief_eta_min"], P["belief_eta_max"])
        self.nu_vol = np.random.uniform(P["belief_nu_min"], P["belief_nu_max"])

        self.delay_cost = 0.0
        self.unserved_cost = 0.0
        self.mode_history = []
        self.utility_history = []
        self.hysteresis = 0.0

    def expected_duration(self):
        return self.belief_shape * self.belief_scale

    def update_belief(self, observed_days):
        post_shape = ((1 - self.lambda_persist) * self.belief_shape
                      + self.lambda_persist * (self.belief_shape + self.eta_update))
        post_scale = ((1 - self.lambda_persist) * self.belief_scale
                      + self.lambda_persist * ((self.belief_scale + observed_days) / 2))
        self.belief_shape = post_shape
        self.belief_scale = post_scale * self.nu_vol

    def inventory_loss(self, weeks_blocked):
        if weeks_blocked <= self.inv:
            return 0.0
        return (weeks_blocked - self.inv) * self.value_day * 7

    def utility(self, wait_weeks, rail_cost, truck_cost, mixed_cost):
        wait_cost = (self.vot * wait_weeks * 7 * self.value_day
                     + self.alpha * wait_weeks
                     + self.hysteresis * self.value_day)
        return wait_cost, -rail_cost + self.beta, -truck_cost, -mixed_cost + 0.5 * self.beta

    def choose_mode(self, wait_cost, rail_u, truck_u, mixed_u):
        u = np.array([-wait_cost, rail_u, truck_u, mixed_u], dtype=float)
        z = u + np.random.gumbel(size=4)
        z -= np.nanmax(z)
        p  = np.exp(z)
        s  = np.nansum(p)
        p  = p / s if (np.isfinite(s) and s > 0) else np.ones(4) / 4.0
        return int(np.argmax(p)), u.tolist()


# ---------------------------------------------------------------------------
# MRIIM bridge
# ---------------------------------------------------------------------------

def run_mriim_with_external_shock(state_sector_matrix, gdp_state_sector_df):
    """Convert dollar losses → inoperability fractions, then call MRIIM."""
    base_output = gdp_state_sector_df.loc[
        state_sector_matrix.index, state_sector_matrix.columns
    ]
    c_frac = (state_sector_matrix / base_output).fillna(0.0).clip(0.0, 1.0)
    return run_mriim_simple(c_frac.values.flatten(order="C"))


# ---------------------------------------------------------------------------
# Plotting helpers
# ---------------------------------------------------------------------------

def plot_bar(values, labels, title, xlabel, out_path, top_n=5):
    s = pd.Series(values, index=labels).sort_values(ascending=False).head(top_n)
    plt.figure(figsize=(10, max(4, 0.35 * len(s) + 1)))
    ax = s.sort_values().plot(kind="barh")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    for i, (k, v) in enumerate(s.sort_values().items()):
        ax.text(v, i, f"  {_fmt_musd(v)}", va="center", fontsize=9)
    _savefig(out_path)


def plot_heatmap(mat_df, title, out_path):
    M      = mat_df.values.astype(float)
    M_plot = M / np.maximum(M.max(axis=0, keepdims=True), 1e-9)
    plt.figure(figsize=(14, 10))
    im = plt.imshow(M_plot, aspect="auto", vmin=0, vmax=1, cmap="viridis")
    plt.title(title + " (within-sector normalized)")
    plt.xlabel("Sector")
    plt.ylabel("State")
    plt.yticks(np.arange(len(mat_df.index)), mat_df.index)
    plt.xticks(np.arange(len(mat_df.columns)), np.arange(1, len(mat_df.columns) + 1))
    plt.colorbar(im).set_label("relative loss within sector")
    _savefig(out_path)


# ---------------------------------------------------------------------------
# Main ABM
# ---------------------------------------------------------------------------

def run_abm(include_inbound=True, abm_params=None, **kwargs):
    print("\n===================== RUNNING ENHANCED ABM =====================")
    P = _merge_abm_params(abm_params)
    np.random.seed(int(P.get("seed", 42)))
    LOSS_MULT = float(kwargs.get("loss_mult", 1.0))
    gdp_df = load_gdp_state_sector_15(
        str(Path(__file__).resolve().parent / "data" / "GDP by State by Industry.xlsx")
    )

    initialize_mriim(
        faf_path   = PATH_FAF,
        use42_path = str(Path(__file__).resolve().parent / "data" / "Use Sector Before.xlsx"),
        make42_path= str(Path(__file__).resolve().parent / "data" / "Make Sector Before.xlsx"),
        sheet42    = "Table",
        gdp_df     = gdp_df,
        state_list = STATES,
    )

    pola_dist = load_pola_distances(PATH_POLA_DIST)
    faf_raw   = load_faf_pola_bidirectional(PATH_FAF, pola_code=POLA_CODE)
    if not include_inbound:
        faf_raw = faf_raw[faf_raw["direction"] == "outbound"].copy()

    faf_raw["dms_orig_i"] = pd.to_numeric(faf_raw["dms_orig"], errors="coerce").fillna(-1).astype(int)
    faf_raw["dms_dest_i"] = pd.to_numeric(faf_raw["dms_dest"], errors="coerce").fillna(-1).astype(int)
    faf_raw["dist_key"]   = faf_raw.apply(
        lambda r: r["dms_dest_i"] if r["direction"] == "outbound" else r["dms_orig_i"], axis=1
    )
    faf_raw = faf_raw.merge(pola_dist, left_on="dist_key", right_index=True, how="left")

    g       = (faf_raw.groupby("sector")
               .agg({"tons_day": "sum", "value_day": "sum"})
               .reindex(sector_names).fillna(0.0))
    sectors = list(g.index)
    tons    = g["tons_day"].values.astype(float)
    vals    = g["value_day"].values.astype(float)

    print(f"POLA bidirectional={include_inbound}  "
          f"sectors_nonzero={(g['tons_day'] > 0).sum()}/15")
    print(f"Total POLA tons/day:  {tons.sum():,.6f}")
    print(f"Total POLA value/day: {vals.sum():,.6f}")

    sector_dist = {}
    for s in sectors:
        sub = faf_raw[faf_raw["sector"] == s]
        w   = sub["tons_day"].values.astype(float)
        sector_dist[s] = (
            {"truck": float(np.average(sub["truck_d"], weights=w)),
             "rail":  float(np.average(sub["rail_d"],  weights=w)),
             "barge": float(np.average(sub["water_d"], weights=w))}
            if w.sum() > 0 else {"truck": 0.0, "rail": 0.0, "barge": 0.0}
        )

    alpha = np.linspace(P["alpha_min"], P["alpha_max"], len(sectors))
    beta = np.linspace(P["beta_min"], P["beta_max"], len(sectors))
    vot    = 0.02 * vals / np.maximum(tons, 1.0)
    inv    = np.clip(
        0.5 + 3.0 * (vals / np.max(vals) if np.max(vals) > 0 else 0.0), 1.0, 6.0
    )
    agents = [
        SectorAgent(sectors[i], tons[i], vals[i], alpha[i], beta[i], vot[i], inv[i], params=P)
        for i in range(len(sectors))
    ]

    # Reference module-level constants — guarantees run_abm() and
    # run_rl_paired_comparison() always use the same capacity values.
    port_cap = float(P["port_cap"])
    rail_cap = float(P["rail_cap"])

    # Treat gamma draws as "days" and convert to weeks so blocked stays O(0–3) weeks.
    cs = closure_series(True) 
    W  = len(cs)
    print("Total weeks of simulation:", W)

    diag_modes, diag_utils, diag_cong, diag_costs = [], [], [], []
    diag_port_delay_weeks = []
    diag_rail_delay_weeks = []
    diag_port_utilization = []
    diag_rail_utilization = []
    port_load_prev = 0.0
    rail_load_prev = 0.0
    port_load_hist = []
    rail_load_hist = []

    for w in tqdm(range(W), desc="Simulating weeks"):
        blocked        = float(cs[w])
        cap_shock      = 1.0 - 0.15 * np.tanh(blocked / 3.0)
        load_port      = np.random.uniform(0.45, 0.75) * port_load_prev
        load_rail      = np.random.uniform(0.50, 0.80) * rail_load_prev
        weekly_losses  = np.zeros(len(agents))

        for i, a in enumerate(agents):
            a.update_belief(blocked)
            a.hysteresis  = 0.9 * a.hysteresis + 0.1 * blocked
            stress        = blocked / (a.inv + 1)
            a.alpha      *= (1 + 0.02 * stress)
            a.beta       *= (1 - 0.01 * stress)

            tons_week = 7.0 * a.tons_day
            d = sector_dist[a.name]

            c_truck = generalized_cost(tons_week, d["truck"], "truck",
                                       FUEL_DEFAULT["truck"], a.value_day * 7)
            c_rail  = generalized_cost(tons_week, d["rail"],  "rail",
                                       FUEL_DEFAULT["rail"],  a.value_day * 7)
            c_barge = generalized_cost(tons_week, d["barge"], "barge",
                                       FUEL_DEFAULT["barge"], a.value_day * 7)

            eff_port_cap = cap_shock * port_cap * max(0.05, 1.0 - blocked / 6.0)
            eff_rail_cap = cap_shock * rail_cap * max(0.20, 1.0 - 0.5 * blocked / 6.0)

            c_rail  = exp_congestion(c_rail,  load_rail, eff_rail_cap)
            c_barge = exp_congestion(c_barge, load_port, eff_port_cap)
            c_mixed = exp_congestion(c_rail + c_barge,
                                     load_rail + load_port,
                                     rail_cap + port_cap)

            rail_delay = queue_delay(
                load_rail, rail_cap,
                queue_alpha=P["queue_alpha"],
                queue_beta=P["queue_beta"],
                max_weeks=P["queue_max_weeks"],
                exp_max_arg=P["exp_max_arg"],
            )
            port_delay = queue_delay(
                load_port, max(eff_port_cap, 1.0),
                queue_alpha=P["queue_alpha"],
                queue_beta=P["queue_beta"],
                max_weeks=P["queue_max_weeks"],
                exp_max_arg=P["exp_max_arg"],
            )
            wait_weeks = max(blocked, rail_delay + port_delay)
            cong_pen   = 0.5 * (rail_delay + port_delay) * a.value_day * 7.0

            wait_cost, rail_u, truck_u, mixed_u = a.utility(
                wait_weeks, c_rail, c_truck, c_mixed
            )
            mode, utils = a.choose_mode(wait_cost, rail_u, truck_u, mixed_u)
            a.mode_history.append(mode)
            a.utility_history.append(utils)

            inventory_ratio  = min(wait_weeks / a.inv, 1.0)
            partial_loss = inventory_ratio * P["inventory_partial_mult"] * a.value_day * 7.0
            if wait_weeks <= a.inv:
                lost_output_week = partial_loss
            else:
                lost_output_week = (
                    partial_loss
                    + P["inventory_post_buffer_mult"] * (wait_weeks - a.inv) * a.value_day * 7.0
                )
            weekly_losses[i] = LOSS_MULT * (lost_output_week + cong_pen)

            if mode == 1:
                load_rail += tons_week * np.random.uniform(0.85, 1.15)
            elif mode == 2:
                load_port += 0.15 * tons_week * np.random.uniform(0.8, 1.3)
            elif mode == 3:
                split      = np.clip(
                    0.4 + 0.2 * np.sin(2 * np.pi * w / 4)
                    + np.random.normal(0, 0.1), 0.2, 0.7
                )
                load_port += split * tons_week
                load_rail += (1 - split) * tons_week

        weekly_port_delay = queue_delay(
            load_port, max(port_cap, 1.0),
            queue_alpha=P["queue_alpha"],
            queue_beta=P["queue_beta"],
            max_weeks=P["queue_max_weeks"],
            exp_max_arg=P["exp_max_arg"],
        )
        weekly_rail_delay = queue_delay(
            load_rail, max(rail_cap, 1.0),
            queue_alpha=P["queue_alpha"],
            queue_beta=P["queue_beta"],
            max_weeks=P["queue_max_weeks"],
            exp_max_arg=P["exp_max_arg"],
        )

        diag_port_delay_weeks.append(float(weekly_port_delay))
        diag_rail_delay_weeks.append(float(weekly_rail_delay))
        diag_port_utilization.append(float(load_port / max(port_cap, 1.0)))
        diag_rail_utilization.append(float(load_rail / max(rail_cap, 1.0)))

        port_load_hist.append(load_port)
        rail_load_hist.append(load_rail)
        port_load_prev = load_port
        rail_load_prev = load_rail

        diag_modes.append([a.mode_history[-1] for a in agents])
        diag_utils.append([a.utility_history[-1] for a in agents])
        diag_cong.append([load_port, load_rail])
        diag_costs.append(weekly_losses.copy())

    df_modes = pd.DataFrame(diag_modes, columns=sectors)
    df_utils = pd.DataFrame(diag_utils, columns=sectors)
    df_cong  = pd.DataFrame({
        "port_load": diag_cong and [x[0] for x in diag_cong] or [],
        "rail_load": diag_cong and [x[1] for x in diag_cong] or [],
        "port_delay_weeks": diag_port_delay_weeks,
        "rail_delay_weeks": diag_rail_delay_weeks,
        "port_utilization": diag_port_utilization,
        "rail_utilization": diag_rail_utilization,
    })
    df_costs = pd.DataFrame(diag_costs, columns=sectors)
    baseline_mean_weekly_loss_musd = float(df_costs.sum(axis=1).mean() / 1e6)
    print("[ABM] weeks simulated:", len(df_modes))
    print("[ABM] mean weekly loss ($):", df_costs.sum(axis=1).mean())
    print("[ABM] max port load:", df_cong["port_load"].max())
    print("[ABM] max rail load:", df_cong["rail_load"].max())

    # ---- sector losses ----
    sector_loss = pd.Series(
        df_costs.sum(axis=0).values / 1e6,
        index=sectors,
        name="ABM_sector_loss_musd",
    ).sort_values(ascending=False)

    # Cross-sector production coupling (GDP-weighted leakage)
    baseline_gdp = gdp_df.sum(axis=0); baseline_gdp /= baseline_gdp.sum()
    sector_loss  = (1 - 0.12) * sector_loss + 0.12 * sector_loss.sum() * baseline_gdp
    total_loss   = sector_loss.sum()
    # Idempotent leakage re-normalisation (preserves total)
    sector_loss  = (1 - 0.08) * sector_loss + 0.08 * total_loss * (sector_loss / sector_loss.sum())

    # ---- geographic distribution ----
    faf_raw["dest_state"] = faf_raw["dms_dest_i"].apply(
        lambda x: faf_dms_to_state(x) if x > 0 else None
    )
    faf_raw["orig_state"] = faf_raw["dms_orig_i"].apply(
        lambda x: faf_dms_to_state(x) if x > 0 else None
    )

    out_df = faf_raw[faf_raw["direction"] == "outbound"]
    in_df  = faf_raw[faf_raw["direction"] == "inbound"]

    exposure_out = (out_df.groupby(["dest_state", "sector"])["value_day"]
                    .sum().unstack(fill_value=0)
                    .reindex(index=STATES, columns=sectors).fillna(0.0))
    exposure_in  = (in_df.groupby(["orig_state",  "sector"])["value_day"]
                    .sum().unstack(fill_value=0)
                    .reindex(index=STATES, columns=sectors).fillna(0.0))
    exposure     = exposure_out.add(exposure_in, fill_value=0.0)

    # Blend GDP weights with POLA exposure (exposure floor prevents flat sectors)
    weights_gdp = gdp_df.div(gdp_df.sum(axis=0).replace(0, np.nan), axis=1).fillna(0.0)
    weights_faf = (exposure.div(exposure.sum(axis=0).replace(0, np.nan), axis=1).fillna(0.0)
                   + 0.02)
    weights_faf = weights_faf.div(weights_faf.sum(axis=0).replace(0, np.nan), axis=1).fillna(0.0)

    weights = 1.6 * weights_gdp + weights_faf
    weights = weights.div(weights.sum(axis=0).replace(0, np.nan), axis=1).fillna(0.0)
    weights = weights.reindex(columns=sector_loss.index, fill_value=0.0)
    matrix  = weights.mul(sector_loss.values, axis=1)

    assert (matrix.sum(axis=0) - sector_loss).abs().max() < 1e-9, "Matrix–sector mismatch!"

    # ---- diagnostics ----
    print("\n================ ABM → STATE SHOCK DIAGNOSTICS ================")
    print("Sector loss (M$):\n", sector_loss)
    print("\nMatrix sum by sector:\n", matrix.sum(axis=0))
    diff = matrix.sum(axis=0) - sector_loss
    print("\nDifference (matrix − sector loss):\n", diff)
    print("\nRelative error:\n", diff / sector_loss.replace(0, np.nan))
    print(f"\nTotal sector loss: {sector_loss.sum():.3f} M$  |  "
          f"Total matrix loss: {matrix.values.sum():.3f} M$")
    print("Nonzero sector losses:", (sector_loss > 0).sum(), "/ 15")
    print("Nonzero matrix cells:", (matrix.values > 0).sum())
    print("\nTop states:")
    print(matrix.sum(axis=1)[matrix.sum(axis=1) > 0]
          .sort_values(ascending=False).head(15))
    print("================ END DIAGNOSTICS ================================\n")

    if (matrix.sum(axis=1) == 0).all():
        raise ValueError(
            "No state received ABM shock.\n"
            f"Total sector loss (M$): {sector_loss.sum():.6f}\n"
            f"Nonzero exposure cells: {(exposure.values > 0).sum()}\n"
            f"Nonzero sector losses:  {(sector_loss > 0).sum()}\n"
            "Likely cause: value-based loss with ton-based exposure."
        )

    state_loss            = matrix.sum(axis=1).rename("ABM_state_loss_musd").sort_values(ascending=False)
    mriim_out             = run_mriim_with_external_shock(matrix, gdp_df)
    mriim_df              = mriim_out.reset_index()
    mriim_df.columns      = ["state", "sector", "loss"]
    mriim_matrix          = (mriim_df.pivot(index="state", columns="sector", values="loss")
                              .reindex(index=STATES, columns=sectors).fillna(0.0))
    mriim_state_loss      = mriim_matrix.sum(axis=1).rename("MRIIM_state_loss_musd")

    # ------------------------------------------------------------------
    # OPTIONAL: POLB switching scenario + Figures 9–11 + Table 3
    # ------------------------------------------------------------------
    polb_switching_results = None
    polb_table3 = None
    polb_sweep_df = None

    if kwargs.get("run_polb_switching", False):
        polb_out_dir = kwargs.get("polb_out_dir", None)
        if polb_out_dir is None:
            polb_out_dir = os.path.join(os.path.expanduser("~"), "Desktop", "POLA Results", "polb_switching")
        os.makedirs(polb_out_dir, exist_ok=True)

        polb_seed  = int(kwargs.get("polb_seed", 0))
        polb_weeks = int(kwargs.get("polb_n_weeks", len(df_costs)))

        # match ABM shock process by default
        blocked_series = kwargs.get("polb_blocked_series", None)
        if blocked_series is None:
            blocked_series = cs[:polb_weeks]
        blocked_const = float(kwargs.get("polb_blocked_const_weeks", 2.0))

        # --- NEW: sweep mode (driven by your main file kwargs)
        polb_severity_list = kwargs.get("polb_severity_list", None)
        polb_seeds = kwargs.get("polb_seeds", None)

        if polb_severity_list is not None:
            # normalize user inputs
            polb_severity_list = [float(x) for x in list(polb_severity_list)]
            if polb_seeds is None:
                polb_seeds = [polb_seed]
            polb_seeds = [int(x) for x in list(polb_seeds)]

            polb_sweep_df = run_polb_switching_sweep(
                faf_raw=faf_raw,
                pola_dist_df=pola_dist,
                gdp_df=gdp_df,
                sectors=sectors,
                tons=tons,
                vals=vals,
                sector_dist_pola=sector_dist,
                blocked_series=blocked_series,
                out_dir=polb_out_dir,
                severities=tuple(polb_severity_list),
                seeds=tuple(polb_seeds),
                n_weeks=polb_weeks,
                blocked_const_weeks=blocked_const,
                diff_mode=str(kwargs.get("polb_diff_mode", "symlog")),
                pct_clip=float(kwargs.get("polb_pct_clip", 0.50)),
                **kwargs,
            )

            # (optional) keep these None in sweep mode; results are in folders + sweep df
            polb_switching_results = None
            polb_table3 = None

        else:
            # --- single-run mode (your original behavior)
            polb_red = float(kwargs.get("polb_severity", POLB_TRIGGER_SEVERITY))

            baseline_no_polb = run_port_switching_scenario(
                faf_raw=faf_raw,
                pola_dist_df=pola_dist,
                gdp_df=gdp_df,
                sectors=sectors,
                tons=tons,
                vals=vals,
                sector_dist_pola=sector_dist,
                n_weeks=polb_weeks,
                pola_capacity_reduction=polb_red,
                blocked_series=blocked_series,
                blocked_const_weeks=blocked_const,
                enable_polb=False,
                seed=polb_seed,
                **kwargs,
            )

            polb_switching_results = run_port_switching_scenario(
                faf_raw=faf_raw,
                pola_dist_df=pola_dist,
                gdp_df=gdp_df,
                sectors=sectors,
                tons=tons,
                vals=vals,
                sector_dist_pola=sector_dist,
                n_weeks=polb_weeks,
                pola_capacity_reduction=polb_red,
                blocked_series=blocked_series,
                blocked_const_weeks=blocked_const,
                enable_polb=True,
                seed=polb_seed,
                **kwargs,
            )

            baseline_results = {
                "costs": baseline_no_polb["costs_sw"],
                "mriim_matrix": baseline_no_polb["mriim_matrix_sw"],
                "abm_sector_loss": baseline_no_polb["sector_loss_sw"],
            }

            polb_table3 = compare_port_switching(
                baseline_results=baseline_results,
                switching_results=polb_switching_results,
                out_dir=polb_out_dir,
            )
    return {
        # ABM dynamics (expected by audit_viz_v2)
        "modes":      df_modes,
        "utilities":  df_utils,
        "congestion": df_cong,
        "costs":      df_costs,
        # Loss outputs
        "abm_sector_loss": sector_loss,
        "abm_state_loss":  state_loss,
        "abm_matrix":      matrix,
         # POLB switching outputs (optional)
        "polb_switching": polb_switching_results,
        "polb_table3": polb_table3,
        "polb_sweep_df": polb_sweep_df,
        # MRIIM
        "mriim_matrix":     mriim_matrix,
        "mriim_state_loss": mriim_state_loss,
        # Shock vector for viz
        "shock": mriim_matrix.sum(axis=0).values,
        "meta": {
            "include_inbound": include_inbound,
            "tons_day_total":  float(tons.sum()),
            "value_day_total": float(vals.sum()),
        },
        # Scalar baseline consumed by run_rl_paired_comparison() — §5.5
        "rl_baseline_loss_musd": float(sector_loss.sum()),
        "rl_baseline_mean_weekly_loss_musd": baseline_mean_weekly_loss_musd,  # NEW

    }

def _build_rl_state_space():
    """
    Discretized state space for interpretable policy maps.
    State dimensions:
      1) severity bin
      2) rail utilization bin
      3) port utilization bin
      4) inventory stress bin
    """
    severity_bins = ["low", "moderate", "high"]
    util_bins = ["low", "med", "high"]
    inv_bins = ["low", "high"]

    states = []
    for sev in severity_bins:
        for rail_u in util_bins:
            for port_u in util_bins:
                for inv_s in inv_bins:
                    states.append((sev, rail_u, port_u, inv_s))
    return states

def _rl_actions():
    return list(DEFAULT_ABM_PARAMS["rl_actions"].keys())

def _pretty_rl_action_labels():
    return {
        "delta_r_1": "Truck-to-rail shift (level 1)",
        "delta_r_2": "Truck-to-rail shift (level 2)",
        "delta_b_1": "Truck-to-barge shift (level 1)",
        "delta_b_2": "Truck-to-barge shift (level 2)",
        "phi_truck": "Truck fuel switch",
        "phi_rail": "Rail fuel switch",
        "phi_barge": "Barge fuel switch",
        "reset": "Reset to baseline",
    }

def _simulate_rl_environment_step(state, action, base_loss_musd, rng):
    """
    One-step stylized environment used for policy learning diagnostics.
    The paper is written in cost/loss-minimization form, so the realized
    annualized loss is returned explicitly, while the internal RL update
    still uses reward = -loss.
    """
    sev, rail_u, port_u, inv_s = state
    params = DEFAULT_ABM_PARAMS["rl_actions"][action]

    sev_mult = {"low": 0.25, "moderate": 0.50, "high": 0.85}[sev]
    rail_mult = {"low": 0.9, "med": 1.0, "high": 1.2}[rail_u]
    port_mult = {"low": 0.9, "med": 1.0, "high": 1.25}[port_u]
    inv_mult = {"low": 0.95, "high": 1.15}[inv_s]

    loss = base_loss_musd * sev_mult * rail_mult * port_mult * inv_mult

    rc = params.get("rail_cost_mult", 1.0)
    bc = params.get("barge_cost_mult", 1.0)
    tc = params.get("truck_cost_mult", 1.0)
    truck_cap = params.get("truck_avail_cap", 1.0)

    # action benefit and saturation penalty
    loss = loss * rc * bc * tc
    sat_penalty = max(0.0, 1.0 / max(truck_cap, 1e-9) - 1.0)
    if rail_u == "high":
        loss *= (1.0 + 0.15 * sat_penalty)
    if port_u == "high" and action in {"phi_truck", "phi_rail", "phi_barge", "reset"}:
        loss *= 1.05

    # stochastic transition
    next_sev = sev
    if sev == "low" and rng.uniform() < 0.15:
        next_sev = "moderate"
    elif sev == "moderate":
        u = rng.uniform()
        if u < 0.10:
            next_sev = "low"
        elif u > 0.80:
            next_sev = "high"
    elif sev == "high" and rng.uniform() < 0.15:
        next_sev = "moderate"

    def step_util(u):
        x = {"low": 0, "med": 1, "high": 2}[u]
        x = int(np.clip(x + rng.choice([-1, 0, 1], p=[0.2, 0.6, 0.2]), 0, 2))
        return ["low", "med", "high"][x]

    next_state = (
        next_sev,
        step_util(rail_u),
        step_util(port_u),
        inv_s if rng.uniform() < 0.8 else ("high" if inv_s == "low" else "low"),
    )

    loss = float(loss)
    reward = -loss
    return next_state, reward, loss

def learn_rl_policy(
    base_loss_musd,
    n_episodes=2000,
    episode_len=20,
    alpha=0.10,
    gamma=0.95,
    epsilon0=0.20,
    epsilon_min=0.02,
    seed=42,
):
    rng = np.random.default_rng(seed)
    states = _build_rl_state_space()
    actions = _rl_actions()
    s_to_i = {s: i for i, s in enumerate(states)}
    a_to_i = {a: i for i, a in enumerate(actions)}

    Q = np.zeros((len(states), len(actions)), dtype=float)
    ep_rewards = []
    ep_losses = []
    action_counts = np.zeros(len(actions), dtype=int)

    for ep in range(n_episodes):
        state = states[int(rng.integers(0, len(states)))]
        eps = max(epsilon_min, epsilon0 * (0.995 ** ep))
        total_reward = 0.0
        total_loss = 0.0

        for _ in range(episode_len):
            si = s_to_i[state]
            if rng.uniform() < eps:
                ai = int(rng.integers(0, len(actions)))
            else:
                ai = int(np.argmax(Q[si, :]))
            action = actions[ai]

            next_state, reward, loss = _simulate_rl_environment_step(
                state, action, base_loss_musd, rng
            )
            sj = s_to_i[next_state]

            Q[si, ai] = (1 - alpha) * Q[si, ai] + alpha * (
                reward + gamma * np.max(Q[sj, :])
            )

            total_reward += reward
            total_loss += loss
            action_counts[ai] += 1
            state = next_state

        ep_rewards.append(total_reward)
        ep_losses.append(total_loss)

    policy_idx = np.argmax(Q, axis=1)
    policy = pd.DataFrame({
        "severity_bin": [s[0] for s in states],
        "rail_util_bin": [s[1] for s in states],
        "port_util_bin": [s[2] for s in states],
        "inventory_stress_bin": [s[3] for s in states],
        "best_action": [actions[i] for i in policy_idx],
        "best_q_value": [Q[k, policy_idx[k]] for k in range(len(states))],    })

    action_dist = pd.DataFrame({
        "action": actions,
        "count": action_counts,
        "share": action_counts / max(action_counts.sum(), 1),
    }).sort_values("count", ascending=False)

    conv = pd.DataFrame({
        "episode": np.arange(1, n_episodes + 1),
        "episode_reward": ep_rewards,
        "episode_loss": ep_losses,
    })
    conv["rolling_100_reward"] = conv["episode_reward"].rolling(100, min_periods=1).mean()
    conv["rolling_100_loss"] = conv["episode_loss"].rolling(100, min_periods=1).mean()

    return {
        "Q": Q,
        "policy_map": policy,
        "action_distribution": action_dist,
        "convergence": conv,
    }

def _rl_action_symbol_labels():
    """
    Paper-consistent symbolic labels for RL actions.
    Uses Matplotlib mathtext so labels render in figures/PDFs.
    """
    return {
        "delta_r_1": r"$\delta_r^{(1)}$",
        "delta_r_2": r"$\delta_r^{(2)}$",
        "delta_b_1": r"$\delta_b^{(1)}$",
        "delta_b_2": r"$\delta_b^{(2)}$",
        "phi_truck": r"$\phi_t$",
        "phi_rail":  r"$\phi_r$",
        "phi_barge": r"$\phi_b$",
        "reset":     r"$\varnothing$",
    }
# ---------------------------------------------------------------------------
# RL paired comparison  (§5.5 Table 2)
# ---------------------------------------------------------------------------
def run_rl_paired_comparison(
    abm_baseline_results: dict,
    L_full,
    n_realizations: int = 2000,
    seed: int = 42,
    out_dir: str | None = None,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    actions = DEFAULT_ABM_PARAMS["rl_actions"]

    base_weekly_musd = float(
        abm_baseline_results.get(
            "rl_baseline_mean_weekly_loss_musd",
            abm_baseline_results["rl_baseline_loss_musd"],
        )
    )
    base_total_musd = 52.0 * base_weekly_musd

    # ---- NEW: learn policy for diagnostics
    rl_diag = learn_rl_policy(
        base_loss_musd=base_total_musd,
        n_episodes=3000,
        episode_len=20,
        seed=seed,
    )

    # policy lookup by severity only (for paired table)
    policy_by_sev = (
        rl_diag["policy_map"]
        .groupby("severity_bin")["best_action"]
        .agg(lambda x: x.value_counts().idxmax())
        .to_dict()
    )

    lambdas = np.clip(rng.beta(2, 3, size=n_realizations), 0.01, 0.99)
    records = []

    for lam in lambdas:
        loss_base = base_total_musd * lam
        if lam <= 0.25:
            sev = "low"
        elif lam <= 0.50:
            sev = "moderate"
        else:
            sev = "high"

        chosen_action = policy_by_sev.get(sev, "reset")
        params = actions[chosen_action]

        rc = params.get("rail_cost_mult", 1.0)
        bc = params.get("barge_cost_mult", 1.0)
        tc = params.get("truck_cost_mult", 1.0)
        eff_rail_cap = RAIL_CAP * params.get("truck_avail_cap", 1.0)
        rail_sat = max(0.0, lam * RAIL_CAP / max(eff_rail_cap, 1.0) - 1.0)

        loss_rl = loss_base * (rc * bc * tc) * (1.0 + 0.35 * rail_sat)

        records.append({
            "lambda": float(lam),
            "severity_bin": sev,
            "action": chosen_action,
            "loss_base": loss_base,
            "loss_rl": loss_rl,
        })

    df = pd.DataFrame(records)
    df_action_by_severity = (
        df.groupby(["severity_bin", "action"])
          .size()
          .reset_index(name="count")
    )
    df_action_by_severity["share_within_severity"] = (
        df_action_by_severity["count"] /
        df_action_by_severity.groupby("severity_bin")["count"].transform("sum")
    )
    rows = []
    for label, lo, hi in _RL_SEVERITY_BINS:
        sub = df[(df["lambda"] > lo) & (df["lambda"] <= hi)]
        if len(sub) < 2:
            continue
        n = len(sub)
        mu_b = float(sub["loss_base"].mean())
        mu_r = float(sub["loss_rl"].mean())
        pct = 100.0 * (mu_b - mu_r) / max(mu_b, 1e-9)

        boot = []
        for _ in range(1000):
            s = sub.sample(n=n, replace=True, random_state=int(rng.integers(0, 2**31)))
            boot.append(
                100.0 * (s["loss_base"].mean() - s["loss_rl"].mean()) / max(s["loss_base"].mean(), 1e-9)
            )

        rows.append({
            "severity_bin": label,
            "n_realizations": n,
            "baseline_mean_loss_musd": round(mu_b, 2),
            "rl_mean_loss_musd": round(mu_r, 2),
            "pct_reduction": round(pct, 1),
            "ci_low_pct": round(float(np.percentile(boot, 2.5)), 2),
            "ci_high_pct": round(float(np.percentile(boot, 97.5)), 2),
            "dominant_action": sub["action"].value_counts().idxmax(),
            "dominant_action_share": round(float(sub["action"].value_counts(normalize=True).iloc[0]), 3),
        })

    out = pd.DataFrame(rows)

    if out_dir is not None:
        os.makedirs(out_dir, exist_ok=True)

        with pd.ExcelWriter(os.path.join(out_dir, "RL_Diagnostics.xlsx"), engine="xlsxwriter") as writer:
            out.to_excel(writer, sheet_name="Paired_Table", index=False)
            df.to_excel(writer, sheet_name="Paired_Draws", index=False)
            rl_diag["policy_map"].to_excel(writer, sheet_name="Policy_Map", index=False)
            rl_diag["action_distribution"].to_excel(writer, sheet_name="Action_Distribution", index=False)
            rl_diag["convergence"].to_excel(writer, sheet_name="Convergence", index=False)
            df_action_by_severity.to_excel(writer, sheet_name="Action_By_Severity", index=False)

        # convergence curve (paper-consistent: positive loss, lower is better)
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.plot(
            rl_diag["convergence"]["episode"],
            rl_diag["convergence"]["rolling_100_loss"],
            linewidth=2
        )
        ax.set_xlabel("Episode", fontsize=16)
        ax.set_ylabel("Rolling mean episode loss (100-episode, M$)", fontsize=16)
        ax.tick_params(axis="both", labelsize=12)
        ax.grid(True, axis="y", linestyle=":", alpha=0.5)
        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, "RL_Convergence_Curve.pdf"), dpi=300)
        plt.close(fig)

        # action distribution
        ad = rl_diag["action_distribution"].copy()
        symbol_labels = _rl_action_symbol_labels()

        action_order = [
            "delta_r_1",
            "delta_r_2",
            "delta_b_1",
            "delta_b_2",
            "phi_truck",
            "phi_rail",
            "phi_barge",
            "reset",
        ]

        ad = ad.set_index("action").reindex(action_order).reset_index()
        ad["action_symbol"] = ad["action"].map(symbol_labels).fillna(ad["action"])

        fig, ax = plt.subplots(figsize=(8.5, 4.8))
        ax.bar(
            np.arange(len(ad)),
            ad["share"].values,
            color="0.45",
            edgecolor="0.2",
            linewidth=0.6,
        )
        ax.set_xticks(np.arange(len(ad)))
        ax.set_xticklabels(ad["action_symbol"], rotation=0, fontsize=13)  # x tick labels
        ax.set_xlabel("Action", fontsize=16)                              # x-axis label
        ax.set_ylabel("Selection share", fontsize=16)                    # y-axis label
        ax.tick_params(axis="y", labelsize=12)                           # y tick labels
        ax.grid(True, axis="y", linestyle=":", alpha=0.5)

        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, "RL_Action_Distribution.pdf"), dpi=300)
        plt.close(fig)

        # policy maps
        pol = rl_diag["policy_map"].copy()
        symbol_labels = _rl_action_symbol_labels()

        util_pretty = {
            "low": "Low",
            "med": "Medium",
            "high": "High",
        }

        action_order = [
            "delta_r_1",
            "delta_r_2",
            "delta_b_1",
            "delta_b_2",
            "phi_truck",
            "phi_rail",
            "phi_barge",
            "reset",
        ]

        cmap = _truncated_gray_cmap(lo=0.10, hi=0.82)

        for sev in ["low", "moderate", "high"]:
            sub = pol[
                (pol["severity_bin"] == sev) &
                (pol["inventory_stress_bin"] == "high")
            ].copy()

            pivot = sub.pivot(
                index="port_util_bin",
                columns="rail_util_bin",
                values="best_action"
            )

            row_order = [x for x in ["low", "med", "high"] if x in pivot.index]
            col_order = [x for x in ["low", "med", "high"] if x in pivot.columns]
            pivot = pivot.reindex(index=row_order, columns=col_order)

            amap = {a: i for i, a in enumerate(action_order)}
            M = pivot.replace(amap).infer_objects(copy=False).values

            fig, ax = plt.subplots(figsize=(6.5, 4.8))
            im = ax.imshow(
                M,
                aspect="auto",
                interpolation="nearest",
                cmap=cmap,
                vmin=-0.5,
                vmax=len(action_order) - 0.5,
            )

            ax.set_xticks(np.arange(len(pivot.columns)))
            ax.set_xticklabels([util_pretty.get(x, x) for x in pivot.columns], fontsize=12)

            ax.set_yticks(np.arange(len(pivot.index)))
            ax.set_yticklabels([util_pretty.get(x, x) for x in pivot.index], fontsize=12)

            ax.set_xlabel("Rail utilization", fontsize=16)
            ax.set_ylabel("Port utilization", fontsize=16)
            ax.tick_params(axis="both", labelsize=12)
            ax.set_xticks(np.arange(-0.5, len(pivot.columns), 1), minor=True)
            ax.set_yticks(np.arange(-0.5, len(pivot.index), 1), minor=True)
            ax.grid(which="minor", color="k", linestyle="-", linewidth=0.4, alpha=0.25)
            ax.tick_params(which="minor", bottom=False, left=False)

            cb = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
            cb.set_ticks(list(amap.values()))
            cb.set_ticklabels([symbol_labels[a] for a in action_order])
            cb.ax.tick_params(labelsize=14)

            plt.tight_layout()
            plt.savefig(os.path.join(out_dir, f"RL_Policy_Map_{sev}.pdf"), dpi=300)
            plt.close(fig)
    return out


# ---------------------------------------------------------------------------
# NOVELTY METRICS  (§2.5 Contributions — machine-verifiable evidence)
# ---------------------------------------------------------------------------

def compute_novelty_metrics(
    abm_results: dict,
    rl_comparison_df: pd.DataFrame,
    n_stochastic: int = 2000,
    seed: int = 42,
    out_dir: str | None = None,
) -> dict:
    """
    Compute and return every quantified claim cited in §2.5 (Contributions),
    the abstract, and §6 (Conclusion).

    This function is the *single source of truth* for the paper's novelty
    numbers.  Run it after run_abm() and run_rl_paired_comparison() and
    verify the output against the manuscript before submission.

    Contributions addressed
    -----------------------
    C1  Endogenous multimodal routing under binding capacity constraints:
        → inbound/outbound tonnage ratio (validates gateway characterisation)
        → modal split distribution across 52 weeks (shows endogeneity)
        → fraction of weeks in which at least one mode exceeds capacity

    C2  ABM–MRIIM coupling at 48-state × 15-sector resolution:
        → nonzero state-sector cells in the loss matrix
        → Spearman rank correlation between direct FAF exposure and
          MRIIM-propagated loss (low ρ = evidence that structure ≠ exposure)

    C3  Stochastic disconnect between shock dispersion and loss concentration:
        → fraction of realizations in which Manufacturing (Sec 5) or
          Transportation/Warehousing (Sec 8) is in the top-3 loss sectors
        → ratio of p80 national loss to p50 (tail-risk multiplier)
        → Gini coefficient of mean sectoral losses (concentration index)

    C4  RL intervention effectiveness frontier:
        → moderate-severity mean loss reduction + 95 % CI
        → high-severity mean loss reduction (saturation evidence)
        → rail-vs-barge per-unit benefit asymmetry ($/1 000 t shifted)

    Parameters
    ----------
    abm_results : dict
        Return value of run_abm().
    rl_comparison_df : pd.DataFrame
        Return value of run_rl_paired_comparison().
    n_stochastic : int
        Number of Monte Carlo realizations used to compute C3 metrics.
        Should match the n_realizations passed to run_rl_paired_comparison().
    seed : int
        NumPy random seed — must match run_rl_paired_comparison() seed so
        the same λ draws are used for both tables.
    out_dir : str or None
        If provided, writes a plain-text summary to
        ``<out_dir>/Novelty_Metrics_Check.txt``.

    Returns
    -------
    dict  — keys match the labels used in the paper; all values are either
            floats or short strings ready to paste into LaTeX.
    """
    rng = np.random.default_rng(seed)

    sector_loss  = abm_results["abm_sector_loss"]       # pd.Series (M$)
    mriim_matrix = abm_results["mriim_matrix"]          # 48 × 15 DataFrame
    df_modes     = abm_results["modes"]                 # 52 × 15 int DataFrame
    df_cong      = abm_results["congestion"]            # 52 × 2 DataFrame
    abm_matrix   = abm_results["abm_matrix"]            # 48 × 15 (ABM shock)
    meta         = abm_results["meta"]

    metrics = {}

    # ------------------------------------------------------------------
    # C1 — endogenous routing
    # ------------------------------------------------------------------

    # Inbound/outbound tonnage ratio (validates §4.2 gateway claim)
    tons_total = meta["tons_day_total"]
    # We don't have inbound/outbound split in meta, but we have direction
    # embedded in sector_loss via abm_matrix; approximate from modes:
    # Mode 0 = wait (port), 1 = rail, 2 = truck, 3 = mixed
    mode_counts = df_modes.apply(pd.Series.value_counts).fillna(0).T.sum()
    total_mode_steps = mode_counts.sum()
    metrics["c1_rail_share_pct"]    = round(100.0 * mode_counts.get(1, 0) / max(total_mode_steps, 1), 1)
    metrics["c1_truck_share_pct"]   = round(100.0 * mode_counts.get(2, 0) / max(total_mode_steps, 1), 1)
    metrics["c1_mixed_share_pct"]   = round(100.0 * mode_counts.get(3, 0) / max(total_mode_steps, 1), 1)
    metrics["c1_wait_share_pct"]    = round(100.0 * mode_counts.get(0, 0) / max(total_mode_steps, 1), 1)

    # Weeks in which rail or port load exceeds nominal capacity
    rail_overload_weeks = (df_cong["rail_load"] > RAIL_CAP).sum()
    port_overload_weeks = (df_cong["port_load"] > PORT_CAP).sum()
    n_weeks = len(df_cong)
    metrics["c1_rail_overload_weeks"]    = int(rail_overload_weeks)
    metrics["c1_port_overload_weeks"]    = int(port_overload_weeks)
    metrics["c1_any_overload_pct_weeks"] = round(
        100.0 * ((df_cong["rail_load"] > RAIL_CAP) | (df_cong["port_load"] > PORT_CAP)).mean(), 1
    )

    # ------------------------------------------------------------------
    # C2 — ABM–MRIIM coupling resolution
    # ------------------------------------------------------------------

    # Number of nonzero state-sector cells in the MRIIM output matrix
    mriim_nonzero_cells  = int((mriim_matrix > 0).values.sum())
    total_cells          = mriim_matrix.shape[0] * mriim_matrix.shape[1]
    metrics["c2_mriim_nonzero_cells"] = mriim_nonzero_cells
    metrics["c2_mriim_total_cells"]   = total_cells
    metrics["c2_mriim_coverage_pct"]  = round(100.0 * mriim_nonzero_cells / total_cells, 1)

    # Spearman ρ between direct FAF exposure (abm_matrix) and MRIIM output
    # A LOW ρ is the key novelty claim: network structure ≠ direct exposure.
    abm_flat    = abm_matrix.values.flatten()
    mriim_flat  = mriim_matrix.values.flatten()
    if abm_flat.std() > 0 and mriim_flat.std() > 0:
        from scipy.stats import spearmanr
        rho, p_rho = spearmanr(abm_flat, mriim_flat)
        metrics["c2_spearman_rho_abm_mriim"]   = round(float(rho), 3)
        metrics["c2_spearman_pval"]            = float(p_rho)
        # Interpretation string for the paper
        metrics["c2_spearman_interp"] = (
            "moderate positive" if rho > 0.5
            else ("weak positive" if rho > 0.2
                  else "negligible / negative")
        )
    else:
        metrics["c2_spearman_rho_abm_mriim"] = np.nan
        metrics["c2_spearman_pval"]          = np.nan
        metrics["c2_spearman_interp"]        = "undetermined (zero variance)"

    # State-level amplification: ratio of total MRIIM loss to total ABM shock
    abm_total_musd   = float(abm_matrix.values.sum())
    mriim_total_musd = float(mriim_matrix.values.sum())
    metrics["c2_abm_direct_loss_musd"]   = round(abm_total_musd, 2)
    metrics["c2_mriim_total_loss_musd"]  = round(mriim_total_musd, 2)
    metrics["c2_io_amplification_ratio"] = round(
        mriim_total_musd / max(abm_total_musd, 1e-9), 3
    )

    # ------------------------------------------------------------------
    # C3 — Stochastic disconnect between shock dispersion and concentration
    # Uses same λ draws as run_rl_paired_comparison for consistency.
    # ------------------------------------------------------------------

    # Identify the two "structural concentrator" sectors
    mfg_candidates = [s for s in sector_loss.index
                      if "manufactur" in s.lower()]
    tw_candidates  = [s for s in sector_loss.index
                      if "transport" in s.lower() or "warehouse" in s.lower()
                      or "warehousing" in s.lower()]

    # Graceful fallback: use top-2 actual loss sectors if names don't match
    if not mfg_candidates:
        mfg_candidates = [sector_loss.index[0]]
    if not tw_candidates:
        tw_candidates  = [sector_loss.index[1]]

    mfg_sec = mfg_candidates[0]
    tw_sec  = tw_candidates[0]

    # Monte Carlo: for each λ draw, scale all sector losses proportionally
    # and record which sectors are in the top-3.
    lambdas_c3 = np.clip(rng.beta(2, 3, size=n_stochastic), 0.01, 0.99)
    n_sectors  = len(sector_loss)
    base_losses = sector_loss.values.astype(float)

    concentrator_top3_count = 0
    mfg_top3_count  = 0
    tw_top3_count   = 0
    total_losses_mc = []

    for lam in lambdas_c3:
        # Stochastic realization: scale + add heterogeneous noise
        realization = base_losses * lam * np.random.uniform(0.7, 1.3, size=n_sectors)
        top3_idx    = np.argsort(realization)[::-1][:3]
        top3_names  = [sector_loss.index[j] for j in top3_idx]
        if mfg_sec in top3_names or tw_sec in top3_names:
            concentrator_top3_count += 1
        if mfg_sec in top3_names:
            mfg_top3_count += 1
        if tw_sec in top3_names:
            tw_top3_count += 1
        total_losses_mc.append(float(realization.sum()))

    concentrator_freq = 100.0 * concentrator_top3_count / n_stochastic
    mfg_freq          = 100.0 * mfg_top3_count / n_stochastic
    tw_freq           = 100.0 * tw_top3_count  / n_stochastic

    metrics["c3_mfg_sector"]              = mfg_sec
    metrics["c3_tw_sector"]               = tw_sec
    metrics["c3_concentrator_top3_pct"]   = round(concentrator_freq, 1)
    metrics["c3_mfg_top3_pct"]            = round(mfg_freq, 1)
    metrics["c3_tw_top3_pct"]             = round(tw_freq, 1)

    # Tail-risk multiplier (p80 / p50)
    arr   = np.array(total_losses_mc)
    p50   = float(np.percentile(arr, 50))
    p80   = float(np.percentile(arr, 80))
    p95   = float(np.percentile(arr, 95))
    metrics["c3_p50_loss_musd"]    = round(p50, 2)
    metrics["c3_p80_loss_musd"]    = round(p80, 2)
    metrics["c3_p95_loss_musd"]    = round(p95, 2)
    metrics["c3_p80_over_p50"]     = round(p80 / max(p50, 1e-9), 2)
    metrics["c3_loss_range_ratio"] = round(arr.max() / max(arr.min(), 1e-9), 1)

    # Gini coefficient of mean sectoral losses (concentration index for §2.5 C3)
    sl = np.sort(np.abs(base_losses))
    n  = len(sl)
    gini = float((2 * np.sum((np.arange(1, n + 1)) * sl) - (n + 1) * sl.sum())
                 / max(n * sl.sum(), 1e-9))
    metrics["c3_gini_sector_loss"] = round(gini, 3)

    # ------------------------------------------------------------------
    # C4 — RL intervention effectiveness frontier
    # ------------------------------------------------------------------

    if rl_comparison_df is not None and not rl_comparison_df.empty:
        for _, row in rl_comparison_df.iterrows():
            label = row["severity_bin"]
            metrics[f"c4_rl_{label}_pct_reduction"]  = row["pct_reduction"]
            metrics[f"c4_rl_{label}_ci_lo"]          = row["ci_low_pct"]
            metrics[f"c4_rl_{label}_ci_hi"]          = row["ci_high_pct"]
            metrics[f"c4_rl_{label}_baseline_musd"]  = row["baseline_mean_loss_musd"]
            metrics[f"c4_rl_{label}_rl_musd"]        = row["rl_mean_loss_musd"]

        mod = rl_comparison_df[rl_comparison_df["severity_bin"] == "moderate"]
        hi  = rl_comparison_df[rl_comparison_df["severity_bin"] == "high"]
        if not mod.empty and not hi.empty:
            metrics["c4_rl_saturation_evidence"] = (
                f"Moderate: {float(mod['pct_reduction'].iloc[0]):.1f}% reduction  "
                f"vs  High: {float(hi['pct_reduction'].iloc[0]):.1f}% reduction  "
                f"(difference = "
                f"{float(mod['pct_reduction'].iloc[0]) - float(hi['pct_reduction'].iloc[0]):.1f}pp)"
            )

        # Rail vs barge per-unit benefit (computed from COST_TKM differentials)
        # Rail:  baseline diesel cost = 0.007891 $/t-km × avg distance
        # Barge: baseline diesel cost = 0.001883 $/t-km × avg distance
        # delta_r_2 reduces rail cost by 15%; delta_b_2 reduces barge cost by 14%
        avg_dist_km   = 1500.0   # approximate national-average haul, km
        ton_batch     = 1_000.0  # 1 000 tons = unit for comparison
        rail_saving   = ton_batch * avg_dist_km * (COST_TKM["rail"]["diesel"]  * 0.15)
        barge_saving  = ton_batch * avg_dist_km * (COST_TKM["barge"]["diesel"] * 0.14)
        metrics["c4_rail_saving_per_1000t_musd"]  = round(rail_saving  / 1e6, 4)
        metrics["c4_barge_saving_per_1000t_musd"] = round(barge_saving / 1e6, 4)
        metrics["c4_rail_barge_asymmetry_ratio"]  = round(
            rail_saving / max(barge_saving, 1e-9), 2
        )

    # ------------------------------------------------------------------
    # Write plain-text summary
    # ------------------------------------------------------------------

    lines = [
        "=" * 68,
        "NOVELTY METRICS — paper consistency check",
        "=" * 68,
        "",
        "─── Contribution 1: Endogenous multimodal routing ───────────────",
        f"  Modal shares (% of agent-week decisions):",
        f"    Rail:  {metrics['c1_rail_share_pct']}%",
        f"    Truck: {metrics['c1_truck_share_pct']}%",
        f"    Mixed: {metrics['c1_mixed_share_pct']}%",
        f"    Wait:  {metrics['c1_wait_share_pct']}%",
        f"  Weeks with any mode exceeding capacity: "
        f"{metrics['c1_any_overload_pct_weeks']}% of {n_weeks}",
        f"    Rail overload weeks: {metrics['c1_rail_overload_weeks']}",
        f"    Port overload weeks: {metrics['c1_port_overload_weeks']}",
        "",
        "─── Contribution 2: ABM–MRIIM coupling resolution ───────────────",
        f"  ABM direct loss:   {metrics['c2_abm_direct_loss_musd']} M$",
        f"  MRIIM total loss:  {metrics['c2_mriim_total_loss_musd']} M$",
        f"  IO amplification:  ×{metrics['c2_io_amplification_ratio']}",
        f"  Nonzero MRIIM cells: {metrics['c2_mriim_nonzero_cells']} / {metrics['c2_mriim_total_cells']} "
        f"({metrics['c2_mriim_coverage_pct']}%)",
        f"  Spearman ρ(ABM exposure, MRIIM loss): "
        f"{metrics['c2_spearman_rho_abm_mriim']}  "
        f"[{metrics['c2_spearman_interp']}]",
        f"  → paper claims: structure ≠ exposure (low ρ expected)",
        "",
        "─── Contribution 3: Stochastic disconnect ────────────────────────",
        f"  Structural concentrators: '{metrics['c3_mfg_sector']}' "
        f"& '{metrics['c3_tw_sector']}'",
        f"  Either sector in top-3 across realizations: "
        f"{metrics['c3_concentrator_top3_pct']}%",
        f"    Manufacturing top-3 freq:          {metrics['c3_mfg_top3_pct']}%",
        f"    Transport/warehousing top-3 freq:  {metrics['c3_tw_top3_pct']}%",
        f"  → paper claims: >80% (§2.5 C3, abstract, §5.2)",
        f"  p50 national loss: {metrics['c3_p50_loss_musd']} M$",
        f"  p80 national loss: {metrics['c3_p80_loss_musd']} M$  "
        f"(p80/p50 = ×{metrics['c3_p80_over_p50']})",
        f"  p95 national loss: {metrics['c3_p95_loss_musd']} M$",
        f"  Loss range (max/min):  ×{metrics['c3_loss_range_ratio']}",
        f"  → paper claims: >2 orders of magnitude (§6)",
        f"  Gini coefficient (sectoral loss concentration): "
        f"{metrics['c3_gini_sector_loss']}",
        "",
        "─── Contribution 4: RL effectiveness frontier ────────────────────",
    ]

    for sev in ("low", "moderate", "high"):
        k = f"c4_rl_{sev}_pct_reduction"
        if k in metrics:
            ci_lo = metrics.get(f"c4_rl_{sev}_ci_lo", "?")
            ci_hi = metrics.get(f"c4_rl_{sev}_ci_hi", "?")
            lines.append(
                f"  {sev.capitalize():10s}: {metrics[k]:.1f}%  "
                f"(95% CI [{ci_lo}%, {ci_hi}%])"
            )

    if "c4_rl_saturation_evidence" in metrics:
        lines += [
            f"  Saturation evidence: {metrics['c4_rl_saturation_evidence']}",
            f"  → paper claims: 12–18% moderate, <5% high (§2.5 C4, §5.5)",
        ]
    if "c4_rail_barge_asymmetry_ratio" in metrics:
        lines += [
            f"  Rail saving / 1 000 t: {metrics['c4_rail_saving_per_1000t_musd']} M$",
            f"  Barge saving / 1 000 t: {metrics['c4_barge_saving_per_1000t_musd']} M$",
            f"  Rail/barge asymmetry ratio: ×{metrics['c4_rail_barge_asymmetry_ratio']}",
            f"  → paper claims rail >> barge per unit (§5.5)",
        ]

    lines += [
        "",
        "=" * 68,
        "All metrics above must match the manuscript before submission.",
        "=" * 68,
    ]

    summary = "\n".join(lines)
    print("\n" + summary)

    if out_dir is not None:
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, "Novelty_Metrics_Check.txt")
        with open(out_path, "w") as fh:
            fh.write(summary + "\n")
        print(f"\n[Novelty Metrics] Written → {out_path}")

    return metrics

def run_capacity_sensitivity(
    out_dir,
    include_inbound=True,
    port_caps=(40000.0, 50000.0, 60000.0, 70000.0, 80000.0),
    rail_caps=(60000.0, 75000.0, 90000.0, 105000.0, 120000.0),
    seeds=(0, 1, 2, 3, 4),
    **kwargs,
):
    """
    Grid sensitivity over assumed port and rail capacity thresholds.
    For each (port_cap, rail_cap, seed):
      - run ABM
      - record direct ABM loss
      - record MRIIM propagated loss
      - record overload statistics
    """
    os.makedirs(out_dir, exist_ok=True)
    rows = []

    for pc in port_caps:
        for rc in rail_caps:
            for sd in seeds:
                res = run_abm(
                    include_inbound=include_inbound,
                    abm_params={
                        "port_cap": float(pc),
                        "rail_cap": float(rc),
                        "seed": int(sd),
                    },
                    **kwargs,
                )

                cong = res["congestion"]
                abm_total = float(res["abm_sector_loss"].sum())
                mriim_total = float(res["mriim_matrix"].values.sum())

                rail_over = int((cong["rail_load"] > rc).sum())
                port_over = int((cong["port_load"] > pc).sum())
                any_over = int(((cong["rail_load"] > rc) | (cong["port_load"] > pc)).sum())

                rows.append({
                    "port_cap": float(pc),
                    "rail_cap": float(rc),
                    "seed": int(sd),
                    "abm_total_loss_musd": abm_total,
                    "mriim_total_loss_musd": mriim_total,
                    "rail_overload_weeks": rail_over,
                    "port_overload_weeks": port_over,
                    "any_overload_weeks": any_over,
                })

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(out_dir, "capacity_sensitivity_runs.csv"), index=False)

    agg = (
        df.groupby(["port_cap", "rail_cap"], as_index=False)
          .agg(
              abm_mean=("abm_total_loss_musd", "mean"),
              abm_sd=("abm_total_loss_musd", "std"),
              mriim_mean=("mriim_total_loss_musd", "mean"),
              mriim_sd=("mriim_total_loss_musd", "std"),
              rail_over_mean=("rail_overload_weeks", "mean"),
              port_over_mean=("port_overload_weeks", "mean"),
              any_over_mean=("any_overload_weeks", "mean"),
          )
    )
    agg.to_csv(os.path.join(out_dir, "capacity_sensitivity_summary.csv"), index=False)

    # Pivot tables for heatmaps
    abm_piv = agg.pivot(index="port_cap", columns="rail_cap", values="abm_mean")
    mriim_piv = agg.pivot(index="port_cap", columns="rail_cap", values="mriim_mean")
    over_piv = agg.pivot(index="port_cap", columns="rail_cap", values="any_over_mean")

    with pd.ExcelWriter(os.path.join(out_dir, "Capacity_Sensitivity.xlsx"), engine="xlsxwriter") as writer:
        df.to_excel(writer, sheet_name="AllRuns", index=False)
        agg.to_excel(writer, sheet_name="Summary", index=False)
        abm_piv.to_excel(writer, sheet_name="ABM_Loss_Heatmap")
        mriim_piv.to_excel(writer, sheet_name="MRIIM_Loss_Heatmap")
        over_piv.to_excel(writer, sheet_name="OverloadWeeks_Heatmap")

    # figures
    for piv, title, fname, cbar in [
        (abm_piv, "Capacity sensitivity: mean ABM loss (M$)", "cap_sens_abm_loss.png", "mean ABM loss (M$)"),
        (mriim_piv, "Capacity sensitivity: mean MRIIM loss (M$)", "cap_sens_mriim_loss.png", "mean MRIIM loss (M$)"),
        (over_piv, "Capacity sensitivity: mean overload weeks", "cap_sens_overload_weeks.png", "mean overload weeks"),
    ]:
        fig, ax = plt.subplots(figsize=(8, 6))
        im = ax.imshow(piv.values, aspect="auto", cmap="viridis", interpolation="nearest")
        ax.set_xticks(np.arange(len(piv.columns)))
        ax.set_xticklabels([f"{int(x):,}" for x in piv.columns], rotation=45, ha="right")
        ax.set_yticks(np.arange(len(piv.index)))
        ax.set_yticklabels([f"{int(x):,}" for x in piv.index])
        ax.set_xlabel("Rail capacity (tons/week)")
        ax.set_ylabel("Port capacity (tons/week)")
        ax.set_title(title)
        cb = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cb.set_label(cbar)
        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, fname), dpi=300)
        plt.close(fig)

    return {
        "all_runs": df,
        "summary": agg,
        "abm_heatmap": abm_piv,
        "mriim_heatmap": mriim_piv,
        "overload_heatmap": over_piv,
    }
def _extract_abm_moments(res):
    cong = res["congestion"]
    costs = res["costs"]

    out = {
        "mean_weekly_loss_musd": float(costs.sum(axis=1).mean() / 1e6),
        "mean_port_delay_days": float(7.0 * cong["port_delay_weeks"].mean()),
        "mean_rail_delay_days": float(7.0 * cong["rail_delay_weeks"].mean()),
        "p95_port_delay_days": float(7.0 * cong["port_delay_weeks"].quantile(0.95)),
        "p95_rail_delay_days": float(7.0 * cong["rail_delay_weeks"].quantile(0.95)),
        "weeks_port_delay_ge_9d": float((7.0 * cong["port_delay_weeks"] >= 9.0).sum()),
        "weeks_rail_delay_ge_6d": float((7.0 * cong["rail_delay_weeks"] >= 6.0).sum()),
        "mean_port_utilization": float(cong["port_utilization"].mean()),
        "mean_rail_utilization": float(cong["rail_utilization"].mean()),
        "max_port_utilization": float(cong["port_utilization"].max()),
        "max_rail_utilization": float(cong["rail_utilization"].max()),
        "mean_port_overload_weeks": float((cong["port_load"] > DEFAULT_ABM_PARAMS["port_cap"]).sum()),
        "mean_rail_overload_weeks": float((cong["rail_load"] > DEFAULT_ABM_PARAMS["rail_cap"]).sum()),
    }
    return out

def run_abm_calibration(
    targets_csv,
    out_dir,
    seeds=(0, 1, 2),
    grid=None,
    include_inbound=True,
    **kwargs,
):
    os.makedirs(out_dir, exist_ok=True)
    targets = pd.read_csv(targets_csv)

    if grid is None:
        grid = {
            "queue_alpha": [0.10, 0.15, 0.20],
            "queue_beta": [2.0, 3.0, 4.0],
            "inventory_partial_mult": [2.0, 3.0, 4.0],
            "inventory_post_buffer_mult": [1.5, 2.0, 2.5],
            "belief_nu_min": [0.7, 0.8, 0.9],
            "belief_nu_max": [1.1, 1.2, 1.3],
        }

    import itertools
    keys = list(grid.keys())
    rows = []

    for vals in itertools.product(*[grid[k] for k in keys]):
        params = dict(zip(keys, vals))

        if params["belief_nu_min"] > params["belief_nu_max"]:
            continue

        metrics_acc = []

        for sd in seeds:
            p = dict(params)
            p["seed"] = int(sd)
            kwargs = dict(kwargs)
            kwargs.setdefault("run_polb_switching", False)
            res = run_abm(include_inbound=include_inbound, abm_params=p, **kwargs)
            metrics_acc.append(_extract_abm_moments(res))

        avg = pd.DataFrame(metrics_acc).mean(axis=0).to_dict()

        obj = 0.0
        for _, r in targets.iterrows():
            m = r["metric"]
            t = float(r["target_value"])
            w = float(r["weight"])
            sim = float(avg[m])
            obj += w * ((sim - t) / max(abs(t), 1e-9)) ** 2

        row = dict(params)
        row["objective"] = obj
        row.update({f"sim_{k}": v for k, v in avg.items()})
        rows.append(row)

    df = pd.DataFrame(rows).sort_values("objective")
    df.to_csv(os.path.join(out_dir, "abm_calibration_grid.csv"), index=False)

    best = df.iloc[0].to_dict()
    best_df = pd.DataFrame([best])
    best_df.to_csv(os.path.join(out_dir, "abm_calibration_best.csv"), index=False)

    with pd.ExcelWriter(os.path.join(out_dir, "ABM_Calibration.xlsx"), engine="xlsxwriter") as writer:
        df.to_excel(writer, sheet_name="Calibration_Grid", index=False)
        best_df.to_excel(writer, sheet_name="Best_Run", index=False)
    print("\n[ABM Calibration] Best parameter set:")
    print(best_df.to_string(index=False))
    return df

# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("freight_abm module loaded (no execution).")


# ---------------------------------------------------------------------------
# PORT-SWITCHING SCENARIO  (§5.6)
#
# Design rationale
# ----------------
# When POLA capacity falls to 25% of normal (75% reduction — near-full
# closure), shippers must decide whether to wait, reroute overland, or
# divert to the Port of Long Beach (POLB, FAF code "062").  POLB shares the
# San Pedro Bay marine terminal complex with POLA and can physically receive
# POLA-bound vessels on short notice.
#
# Three things only an endogenous ABM can capture:
#   1. POLB capacity saturation — diverted volume raises POLB generalized
#      cost via exp_congestion(), eventually making overland modes competitive.
#   2. Distance penalty — POLB rail distances are 3% longer than POLA
#      equivalents for inland states, raising delivered cost per sector.
#   3. Asymmetric sectoral recovery — low-inventory sectors are forced to
#      divert earlier and absorb more of the distance penalty.
# ---------------------------------------------------------------------------

POLB_CODE              = "062"
POLB_CAP               = PORT_CAP * 1.10    # 66 000 t/wk  (POLB ~10% > POLA)
POLB_RAIL_DIST_FACTOR  = 1.03               # +3% rail distance vs POLA
POLB_TRIGGER_SEVERITY  = 0.25               # fraction of PORT_CAP removed


def load_polb_distances(pola_dist_df):
    """Derive POLB distance table from POLA table (3% rail uplift, truck/water unchanged)."""
    polb = pola_dist_df.copy()
    polb["rail_d"] = polb["rail_d"] * POLB_RAIL_DIST_FACTOR
    return polb


def run_port_switching_scenario(
    faf_raw,
    pola_dist_df,
    gdp_df,
    sectors,
    tons,
    vals,
    sector_dist_pola,
    n_weeks=52,
    pola_capacity_reduction=POLB_TRIGGER_SEVERITY,   # fraction of PORT_CAP REMOVED
    blocked_series=None,                              # optional per-week blockage (same units you use elsewhere)
    blocked_const_weeks=2.0,                         # fallback constant blockage (weeks)
    enable_polb=True,                                 # toggle POLB option
    seed=0,
    **policy,
):
    """
    POLA 75%-reduction scenario with POLB as an alternative port.

    Five-way mode choice each week: wait / rail / truck / mixed / POLB.
    POLB load accumulates independently; once it exceeds POLB_CAP the
    exp_congestion() multiplier makes POLB unattractive, revealing the
    saturation frontier.

    Returns
    -------
    dict with keys: costs_sw, congestion_sw, modes_sw, sector_loss_sw,
                    mriim_matrix_sw, saturation_week, peak_unserved, meta_sw
    """
    np.random.seed(seed)

    polb_dist = load_polb_distances(pola_dist_df)

    # POLB sector distances
    sector_dist_polb = {}
    for s in sectors:
        sub = faf_raw[faf_raw["sector"] == s]
        w   = sub["tons_day"].values.astype(float)
        if w.sum() > 0:
            sector_dist_polb[s] = {
                "truck": float(np.average(sub["truck_d"], weights=w)),
                "rail":  float(np.average(sub["rail_d"],  weights=w) * POLB_RAIL_DIST_FACTOR),
                "barge": float(np.average(sub["water_d"], weights=w)),
            }
        else:
            sector_dist_polb[s] = {"truck": 0.0, "rail": 0.0, "barge": 0.0}

    # Re-create agents with identical parameters for comparability
    alpha  = np.linspace(0.05, 0.15, len(sectors))
    beta   = np.linspace(0.2,  0.8,  len(sectors))
    vot    = 0.02 * vals / np.maximum(tons, 1.0)
    inv    = np.clip(0.5 + 3.0 * (vals / np.max(vals) if np.max(vals) > 0 else 0.0), 1.0, 6.0)
    agents = [
        SectorAgent(sectors[i], tons[i], vals[i], alpha[i], beta[i], vot[i], inv[i])
        for i in range(len(sectors))
    ]

    pola_cap_sw  = PORT_CAP * (1.0 - float(pola_capacity_reduction))  # e.g. 45k if reduction=0.25
    rail_cap     = RAIL_CAP
    polb_cap     = POLB_CAP

    diag_modes, diag_costs, diag_cong = [], [], []
    port_load_prev = polb_load_prev = rail_load_prev = 0.0
    saturation_week = n_weeks + 1
    peak_unserved   = 0.0
    polb_diverted_tons_weekly = []     # tons/week actually sent to POLB
    polb_mode_share_weekly    = []     # share of agent decisions that chose POLB
    LOSS_MULT = float(policy.get("loss_mult", 1.0))
    for w in tqdm(range(n_weeks), desc="Port-switching weeks"):
        if blocked_series is not None and w < len(blocked_series):
            blocked = float(blocked_series[w])
        else:
            blocked = float(blocked_const_weeks)
        cap_shock = 1.0 - 0.15 * np.tanh(blocked / 3.0)

        load_port = np.random.uniform(0.45, 0.75) * port_load_prev
        load_rail = np.random.uniform(0.50, 0.80) * rail_load_prev
        load_polb = np.random.uniform(0.60, 0.85) * polb_load_prev

        weekly_losses = np.zeros(len(agents))
        unserved_week = 0.0
        polb_diverted_this_week = 0.0
        polb_choices = 0

        for i, a in enumerate(agents):
            a.update_belief(blocked)
            a.hysteresis = 0.9 * a.hysteresis + 0.1 * blocked
            stress       = blocked / (a.inv + 1)
            a.alpha     *= (1 + 0.02 * stress)
            a.beta      *= (1 - 0.01 * stress)

            tons_week = 7.0 * a.tons_day
            d_pola    = sector_dist_pola[a.name]
            d_polb    = sector_dist_polb[a.name]

            # Costs: POLA modes
            c_truck = generalized_cost(tons_week, d_pola["truck"], "truck", FUEL_DEFAULT["truck"], a.value_day * 7)
            c_rail  = generalized_cost(tons_week, d_pola["rail"],  "rail",  FUEL_DEFAULT["rail"],  a.value_day * 7)
            c_barge = generalized_cost(tons_week, d_pola["barge"], "barge", FUEL_DEFAULT["barge"], a.value_day * 7)

            # Cost: POLB diversion (truck + rail blend, plus marine delay)
            c_polb_truck  = generalized_cost(tons_week, d_polb["truck"], "truck", FUEL_DEFAULT["truck"], a.value_day * 7)
            c_polb_rail   = generalized_cost(tons_week, d_polb["rail"],  "rail",  FUEL_DEFAULT["rail"],  a.value_day * 7)
            c_polb_marine = exp_congestion(c_polb_truck * 0.15, load_polb, polb_cap)
            c_polb = exp_congestion(
                0.55 * c_polb_truck + 0.35 * c_polb_rail + 0.10 * c_polb_marine,
                load_polb, polb_cap
            )

            # POLA congestion at reduced capacity
            eff_pola_cap = cap_shock * pola_cap_sw * max(0.05, 1.0 - blocked / 6.0)
            eff_rail_cap = cap_shock * rail_cap    * max(0.20, 1.0 - 0.5 * blocked / 6.0)

            c_rail  = exp_congestion(c_rail,  load_rail, eff_rail_cap)
            c_barge = exp_congestion(c_barge, load_port, eff_pola_cap)
            c_mixed = exp_congestion(c_rail + c_barge, load_rail + load_port, rail_cap + pola_cap_sw)

            rail_delay = queue_delay(load_rail, rail_cap)
            port_delay = queue_delay(load_port, max(eff_pola_cap, 1.0))   # <-- use effective cap
            wait_weeks = max(blocked, rail_delay + port_delay)
            cong_pen   = 0.5 * (rail_delay + port_delay) * a.value_day * 7.0

            # Five-way utility: wait / rail / truck / mixed / POLB
            # -------------------------- MODE-SENSITIVE DELAYS --------------------------
            # Gate delay at POLA should penalize *all* POLA-dependent options (rail/truck/mixed),
            # otherwise overland reroute dominates and POLB never matters.
            pola_gate_delay = queue_delay(load_port, max(eff_pola_cap, 1.0)) + 0.10 * blocked
            polb_eff_cap    = cap_shock * polb_cap * max(0.20, 1.0 - 0.25 * blocked / 6.0)
            polb_gate_delay = queue_delay(load_polb, max(polb_eff_cap, 1.0)) + 0.03 * blocked
            # Optional: add truck saturation too (otherwise truck is an infinite sink)
            TRUCK_CAP_SW = float(policy.get("truck_cap_sw", 120_000.0))

            truck_delay  = queue_delay(load_port, max(TRUCK_CAP_SW, 1.0))

            # Mode-specific delay (weeks) — THIS is what drives output/inventory losses
            delay_wait  = max(blocked, pola_gate_delay)                           # waiting at POLA
            delay_rail  = pola_gate_delay + rail_delay                             # POLA processing + rail queues
            delay_truck = pola_gate_delay + 0.50 * truck_delay                      # POLA processing + some truck friction
            delay_mixed = pola_gate_delay + 0.50 * rail_delay + 0.25 * port_delay   # blended
            delay_polb  = polb_gate_delay + 0.30 * rail_delay                        # POLB processing + smaller inland queue

            # -------------------------- COST ADJUSTMENTS --------------------------
            # Make POLA-dependent overland modes pay the gate delay in utility space,
            # and allow POLB to include a switching friction/handling cost if desired.
            delay_cost_wait  = a.vot * delay_wait  * 7.0 * a.value_day
            delay_cost_rail  = a.vot * delay_rail  * 7.0 * a.value_day
            delay_cost_truck = a.vot * delay_truck * 7.0 * a.value_day
            delay_cost_mixed = a.vot * delay_mixed * 7.0 * a.value_day
            delay_cost_polb  = a.vot * delay_polb  * 7.0 * a.value_day

            # Optional: explicit POLB handling/switching cost ($/ton)
            POLB_SWITCH_COST_PER_TON = float(policy.get("polb_switch_cost_per_ton", 0.0))

            c_polb = c_polb + POLB_SWITCH_COST_PER_TON * tons_week

            # -------------------------- 5-WAY CHOICE (ALWAYS 5) --------------------------
            # Always draw 5 gumbels so baseline(no-polb) and switching(polb) are paired fairly.
            POLB_UTILITY_BONUS = float(policy.get("polb_utility_bonus", 0.0))

            # --- SCALE costs into M$ so POLB can actually compete in the logit ---
            COST_SCALE = float(policy.get("utility_cost_scale", 1e6))   # dollars -> M$
            TEMP       = float(policy.get("utility_temp", 1.0))         # >1 increases randomness
            POLB_BONUS_MUSD = float(policy.get("polb_utility_bonus_musd", 0.0))

            u = np.array([
    -((delay_cost_wait + a.alpha * delay_wait + a.hysteresis * a.value_day) / COST_SCALE),   # wait
    -((c_rail  + delay_cost_rail)  / COST_SCALE) + a.beta,                                   # rail
    -((c_truck + delay_cost_truck) / COST_SCALE),                                            # truck
    -((c_mixed + delay_cost_mixed) / COST_SCALE) + 0.5 * a.beta,                             # mixed
    (
        -((c_polb + delay_cost_polb) / COST_SCALE)
        + 0.3 * a.beta
        + POLB_UTILITY_BONUS          # <-- THIS is your knob (dimensionless)
        + POLB_BONUS_MUSD             # keep if you want it too
    ) if enable_polb else -1e30,                                                             # POLB
], dtype=float)

            z = (u / max(TEMP, 1e-12)) + np.random.gumbel(size=5)
            z -= np.nanmax(z)
            p  = np.exp(z)
            p /= np.nansum(p) if np.isfinite(np.nansum(p)) and np.nansum(p) > 0 else 5.0
            mode = int(np.argmax(p))
            a.mode_history.append(mode)
            if enable_polb and mode == 4:
                polb_choices += 1
                polb_diverted_this_week += float(tons_week)
            # -------------------------- MODE-SENSITIVE OUTPUT LOSS --------------------------
            delay_weeks = [delay_wait, delay_rail, delay_truck, delay_mixed, delay_polb][mode]

            inventory_ratio  = min(delay_weeks / max(a.inv, 1e-9), 1.0)
            partial_loss     = inventory_ratio * 3.0 * a.value_day * 7.0

            if delay_weeks <= a.inv:
                lost_output_week = partial_loss
            else:
                lost_output_week = partial_loss + 2.0 * (delay_weeks - a.inv) * a.value_day * 7.0

            # Optional: include *incremental* logistics cost as part of “economic loss”
            LOG_PENALTY_W = float(policy.get("logistics_penalty_weight", 0.0))
            chosen_log_cost = [0.0, c_rail, c_truck, c_mixed, c_polb][mode]
            best_alt_cost   = min([c_rail, c_truck, c_mixed] + ([c_polb] if enable_polb else []))
            log_penalty     = max(0.0, chosen_log_cost - best_alt_cost)

            weekly_losses[i] = LOSS_MULT * (lost_output_week + cong_pen + LOG_PENALTY_W * log_penalty)

            # -------------------------- LOAD ACCUMULATION (FIXED) --------------------------
            # POLA terminal throughput is consumed by ANY POLA-serving option.
            # If you don't do this, POLA never congests and POLB can’t matter.
            POLA_TERM_FACTOR = float(policy.get("pola_terminal_load_factor", 1.0))
            POLB_TERM_FACTOR = float(policy.get("polb_terminal_load_factor", 1.0))

            if mode in (0, 1, 2, 3):  # wait/rail/truck/mixed all still require POLA terminal handling
                load_port += POLA_TERM_FACTOR * tons_week

            # inland capacity usage
            if mode == 1:  # rail
                load_rail += tons_week * np.random.uniform(0.85, 1.15)

            elif mode == 2:  # truck
                # optional: if you want truck to also saturate, keep truck_delay separate (you already do)
                pass

            elif mode == 3:  # mixed
                split = np.clip(
                    0.4 + 0.2 * np.sin(2 * np.pi * w / 4) + np.random.normal(0, 0.1),
                    0.2, 0.7
                )
                # mixed uses some rail
                load_rail += (1 - split) * tons_week

            elif enable_polb and mode == 4:  # POLB
                load_polb += POLB_TERM_FACTOR * tons_week * np.random.uniform(0.90, 1.10)

                # MOST POLB diversion will still go inland by rail — make that explicit
                POLB_RAIL_SHARE = float(policy.get("polb_rail_share", 0.70))
                load_rail += (POLB_RAIL_SHARE * tons_week) * np.random.uniform(0.85, 1.15)

                # small spillback to POLA (optional, keep tiny)
                load_port += 0.02 * tons_week
            # -------------------------------------------------------------------------------

        port_load_prev = load_port
        rail_load_prev = load_rail
        polb_load_prev = load_polb

        if load_polb > polb_cap and saturation_week == n_weeks + 1:
            saturation_week = w + 1

        peak_unserved = max(peak_unserved, unserved_week)
        diag_modes.append([a.mode_history[-1] for a in agents])
        diag_costs.append(weekly_losses.copy())
        diag_cong.append([load_port, load_rail, load_polb])
        polb_diverted_tons_weekly.append(float(polb_diverted_this_week))
        polb_mode_share_weekly.append(float(polb_choices) / max(len(agents), 1))

    df_modes_sw = pd.DataFrame(diag_modes, columns=sectors)
    df_costs_sw = pd.DataFrame(diag_costs, columns=sectors)
    df_cong_sw  = pd.DataFrame(diag_cong,  columns=["port_load", "rail_load", "polb_load"])

    print(f"\n[Port-Switching] POLB saturation week : {'never' if saturation_week > n_weeks else saturation_week}")
    print(f"[Port-Switching] Peak unserved demand : {peak_unserved:,.1f} t/week")
    print(f"[Port-Switching] Mean weekly loss ($) : {df_costs_sw.sum(axis=1).mean():,.0f}")
    mean_polb_share = float(np.mean(polb_mode_share_weekly)) if len(polb_mode_share_weekly) else 0.0
    mean_polb_div   = float(np.mean(polb_diverted_tons_weekly)) if len(polb_diverted_tons_weekly) else 0.0
    print(f"[Port-Switching] Mean POLB mode share : {100.0*mean_polb_share:.2f}%")
    print(f"[Port-Switching] Mean POLB diverted  : {mean_polb_div:,.0f} tons/week")

    # Sector losses + MRIIM (same leakage corrections as run_abm for comparability)
    sector_loss_sw = pd.Series(
        df_costs_sw.sum(axis=0).values / 1e6, index=sectors, name="SW_sector_loss_musd"
    ).sort_values(ascending=False)

    baseline_gdp = gdp_df.sum(axis=0); baseline_gdp /= baseline_gdp.sum()
    sector_loss_sw = (1 - 0.12) * sector_loss_sw + 0.12 * sector_loss_sw.sum() * baseline_gdp
    total_sw       = sector_loss_sw.sum()
    sector_loss_sw = (1 - 0.08) * sector_loss_sw + 0.08 * total_sw * (sector_loss_sw / sector_loss_sw.sum())

    faf_raw = faf_raw.copy()
    faf_raw["dest_state"] = faf_raw["dms_dest_i"].apply(lambda x: faf_dms_to_state(x) if x > 0 else None)
    faf_raw["orig_state"] = faf_raw["dms_orig_i"].apply(lambda x: faf_dms_to_state(x) if x > 0 else None)
    out_df = faf_raw[faf_raw["direction"] == "outbound"]
    in_df  = faf_raw[faf_raw["direction"] == "inbound"]

    exp_out = out_df.groupby(["dest_state","sector"])["value_day"].sum().unstack(fill_value=0).reindex(index=STATES, columns=sectors).fillna(0.0)
    exp_in  = in_df.groupby(["orig_state", "sector"])["value_day"].sum().unstack(fill_value=0).reindex(index=STATES, columns=sectors).fillna(0.0)
    exposure_sw = exp_out.add(exp_in, fill_value=0.0)

    w_gdp = gdp_df.div(gdp_df.sum(axis=0).replace(0, np.nan), axis=1).fillna(0.0)
    w_faf = (exposure_sw.div(exposure_sw.sum(axis=0).replace(0, np.nan), axis=1).fillna(0.0) + 0.02)
    w_faf = w_faf.div(w_faf.sum(axis=0).replace(0, np.nan), axis=1).fillna(0.0)
    w_sw  = (1.6 * w_gdp + w_faf)
    w_sw  = w_sw.div(w_sw.sum(axis=0).replace(0, np.nan), axis=1).fillna(0.0)
    w_sw  = w_sw.reindex(columns=sector_loss_sw.index, fill_value=0.0)
    matrix_sw = w_sw.mul(sector_loss_sw.values, axis=1)

    mriim_out_sw     = run_mriim_with_external_shock(matrix_sw, gdp_df)
    mriim_df_sw      = mriim_out_sw.reset_index(); mriim_df_sw.columns = ["state","sector","loss"]
    mriim_matrix_sw  = (mriim_df_sw.pivot(index="state", columns="sector", values="loss")
                        .reindex(index=STATES, columns=sectors).fillna(0.0))

    return {
        "costs_sw":        df_costs_sw,
        "congestion_sw":   df_cong_sw,
        "modes_sw":        df_modes_sw,
        "sector_loss_sw":  sector_loss_sw,
        "mriim_matrix_sw": mriim_matrix_sw,
        "saturation_week": saturation_week,
        "polb_diverted_tons_weekly": np.array(polb_diverted_tons_weekly, dtype=float),
        "polb_mode_share_weekly":    np.array(polb_mode_share_weekly, dtype=float),
        "peak_unserved":   peak_unserved,
        "meta_sw": {
    "pola_capacity_reduction": float(pola_capacity_reduction),  # fraction removed
    "polb_cap": float(polb_cap),
    "pola_cap_effective": float(pola_cap_sw),
    "n_weeks": int(n_weeks),
    "seed": int(seed),
    "blocked_const_weeks": float(blocked_const_weeks),
    "blocked_source": "series" if blocked_series is not None else "const",
},
    }


def compare_port_switching(
    baseline_results,
    switching_results,
    out_dir=None,
    *,
    diff_mode: str = "symlog",   # {"symlog","pct","raw"}
    pct_clip: float = 0.50,      # for pct mode: clip to ±50%
):
    """
    Build §5.6 Table 3 and produce Figures 9–11.

    Figure 9  — weekly national loss: baseline vs. switching
    Figure 10 — POLB cumulative load vs. POLB_CAP (saturation timeline)
    Figure 11 — MRIIM loss differential heatmap (switching − baseline)

    Returns pd.DataFrame — the Table 3 summary.
    """
    base_costs  = baseline_results["costs"]
    sw_costs    = switching_results["costs_sw"]
    base_mriim  = baseline_results["mriim_matrix"]
    sw_mriim    = switching_results["mriim_matrix_sw"]
    base_sec    = baseline_results["abm_sector_loss"]
    sw_sec      = switching_results["sector_loss_sw"]
    sw_cong     = switching_results["congestion_sw"]
    sat_wk      = switching_results["saturation_week"]
    peak_uns    = switching_results["peak_unserved"]
    meta_sw     = switching_results["meta_sw"]
    n_weeks     = len(base_costs)

    base_weekly       = base_costs.sum(axis=1) / 1e6
    sw_weekly         = sw_costs.sum(axis=1)   / 1e6
    base_total        = float(base_sec.sum())
    sw_total          = float(sw_sec.sum())
    loss_diff         = sw_total - base_total
    loss_diff_pct     = 100.0 * loss_diff / max(base_total, 1e-9)
    base_mriim_total  = float(base_mriim.values.sum())
    sw_mriim_total    = float(sw_mriim.values.sum())
    mriim_diff_pct    = 100.0 * (sw_mriim_total - base_mriim_total) / max(base_mriim_total, 1e-9)
    sec_diff          = (sw_sec - base_sec).sort_values(ascending=False)
    sev_pct = int(float(meta_sw["pola_capacity_reduction"]) * 100)
    polb_div = switching_results.get("polb_diverted_tons_weekly", None)
    polb_shr = switching_results.get("polb_mode_share_weekly", None)

    mean_polb_div = float(np.mean(polb_div)) if polb_div is not None and len(polb_div) else 0.0
    peak_polb_div = float(np.max(polb_div))  if polb_div is not None and len(polb_div) else 0.0
    mean_polb_shr = float(np.mean(polb_shr)) if polb_shr is not None and len(polb_shr) else 0.0
    rows = [
    {"Metric": "POLA capacity reduction",                  "Baseline": "—",                        "POLB switching": f"{sev_pct}%"},
    {"Metric": "POLB effective capacity (t/week)",         "Baseline": "—",                        "POLB switching": f"{meta_sw['polb_cap']:,.0f}"},

    # ✅ ADD THESE THREE LINES (right here)
    {"Metric": "Mean POLB mode share",               "Baseline": "0%", "POLB switching": f"{100.0*mean_polb_shr:.2f}%"},
    {"Metric": "Mean POLB diverted volume (t/week)", "Baseline": "0",  "POLB switching": f"{mean_polb_div:,.0f}"},
    {"Metric": "Peak POLB diverted volume (t/week)", "Baseline": "0",  "POLB switching": f"{peak_polb_div:,.0f}"},

    {"Metric": "POLB saturation week",                     "Baseline": "N/A",                      "POLB switching": "Never" if sat_wk > n_weeks else str(sat_wk)},
    {"Metric": "Peak unserved demand (t/week)",            "Baseline": "0",                        "POLB switching": f"{peak_uns:,.0f}"},
    {"Metric": "Total ABM sector loss (M$)",               "Baseline": f"{base_total:.1f}",        "POLB switching": f"{sw_total:.1f}"},
    {"Metric": "Change in total sector loss",              "Baseline": "—",                        "POLB switching": f"{loss_diff:+.1f} M$  ({loss_diff_pct:+.1f}%)"},
    {"Metric": "Total MRIIM national output loss (M$)",    "Baseline": f"{base_mriim_total:.1f}",  "POLB switching": f"{sw_mriim_total:.1f}"},
    {"Metric": "Change in MRIIM output loss",              "Baseline": "—",                        "POLB switching": f"{sw_mriim_total - base_mriim_total:+.1f} M$  ({mriim_diff_pct:+.1f}%)"},
    {"Metric": "Sector most affected by switching",        "Baseline": str(base_sec.index[0]),     "POLB switching": str(sec_diff.index[0])},
]
    table3 = pd.DataFrame(rows)

    print("\n" + "=" * 66)
    print("PORT-SWITCHING COMPARISON — §5.6 Table 3")
    print("=" * 66)
    print(table3.to_string(index=False))
    print("=" * 66)

    if out_dir is None:
        return table3

    os.makedirs(out_dir, exist_ok=True)
    weeks = np.arange(1, n_weeks + 1)

    # Figure 9 — weekly loss trajectories + delta panel
    fig, (ax1, ax2) = plt.subplots(nrows=2, ncols=1, figsize=(12, 7), sharex=True)

    ax1.plot(weeks, base_weekly.values, lw=2, label="Baseline (no switching)")
    ax1.plot(weeks, sw_weekly.values,   lw=2, ls="--", label=f"POLB switching (POLA –{sev_pct}%)")
    if sat_wk <= n_weeks:
        ax1.axvline(sat_wk, ls=":", lw=1.5, label=f"POLB saturation (week {sat_wk})")
    ax1.set_ylabel("National output loss (M$)")
    ax1.set_title("Figure 9 — Weekly national output loss (top) and Δloss (bottom)")
    ax1.grid(alpha=0.3)
    ax1.legend(fontsize=9)

    delta = (sw_weekly - base_weekly).values
    ax2.plot(weeks, delta, lw=2)
    ax2.axhline(0.0, lw=1.0, ls="--", alpha=0.6)
    if sat_wk <= n_weeks:
        ax2.axvline(sat_wk, ls=":", lw=1.5)
    ax2.set_xlabel("Simulation week")
    ax2.set_ylabel("Δloss (M$)")
    ax2.grid(alpha=0.3)

    _savefig(os.path.join(out_dir, "fig09_port_switching_weekly_loss.png"))

    # Figure 10 — POLB diverted volume vs capacity
    polb_divert = switching_results.get("polb_diverted_tons_weekly", None)
    if polb_divert is None or len(polb_divert) != n_weeks:
        # fallback to old behavior, but keep label honest
        polb_divert = sw_cong["polb_load"].values.astype(float)

    fig, ax = plt.subplots(figsize=(12, 4))
    ax.fill_between(weeks, polb_divert, alpha=0.35, label="POLB diverted volume (tons/week)")
    ax.axhline(POLB_CAP, lw=1.5, ls="--", label=f"POLB capacity ({POLB_CAP:,.0f} tons/week)")
    if sat_wk <= n_weeks:
        ax.axvline(sat_wk, ls=":", lw=1.5, label=f"Saturation week {sat_wk}")
    ax.set_xlabel("Simulation week")
    ax.set_ylabel("Tons/week")
    ax.set_title("Figure 10 — POLB diverted volume and capacity ceiling")
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3)
    _savefig(os.path.join(out_dir, "fig10_polb_load_saturation.png"))

    # Figure 11 — differential heatmap (switching − baseline)
    D = (sw_mriim - base_mriim).values.astype(float)

    fig, ax = plt.subplots(figsize=(15, 10))

    if diff_mode == "pct":
        # percent-change relative to baseline magnitude
        B = base_mriim.values.astype(float)
        eps = 1e-9
        P = D / (np.abs(B) + eps)
        P = np.clip(P, -pct_clip, pct_clip)
        im = ax.imshow(P, aspect="auto", cmap="RdBu_r", vmin=-pct_clip, vmax=pct_clip)
        cbar = plt.colorbar(im, ax=ax, fraction=0.03)
        cbar.set_label(f"Δ / |baseline| (clipped ±{int(100*pct_clip)}%)")

    elif diff_mode == "raw":
        vabs = float(np.nanmax(np.abs(D))) if np.isfinite(D).any() else 1.0
        vabs = max(vabs, 1e-9)
        im = ax.imshow(D, aspect="auto", cmap="RdBu_r", vmin=-vabs, vmax=vabs)
        cbar = plt.colorbar(im, ax=ax, fraction=0.03)
        cbar.set_label("Δ loss (M$)")

    else:
        # symlog: reveals small structure + preserves big outliers
        absD = np.abs(D[np.isfinite(D)])
        if absD.size == 0:
            linthresh = 1e-6
            vmax = 1.0
        else:
            linthresh = float(np.percentile(absD, 60)) * 0.1
            linthresh = max(linthresh, 1e-6)
            vmax = float(np.percentile(absD, 99))
            vmax = max(vmax, linthresh * 10)

        norm = SymLogNorm(linthresh=linthresh, vmin=-vmax, vmax=vmax, base=10)
        im = ax.imshow(D, aspect="auto", cmap="RdBu_r", norm=norm)
        cbar = plt.colorbar(im, ax=ax, fraction=0.03)
        cbar.set_label(f"Δ loss (M$), symlog (linthresh={linthresh:.2g})")

    ax.set_title("Figure 11 — MRIIM loss differential: POLB switching − baseline")
    ax.set_xlabel("Sector")
    ax.set_ylabel("State")
    ax.set_yticks(np.arange(len(sw_mriim.index)))
    ax.set_yticklabels(sw_mriim.index, fontsize=7)
    ax.set_xticks(np.arange(len(sw_mriim.columns)))
    ax.set_xticklabels(np.arange(1, len(sw_mriim.columns) + 1))
    plt.tight_layout()
    fig.savefig(os.path.join(out_dir, "fig11_differential_heatmap.png"), dpi=200)
    plt.close(fig)

    # Save Table 3 to Excel
    xl_path = os.path.join(out_dir, "Table3_Port_Switching_Comparison.xlsx")
    with pd.ExcelWriter(xl_path, engine="xlsxwriter") as writer:
        table3.to_excel(writer, sheet_name="Table3_Summary", index=False)
        sec_diff.rename("loss_diff_musd").to_frame().to_excel(writer, sheet_name="Sector_Differential")
        (sw_mriim - base_mriim).to_excel(writer, sheet_name="MRIIM_Differential")
        pd.DataFrame({"week": weeks, "base_musd": base_weekly.values,
                      "sw_musd": sw_weekly.values, "polb_load": sw_cong["polb_load"].values,
                      }).to_excel(writer, sheet_name="Weekly_Trajectories", index=False)
    print(f"[Port-Switching] Table 3 saved → {xl_path}")


    return table3

def run_polb_switching_sweep(
    *,
    faf_raw,
    pola_dist_df,
    gdp_df,
    sectors,
    tons,
    vals,
    sector_dist_pola,
    blocked_series,
    out_dir,
    severities=(0.25, 0.50, 0.75),
    seeds=(0, 1, 2, 3, 4),
    n_weeks=52,
    blocked_const_weeks=2.0,
    diff_mode="symlog",
    pct_clip=0.50,
    **policy,
) -> pd.DataFrame:
    """
    Runs paired (baseline no-POLB vs POLB-enabled) port-switching experiments
    over multiple severities and seeds. Each run writes its own Table3 + Figures
    in a subfolder: <out_dir>/sevXX/seedYY/

    Returns a tidy summary DataFrame and also writes:
      - polb_switching_sweep_summary.csv
      - polb_switching_frontier.png
    """
    out_dir = str(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    # sanitize inputs
    severities = [float(s) for s in severities]
    seeds = [int(s) for s in seeds]
    n_weeks = int(n_weeks)
    blocked_const_weeks = float(blocked_const_weeks)

    records = []

    for sev in severities:
        sev_tag = f"sev{int(round(sev * 100)):02d}"
        for sd in seeds:
            seed_tag = f"seed{sd}"
            run_dir = os.path.join(out_dir, sev_tag, seed_tag)
            os.makedirs(run_dir, exist_ok=True)

            # baseline: same severity/shock, but NO POLB option
            base = run_port_switching_scenario(
                faf_raw=faf_raw,
                pola_dist_df=pola_dist_df,
                gdp_df=gdp_df,
                sectors=sectors,
                tons=tons,
                vals=vals,
                sector_dist_pola=sector_dist_pola,
                n_weeks=n_weeks,
                pola_capacity_reduction=sev,
                blocked_series=blocked_series,
                blocked_const_weeks=blocked_const_weeks,
                enable_polb=False,
                seed=sd,
                **policy,
            )

            # switching: same severity/shock, POLB enabled
            sw = run_port_switching_scenario(
                faf_raw=faf_raw,
                pola_dist_df=pola_dist_df,
                gdp_df=gdp_df,
                sectors=sectors,
                tons=tons,
                vals=vals,
                sector_dist_pola=sector_dist_pola,
                n_weeks=n_weeks,
                pola_capacity_reduction=sev,
                blocked_series=blocked_series,
                blocked_const_weeks=blocked_const_weeks,
                enable_polb=True,
                seed=sd,
                **policy,
            )

            baseline_results = {
                "costs": base["costs_sw"],
                "mriim_matrix": base["mriim_matrix_sw"],
                "abm_sector_loss": base["sector_loss_sw"],
            }

            # per-run outputs (Table3 + Figures) into subfolder
            _ = compare_port_switching(
                baseline_results=baseline_results,
                switching_results=sw,
                out_dir=run_dir,
                diff_mode=diff_mode,
                pct_clip=pct_clip,
            )

            base_total = float(base["sector_loss_sw"].sum())
            sw_total = float(sw["sector_loss_sw"].sum())

            polb_share = sw.get("polb_mode_share_weekly", np.array([], dtype=float))
            polb_div = sw.get("polb_diverted_tons_weekly", np.array([], dtype=float))
            mean_polb_share = float(np.mean(polb_share)) if len(polb_share) else 0.0
            mean_polb_div = float(np.mean(polb_div)) if len(polb_div) else 0.0

            sat_wk = int(sw.get("saturation_week", n_weeks + 1))
            sat_wk = sat_wk if sat_wk <= n_weeks else (n_weeks + 1)

            records.append({
                "severity": sev,
                "seed": sd,
                "base_total_loss_musd": base_total,
                "sw_total_loss_musd": sw_total,
                "delta_loss_musd": sw_total - base_total,
                "delta_loss_pct": 100.0 * (sw_total - base_total) / max(base_total, 1e-9),
                "mean_polb_share_pct": 100.0 * mean_polb_share,
                "mean_polb_divert_tons_week": mean_polb_div,
                "saturation_week": sat_wk,
                "run_dir": run_dir,
            })

    df = pd.DataFrame(records)
    df.to_csv(os.path.join(out_dir, "polb_switching_sweep_summary.csv"), index=False)

    # simple frontier plot (mean across seeds)
    grp = df.groupby("severity", as_index=False).agg({
        "delta_loss_musd": "mean",
        "mean_polb_share_pct": "mean",
        "mean_polb_divert_tons_week": "mean",
    })

    fig, ax1 = plt.subplots(figsize=(10.5, 5.5))
    ax1.plot(grp["severity"] * 100.0, grp["delta_loss_musd"], lw=2, marker="o")
    ax1.axhline(0.0, lw=1.0, ls="--", alpha=0.6)
    ax1.set_xlabel("POLA capacity reduction (%)")
    ax1.set_ylabel("Mean Δloss (M$)  [switching − baseline]")
    ax1.grid(alpha=0.3)

    ax2 = ax1.twinx()
    ax2.plot(grp["severity"] * 100.0, grp["mean_polb_share_pct"], lw=2, ls="--", marker="s")
    ax2.set_ylabel("Mean POLB mode share (%)")

    plt.title("POLB switching sweep: Δloss and POLB uptake vs severity")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "polb_switching_frontier.png"), dpi=200)
    plt.close(fig)

    return df