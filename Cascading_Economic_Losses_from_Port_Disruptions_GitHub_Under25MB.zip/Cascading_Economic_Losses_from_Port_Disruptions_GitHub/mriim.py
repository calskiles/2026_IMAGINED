import numpy as np
import pandas as pd

_MRIIM_INITIALIZED = False
A_H = None
L_df = None
trade_share = None

sector_names = [
    "Agriculture, forestry, fishing, and hunting","Mining","Utilities","Construction","Manufacturing",
    "Wholesale trade","Retail trade","Transportation and warehousing","Information",
    "Finance, insurance, real estate, rental, and leasing","Professional and business services",
    "Educational services, health care, and social assistance",
    "Arts, entertainment, recreation, accommodation, and food services","Other services, except government","Government"
]

PROD39_TO_SECTOR15 = {
    "Farms":"Agriculture, forestry, fishing, and hunting",
    "Forestry, fishing, and related activities":"Agriculture, forestry, fishing, and hunting",
    "Mining":"Mining",
    "Utilities":"Utilities",
    "Construction":"Construction",
    "Manufacturing":"Manufacturing",
    "Wholesale trade":"Wholesale trade",
    "Retail trade":"Retail trade",
    "Transportation and warehousing":"Transportation and warehousing",
    "Information":"Information",
    "Finance and insurance":"Finance, insurance, real estate, rental, and leasing",
    "Real estate and rental and leasing":"Finance, insurance, real estate, rental, and leasing",
    "Professional, scientific, and technical services":"Professional and business services",
    "Management of companies and enterprises":"Professional and business services",
    "Administrative and waste management services":"Professional and business services",
    "Educational services":"Educational services, health care, and social assistance",
    "Health care and social assistance":"Educational services, health care, and social assistance",
    "Arts, entertainment, and recreation":"Arts, entertainment, recreation, accommodation, and food services",
    "Accommodation and food services":"Arts, entertainment, recreation, accommodation, and food services",
    "Other services, except government":"Other services, except government",
    "Federal government":"Government",
    "State and local government":"Government"
}

SERVICE_TO_SECTOR15 = {
    "Construction":"Construction",
    "Wholesale trade":"Wholesale trade",
    "Transportation services":"Transportation and warehousing",
    "Warehousing and storage":"Transportation and warehousing",
    "Information":"Information",
    "Finance, insurance, real estate, rental, and leasing":"Finance, insurance, real estate, rental, and leasing",
    "Professional and business services":"Professional and business services",
    "Educational services, health care, and social assistance":"Educational services, health care, and social assistance",
    "Arts, entertainment, recreation, accommodation, and food services":"Arts, entertainment, recreation, accommodation, and food services",
    "Other services, except government":"Other services, except government",
    "Government":"Government"
}

CONTIG48 = [
    "AL","AZ","AR","CA","CO","CT","DE","FL","GA","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA",
    "MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC",
    "SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"
]

_dms_map = {
    "01":"AL","02":"AK","04":"AZ","05":"AR","06":"CA","08":"CO","09":"CT","10":"DE","11":"DC","12":"FL","13":"GA",
    "15":"HI","16":"ID","17":"IL","18":"IN","19":"IA","20":"KS","21":"KY","22":"LA","23":"ME","24":"MD","25":"MA",
    "26":"MI","27":"MN","28":"MS","29":"MO","30":"MT","31":"NE","32":"NV","33":"NH","34":"NJ","35":"NM","36":"NY",
    "37":"NC","38":"ND","39":"OH","40":"OK","41":"OR","42":"PA","44":"RI","45":"SC","46":"SD","47":"TN","48":"TX",
    "49":"UT","50":"VT","51":"VA","53":"WA","54":"WV","55":"WI","56":"WY"
}

def map_sctg2_to_sector15(sctg_code: str) -> str:
    i = int(str(sctg_code).strip())
    if 1 <= i <= 9:
        return "Agriculture, forestry, fishing, and hunting"
    if 10 <= i <= 16:
        return "Mining"
    if 17 <= i <= 40:
        return "Manufacturing"
    if i == 41:
        return "Utilities"
    if i == 42:
        return "Transportation and warehousing"
    if i == 43:
        return "Wholesale trade"
    return "Manufacturing"

def dms_to_state(dms):
    d = str(dms).zfill(2)
    return _dms_map.get(d, None)

MAP_TO_15 = {**PROD39_TO_SECTOR15, **SERVICE_TO_SECTOR15}
for s in sector_names:
    MAP_TO_15.setdefault(s, s)

def _read_42square(path: str, sheet: str) -> pd.DataFrame:
    raw = pd.read_excel(path, sheet_name=sheet, header=None)

    # Find the header row (row where column 1 == "Name")
    header_row = None
    for i in range(len(raw)):
        if str(raw.iloc[i, 1]).strip() == "Name":
            header_row = i
            break

    if header_row is None:
        raise ValueError("Could not locate header row with 'Name' in BEA Use/Make table.")

    # Column names come from the header row
    col_names = raw.iloc[header_row, :].astype(str).str.strip().values

    # Data starts one row below
    data = raw.iloc[header_row + 1 :, :].copy()
    data.columns = col_names

    # First column is sector code, second is sector name
    sector_name_col = col_names[1]
    data[sector_name_col] = data[sector_name_col].astype(str).str.strip()
    data = data.set_index(sector_name_col)

    # Drop non-numeric columns (sector codes etc.)
    data = data.iloc[:, 1:]

    # Convert to numeric
    data = data.apply(pd.to_numeric, errors="coerce").fillna(0.0)

    if np.allclose(data.values, 0.0):
        raise ValueError("Parsed Use/Make matrix is all zeros after BEA extraction.")

    return data


def _aggregate_any_to_15(square_df: pd.DataFrame) -> pd.DataFrame:
    rmap = square_df.index.to_series().map(MAP_TO_15).dropna()
    cols = [c for c in square_df.columns if c in MAP_TO_15]
    cmap = pd.Series({c: MAP_TO_15[c] for c in cols})
    sq = square_df.loc[rmap.index, cols].copy()
    sq["__row__"] = rmap.values
    g_rows = sq.groupby("__row__", as_index=True).sum()
    g_rows.columns = [cmap[c] for c in g_rows.columns]
    out = g_rows.groupby(level=0, axis=1).sum()
    out = out.reindex(index=sector_names, columns=sector_names).fillna(0.0)
    return out

def build_national_A(use42_path: str, make42_path: str, sheet42: str):
    use_src = _read_42square(use42_path, sheet42)
    make_src = _read_42square(make42_path, sheet42)

    use15 = _aggregate_any_to_15(use_src)
    make15 = _aggregate_any_to_15(make_src)

    x = make15.sum(axis=0)
    A = use15.div(x.replace(0, np.nan), axis=1)
    A = A.replace([np.inf, -np.inf], 0.0).fillna(0.0)

    if np.allclose(A.values, 0.0):
        raise ValueError("A_national computed as all zeros. Check Use/Make table extraction and labels.")

    return {
        "use_matrix": use15,
        "make_matrix": make15,
        "A_national": A,
        "total_output": x
    }
def map_faf_zone_to_states():
    faf_map = {
        11: ["AL"], 12: ["AL"], 19: ["AL"],
        20: ["AK"],
        41: ["AZ"], 42: ["AZ"], 49: ["AZ"],
        50: ["AR"],
        61: ["CA"], 62: ["CA"], 63: ["CA"], 64: ["CA"], 65: ["CA"], 69: ["CA"],
        81: ["CO"], 89: ["CO"],
        91: ["CT"], 92: ["CT", "NY", "NJ", "PA"], 99: ["CT"],
        101: ["DE", "PA", "NJ", "MD"], 109: ["DE"],
        111: ["DC", "VA", "MD", "WV"],
        121: ["FL", "GA"], 122: ["FL"], 123: ["FL"], 124: ["FL"], 129: ["FL"],
        131: ["GA"], 132: ["GA"], 139: ["GA"],
        151: ["HI"], 159: ["HI"],
        160: ["ID"],
        171: ["IL", "IN", "WI"], 172: ["IL", "MO"], 179: ["IL"],
        181: ["IN", "IL", "WI"], 182: ["IN"], 183: ["IN"], 189: ["IN"],
        190: ["IA"],
        201: ["KS", "MO"], 202: ["KS"], 209: ["KS"],
        211: ["KY", "OH", "IN"], 212: ["KY", "IN"], 219: ["KY"],
        221: ["LA"], 222: ["LA"], 223: ["LA", "MS"], 229: ["LA"],
        230: ["ME"],
        241: ["MD"], 242: ["MD", "DC", "VA", "WV"], 249: ["MD"],
        251: ["MA", "RI", "NH", "CT"], 259: ["MA"],
        261: ["MI"], 262: ["MI"], 269: ["MI"],
        271: ["MN", "WI"], 279: ["MN"],
        280: ["MS"],
        291: ["MO", "KS"], 292: ["MO", "IL"], 299: ["MO"],
        300: ["MT"],
        311: ["NE", "IA"], 319: ["NE"],
        321: ["NV", "AZ"], 329: ["NV"],
        331: ["NH", "MA", "RI", "CT"], 339: ["NH"],
        341: ["NJ", "NY", "CT", "PA"], 342: ["NJ", "PA", "DE", "MD"],
        350: ["NM"],
        361: ["NY"], 362: ["NY"], 363: ["NY", "NJ", "CT", "PA"], 364: ["NY"], 369: ["NY"],
        371: ["NC", "SC"], 372: ["NC"], 373: ["NC"], 379: ["NC"],
        380: ["ND"],
        391: ["OH", "KY", "IN"], 392: ["OH"], 393: ["OH"], 394: ["OH"], 399: ["OH"],
        401: ["OK"], 402: ["OK"], 409: ["OK"],
        411: ["OR", "WA"], 419: ["OR"],
        421: ["PA", "NJ", "DE", "MD"], 422: ["PA", "OH", "WV"], 423: ["PA", "NY", "NJ", "CT"], 429: ["PA"],
        441: ["RI", "MA", "NH", "CT"],
        451: ["SC"], 452: ["SC"], 459: ["SC"],
        460: ["SD"],
        471: ["TN", "MS", "AR"], 472: ["TN"], 473: ["TN"], 479: ["TN"],
        481: ["TX"], 482: ["TX"], 483: ["TX"], 484: ["TX", "OK"], 485: ["TX", "NM"],
        486: ["TX"], 487: ["TX"], 488: ["TX"], 489: ["TX"],
        491: ["UT"], 499: ["UT"],
        500: ["VT"],
        511: ["VA"], 512: ["VA", "NC"], 513: ["VA", "DC", "MD", "WV"], 519: ["VA"],
        531: ["WA"], 532: ["WA", "OR"], 539: ["WA"],
        540: ["WV"],
        551: ["WI"], 559: ["WI"],
        560: ["WY"],
    }
    return faf_map

def build_trade_share_from_faf(
    faf_path: str,
    state_list: list,
    run_diagnostics: bool = False
):
    df = pd.read_csv(faf_path)

    if "dms_orig" not in df.columns or "dms_dest" not in df.columns:
        raise ValueError("FAF file must contain dms_orig and dms_dest columns")

    value_candidates = [
        "value_2024",
        "current_value_2024",
    ] + sorted(
        [c for c in df.columns if c.startswith("value_")],
        key=lambda x: int(x.split("_")[1]),
        reverse=True
    )

    val_col = next((c for c in value_candidates if c in df.columns), None)
    if val_col is None:
        raise ValueError("No usable FAF value column found")

    df = df[["dms_orig", "dms_dest", val_col]].copy()
    df[val_col] = pd.to_numeric(df[val_col], errors="coerce").fillna(0.0)

    faf_zone_map = map_faf_zone_to_states()

    records = []

    for o, d, v in df.itertuples(index=False):
        o = int(o)
        d = int(d)

        if o not in faf_zone_map or d not in faf_zone_map:
            continue

        o_states = faf_zone_map[o]
        d_states = faf_zone_map[d]

        w = v / (len(o_states) * len(d_states))

        for os in o_states:
            for ds in d_states:
                if os in state_list and ds in state_list:
                    records.append((os, ds, w))

    if not records:
        raise ValueError("FAF aggregation produced zero valid state flows")

    flow = (
        pd.DataFrame(records, columns=["orig_state", "dest_state", "v"])
        .groupby(["orig_state", "dest_state"], as_index=False)["v"]
        .sum()
    )

    M = (
        flow.pivot(index="orig_state", columns="dest_state", values="v")
        .reindex(index=state_list, columns=state_list)
        .fillna(0.0)
    )

    col_sums = M.sum(axis=0)
    if np.allclose(col_sums.values, 0.0):
        raise ValueError("All destination columns are zero after FAF aggregation")

    trade_share = M.div(col_sums.replace(0.0, np.nan), axis=1).fillna(0.0)

    if run_diagnostics:
        print("=== TRADE SHARE DIAGNOSTICS (FAF FIXED) ===")
        print("value column:", val_col)
        print("nonzeros:", int((trade_share.values != 0).sum()))
        print("colsum min/max:",
              float(trade_share.sum(axis=0).min()),
              float(trade_share.sum(axis=0).max()))
        diag = np.diag(trade_share.values)
        print("diag min/mean/max:",
              float(diag.min()),
              float(diag.mean()),
              float(diag.max()))

    return trade_share


def build_regional_IO(A_national: pd.DataFrame, gdp_df: pd.DataFrame, state_list: list, trade_share: pd.DataFrame, run_diagnostics: bool = False):
    gdp_df = gdp_df.reindex(index=state_list, columns=sector_names).fillna(0.0)

    if np.allclose(gdp_df.values, 0.0):
        raise ValueError("GDP table is all zeros after reindexing. Check gdp_df state/sector labels.")

    gdp_share = gdp_df.div(gdp_df.sum(axis=0).replace(0, np.nan), axis=1).fillna(0.0)

    if not isinstance(trade_share, pd.DataFrame):
        raise ValueError(f"trade_share must be DataFrame. Got {type(trade_share)}")

    if list(trade_share.index) != list(state_list) or list(trade_share.columns) != list(state_list):
        missing_rows = [s for s in state_list if s not in trade_share.index]
        missing_cols = [s for s in state_list if s not in trade_share.columns]
        raise ValueError(
            "trade_share labels do not match state_list.\n"
            f"missing rows: {missing_rows}\n"
            f"missing cols: {missing_cols}\n"
            f"trade_share index sample: {list(trade_share.index)[:10]}\n"
            f"trade_share cols  sample: {list(trade_share.columns)[:10]}\n"
            f"state_list sample: {state_list[:10]}"
        )

    blocks_rows = []
    for r in state_list:
        row_blocks = []
        for rp in state_list:
            w_scalar = float(trade_share.loc[rp, r])
            w_vec = w_scalar * gdp_share.loc[rp].values
            row_blocks.append(A_national.values * w_vec.reshape(1, -1))
        blocks_rows.append(row_blocks)

    A_big = np.block(blocks_rows)

    A_H_local = pd.DataFrame(
        A_big,
        index=pd.MultiIndex.from_product([state_list, sector_names]),
        columns=pd.MultiIndex.from_product([state_list, sector_names])
    )

    if not np.isfinite(A_H_local.values).all():
        raise ValueError("A_H contains invalid values (NaN/Inf).")

    max_AH = float(np.max(np.abs(A_H_local.values))) if A_H_local.size else 0.0
    sum_AH = float(np.sum(np.abs(A_H_local.values))) if A_H_local.size else 0.0

    if max_AH == 0.0 or sum_AH == 0.0:
        raise ValueError("A_H is all zeros. Likely trade_share or GDP weighting issue.")

    if run_diagnostics:
        try:
            rho_AH = float(np.max(np.abs(np.linalg.eigvals(A_H_local.values))))
        except Exception:
            rho_AH = float("nan")
        print("=== GDP/TRADE/A_H DIAGNOSTICS (inside build_regional_IO) ===")
        print("gdp_df shape:", gdp_df.shape)
        print("GDP total by sector min/max:", float(gdp_df.sum(axis=0).min()), float(gdp_df.sum(axis=0).max()))
        print("trade_share nonzeros:", int((trade_share.values != 0).sum()))
        print("trade_share colsum min/max:", float(trade_share.sum(axis=0).min()), float(trade_share.sum(axis=0).max()))
        print("A_H max_abs:", max_AH, "A_H abs_sum:", sum_AH, "rho(A_H):", rho_AH)

    return A_H_local

def leontief_inverse(A: pd.DataFrame) -> pd.DataFrame:
    I = np.eye(len(A))
    L = np.linalg.inv(I - A.values)
    return pd.DataFrame(L, index=A.index, columns=A.columns)

def apply_MRIIM_losses(L: pd.DataFrame, d: pd.Series) -> pd.Series:
    x = L.values @ d.reindex(L.index).fillna(0.0).values.reshape(-1, 1)
    return pd.Series(x.flatten(), index=L.index)

def print_L_diagnostics(L_df: pd.DataFrame):
    I = np.eye(L_df.shape[0])
    print("||L - I||_1:", float(np.linalg.norm(L_df.values - I, 1)))
    print("min/max L:", float(L_df.values.min()), float(L_df.values.max()))

def run_mriim_simple(shock_vector):
    global L_df, _MRIIM_INITIALIZED
    if not _MRIIM_INITIALIZED or L_df is None:
        raise RuntimeError("MRIIM not initialized. Call initialize_mriim() first.")
    shock = np.asarray(shock_vector).reshape(-1, 1)
    if shock.shape[0] != L_df.shape[0]:
        raise ValueError(f"Shock length {shock.shape[0]} does not match IO dimension {L_df.shape[0]}")
    loss = L_df.values @ shock
    return pd.Series(loss.flatten(), index=L_df.index, name="Output_Loss")

def initialize_mriim(use42_path, make42_path, sheet42, gdp_df, state_list, faf_path, run_diagnostics=True):
    global A_H, L_df, trade_share, _MRIIM_INITIALIZED

    if _MRIIM_INITIALIZED and (A_H is not None) and (L_df is not None) and (trade_share is not None):
        return {"A_H": A_H, "L_df": L_df, "trade_share": trade_share}

    nat = build_national_A(use42_path=use42_path, make42_path=make42_path, sheet42=sheet42)

    trade_share = build_trade_share_from_faf(
        faf_path=faf_path,
        state_list=state_list,
        run_diagnostics=run_diagnostics
    )

    A_H = build_regional_IO(
        A_national=nat["A_national"],
        gdp_df=gdp_df,
        state_list=state_list,
        trade_share=trade_share,
        run_diagnostics=run_diagnostics
    )

    if run_diagnostics:
        print("\n================ MRIIM INTERDEPENDENCY VALIDATION =================")

        A = A_H.values

        # (1) Column uniqueness (are columns identical?)
        col_norms = np.linalg.norm(A, axis=0)
        print("Unique column norms:", len(np.unique(np.round(col_norms, 6))))

        # (2) Pairwise column similarity (cosine distance)
        from scipy.spatial.distance import pdist
        d = pdist(A.T, metric="cosine")
        print("Cosine distance min / mean / max:",
              float(np.min(d)), float(np.mean(d)), float(np.max(d)))

        # (3) Interstate vs intrastate contribution for selected state–sector
        test_states = ["CA", "TX", "WY"]
        test_sector = "Manufacturing"

        for s in test_states:
            col = A_H.loc[:, (s, test_sector)]
            home = col.loc[(s, slice(None))].sum()
            foreign = col.sum() - home
            print(f"[{s}-{test_sector}] home share:",
                  float(home / col.sum()) if col.sum() > 0 else 0.0,
                  "foreign share:",
                  float(foreign / col.sum()) if col.sum() > 0 else 0.0)

        # (4) Trade-share heterogeneity check
        print("\nTop suppliers to CA (trade_share):")
        print(trade_share["CA"].sort_values(ascending=False).head(8))

        print("\nTop suppliers to TX (trade_share):")
        print(trade_share["TX"].sort_values(ascending=False).head(8))

        # (5) Structural sanity
        print("\nA_H diagnostics:")
        print("A_H max abs:", float(np.max(np.abs(A))))
        print("A_H abs sum:", float(np.sum(np.abs(A))))
        try:
            rho = float(np.max(np.abs(np.linalg.eigvals(A))))
        except Exception:
            rho = np.nan
        print("rho(A_H):", rho)

        print("================ END MRIIM VALIDATION =================\n")

    L_df = leontief_inverse(A_H)
    _MRIIM_INITIALIZED = True

    if run_diagnostics:
        print_L_diagnostics(L_df)


    return {"A_H": A_H, "L_df": L_df, "trade_share": trade_share}

if __name__ == "__main__":
    pass
