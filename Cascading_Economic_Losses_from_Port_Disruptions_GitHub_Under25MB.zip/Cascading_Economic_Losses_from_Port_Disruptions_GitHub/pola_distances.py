from pathlib import Path
# Optional network-generation inputs are not included; provide shapefiles under data/networks/.
# pola_distances.py
import pandas as pd
import numpy as np
import geopandas as gpd
import networkx as nx
from shapely.geometry import Point, LineString
from tqdm import tqdm

PATH_RAIL_NODES = str(Path(__file__).resolve().parent / "data" / "networks" / "North_American_Rail_Network_Nodes.shp")
PATH_RAIL_LINES = str(Path(__file__).resolve().parent / "data" / "networks" / "North_American_Rail_Network_Lines.shp")
PATH_WATER_NODES = str(Path(__file__).resolve().parent / "data" / "networks" / "Navigable_Waterway_Network_Nodes.shp")
PATH_WATER_LINES = str(Path(__file__).resolve().parent / "data" / "networks" / "Navigable_Waterway_Network_Lines.shp")
PATH_ROAD = str(Path(__file__).resolve().parent / "data" / "networks" / "North_American_Roads.shp")

def build_graph(lines, nodes):
    G = nx.Graph()
    coords = np.vstack([nodes.geometry.x.values, nodes.geometry.y.values]).T

    for geom in tqdm(lines.geometry, desc="   Building edges"):
        if isinstance(geom, LineString):
            xs, ys = geom.xy
            p1 = (xs[0], ys[0])
            p2 = (xs[-1], ys[-1])

            dx = coords[:,0] - p1[0]
            dy = coords[:,1] - p1[1]
            j1 = np.argmin(dx*dx + dy*dy)

            dx = coords[:,0] - p2[0]
            dy = coords[:,1] - p2[1]
            j2 = np.argmin(dx*dx + dy*dy)

            if j1 != j2:
                w = np.sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)
                G.add_edge(j1, j2, weight=w)
    return G


def snap_point_to_node(lon, lat, nodes):
    xs = nodes.geometry.x.values
    ys = nodes.geometry.y.values
    d2 = (xs - lon)**2 + (ys - lat)**2
    return int(np.argmin(d2))


def compute_pola_distances(city_df, save_path):
    """
    city_df columns: faf_code, lon, lat
    """

    print("Loading networks...")
    rail_nodes = gpd.read_file(PATH_RAIL_NODES)
    rail_lines = gpd.read_file(PATH_RAIL_LINES)
    w_nodes = gpd.read_file(PATH_WATER_NODES)
    w_lines = gpd.read_file(PATH_WATER_LINES)
    road = gpd.read_file(PATH_ROAD)

    print("Building rail network...")
    G_rail = build_graph(rail_lines, rail_nodes)

    print("Building waterway network...")
    G_water = build_graph(w_lines, w_nodes)

    print("Building highway network (node = line endpoints)...")
    road_nodes = road.copy()
    # Use each road line endpoint as a node
    xs, ys = [], []
    edges = []
    for geom in road.geometry:
        if isinstance(geom, LineString):
            x, y = geom.xy
            xs.extend([x[0], x[-1]])
            ys.extend([y[0], y[-1]])
            edges.append(((x[0], y[0]), (x[-1], y[-1])))

    road_node_df = pd.DataFrame({"lon": xs, "lat": ys})
    road_nodes_gdf = gpd.GeoDataFrame(road_node_df, geometry=gpd.points_from_xy(road_node_df.lon, road_node_df.lat))

    G_high = nx.Graph()
    coords = np.vstack([road_nodes_gdf.geometry.x.values, road_nodes_gdf.geometry.y.values]).T
    for (p1, p2) in edges:
        dx = coords[:,0] - p1[0]
        dy = coords[:,1] - p1[1]
        j1 = np.argmin(dx*dx + dy*dy)
        dx = coords[:,0] - p2[0]
        dy = coords[:,1] - p2[1]
        j2 = np.argmin(dx*dx + dy*dy)
        w = np.sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)
        G_high.add_edge(j1, j2, weight=w)

    # Port of LA location (DMS 061)
    POLA_lon = -118.2437
    POLA_lat = 34.0522

    rail_src = snap_point_to_node(POLA_lon, POLA_lat, rail_nodes)
    water_src = snap_point_to_node(POLA_lon, POLA_lat, w_nodes)
    high_src = snap_point_to_node(POLA_lon, POLA_lat, road_nodes_gdf)

    result = []

    print("Computing distances POLA → all FAF city centers...")
    for _, row in city_df.iterrows():
        lon, lat = row["lon"], row["lat"]

        rnode = snap_point_to_node(lon, lat, rail_nodes)
        wnode = snap_point_to_node(lon, lat, w_nodes)
        hnode = snap_point_to_node(lon, lat, road_nodes_gdf)

        try:
            d_rail = nx.shortest_path_length(G_rail, rail_src, rnode, weight="weight")
        except:
            d_rail = np.inf
        try:
            d_water = nx.shortest_path_length(G_water, water_src, wnode, weight="weight")
        except:
            d_water = np.inf
        try:
            d_high = nx.shortest_path_length(G_high, high_src, hnode, weight="weight")
        except:
            d_high = np.inf

        result.append([row["faf_code"], d_high, d_rail, d_water])

    df = pd.DataFrame(result, columns=["faf_code", "truck_d", "rail_d", "water_d"])
    df.to_csv(save_path, index=False)
    print("Saved POLA distance table to:", save_path)
    return df
