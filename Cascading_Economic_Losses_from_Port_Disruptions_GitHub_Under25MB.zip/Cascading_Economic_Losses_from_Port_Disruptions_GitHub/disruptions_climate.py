import numpy as np
import pandas as pd

def verify_sector_shares(shares_df: pd.DataFrame):
    if shares_df.isna().any().any():
        raise ValueError("Shares contain NaN")
    colsum = shares_df.sum(axis=0)
    if (colsum == 0).any():
        bad = list(colsum[colsum == 0].index)
        raise ValueError(f"Zero sum share columns: {bad}")
    if not np.allclose(colsum.values, np.ones_like(colsum.values), atol=1e-6):
        raise ValueError("Share columns do not sum to 1")

def propagate_to_mriim(L: pd.DataFrame, sector_losses: pd.Series, shares_df: pd.DataFrame) -> pd.Series:
    verify_sector_shares(shares_df)
    s = sector_losses.reindex(shares_df.columns).fillna(0.0)
    state_sector = shares_df.multiply(s, axis=1).stack()
    v = state_sector.reindex(L.index).fillna(0.0)
    x = L.values @ v.values.reshape(-1, 1)
    return pd.Series(x.flatten(), index=L.index)
