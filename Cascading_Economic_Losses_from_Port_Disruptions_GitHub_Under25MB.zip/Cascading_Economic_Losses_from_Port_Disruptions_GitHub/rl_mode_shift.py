# rl_mode_shift.py
import numpy as np
from typing import Dict, Any, Tuple
from tqdm import tqdm


class ModeShiftEnv:
    """
    Lightweight environment that calls a provided ABM loss function (abm_loss_fn).
    - abm_loss_fn signature must accept:
        (agent_df, sev_array, dur_array, forced_shift=..., fuels=..., **other_kwargs)
    - abm_kwargs: extra keyword args for abm_loss_fn (e.g., sector_usd_per_ton, OD22, mult_sector).
      If 'fuels' is present in abm_kwargs, it will be removed to prevent duplicate kwargs.
    """
    def __init__(self, agent_df, abm_loss_fn, abm_kwargs: Dict[str, Any], H: int = 7, seed: int = 123):
        self.agent_df = agent_df.copy()
        self.H = H
        self.rng = np.random.RandomState(seed)
        self.abm_loss_fn = abm_loss_fn

        # Keep a clean base kwargs dict and ensure we don't carry a 'fuels' key here.
        self.abm_kwargs = dict(abm_kwargs) if abm_kwargs is not None else {}
        if "fuels" in self.abm_kwargs:
            # RL controls fuels dynamically; avoid duplicate kwargs later.
            self.abm_kwargs.pop("fuels", None)

        self.action_space_n = 9
        self.reset()

    def reset(self):
        self.sev = self.rng.beta(2.0, 8.0)
        self.dur = float(np.exp(self.rng.normal(np.log(2.0), 0.5)))
        self.rem = min(30.0, max(1.0, self.dur))
        self.t = 0
        self.share_shift = {"truck->rail": 0.0, "truck->barge": 0.0}
        self.fuels = {"truck": "Diesel", "rail": "Diesel", "barge": "Diesel"}
        self.backlog = self.sev / (1 - self.sev + 1e-3)
        return self._obs()

    def _obs(self):
        return np.array([self.sev, min(3.0, self.backlog), self.rem / 30.0], dtype=np.float32)

    def step(self, action: int):
        # Discrete actions (0..8)
        if action == 1:
            self.share_shift["truck->rail"] = min(1.0, self.share_shift["truck->rail"] + 0.10)
        elif action == 2:
            self.share_shift["truck->rail"] = min(1.0, self.share_shift["truck->rail"] + 0.20)
        elif action == 3:
            self.share_shift["truck->barge"] = min(1.0, self.share_shift["truck->barge"] + 0.10)
        elif action == 4:
            self.share_shift["truck->barge"] = min(1.0, self.share_shift["truck->barge"] + 0.20)
        elif action == 5:
            self.fuels["truck"] = "Electric"
        elif action == 6:
            self.fuels["rail"] = "Electric"
        elif action == 7:
            self.fuels["barge"] = "Biodiesel"
        elif action == 8:
            # Reset knobs
            self.share_shift = {"truck->rail": 0.0, "truck->barge": 0.0}
            self.fuels = {"truck": "Diesel", "rail": "Diesel", "barge": "Diesel"}

        # Build kwargs for abm_loss_fn: inject fuels exactly once here.
        call_kwargs = dict(self.abm_kwargs)
        call_kwargs["fuels"] = self.fuels

        losses = self.abm_loss_fn(
            self.agent_df,
            np.array([self.sev]),
            np.array([self.rem]),
            forced_shift=self.share_shift,
            **call_kwargs,
        )
        day_loss = float(losses[0])
        reward = -day_loss

        # Advance time
        self.t += 1
        self.rem = max(0.0, self.rem - 1.0)
        self.backlog = max(0.0, self.backlog - 0.2)
        done = (self.rem <= 0.0) or (self.t >= self.H)

        return self._obs(), reward, done, {}


def _qbin(x, bins):
    return int(np.digitize([x], bins)[0])


def train_rl(
    env: ModeShiftEnv,
    episodes: int = 240,
    eps_start: float = 0.30,
    eps_end: float = 0.02,
    gamma: float = 0.95,
    alpha: float = 0.3,
) -> Tuple[np.ndarray, np.ndarray, list]:
    """
    Simple tabular Q-learning on a discretized state space with 9 actions.
    Returns: (Q, policy, returns)
    """
    sev_bins = np.linspace(0, 1, 6)[1:-1]   # 4 bins => 5 index positions
    back_bins = np.linspace(0, 3, 7)[1:-1]  # 5 bins => 6 index positions
    rem_bins = np.linspace(0, 1, 6)[1:-1]   # 4 bins => 5 index positions

    Q = np.zeros((5, 6, 5, env.action_space_n))
    returns = []

    pbar = tqdm(range(episodes), desc="RL training")
    for ep in pbar:
        s = env.reset()
        total = 0.0
        done = False
        epsilon = eps_end + (eps_start - eps_end) * max(0.0, (episodes - 1 - ep) / (episodes - 1))

        while not done:
            si = (_qbin(s[0], sev_bins), _qbin(s[1], back_bins), _qbin(s[2], rem_bins))
            if np.random.rand() < epsilon:
                a = np.random.randint(env.action_space_n)
            else:
                a = int(np.argmin(Q[si]))

            s2, r, done, _ = env.step(a)
            si2 = (_qbin(s2[0], sev_bins), _qbin(s2[1], back_bins), _qbin(s2[2], rem_bins))

            Q[si + (a,)] = (1 - alpha) * Q[si + (a,)] + alpha * (r + (0 if done else gamma * np.min(Q[si2])))
            s = s2
            total += r

        returns.append(total)
        if (ep + 1) % 20 == 0:
            pbar.set_postfix(avg_last_20=np.mean(returns[-20:]))

    policy = np.argmin(Q, axis=-1)
    return Q, policy, returns
