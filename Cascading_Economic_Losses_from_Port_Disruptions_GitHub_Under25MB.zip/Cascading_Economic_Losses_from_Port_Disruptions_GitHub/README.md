# Cascading Economic Losses from Port Disruptions

This repository packages the original Python research implementation and the supplied case-study data. The code combines freight disruption scenarios, agent-based freight behavior, mode shifting, and economic input-output analysis. The original mathematical and computational logic is retained; edits primarily replace machine-specific file paths with repository-relative paths.

## Repository contents

- `cascading_economic_losses.py`: main analysis and execution script.
- `freight_abm.py`, `mriim.py`, `rl_mode_shift.py`, `disruptions_climate.py`: supporting models.
- `audit_viz_v2.py`, `diagnostics_all.py`: analysis and diagnostics.
- `pola_distances.py`: optional network-distance generation (requires additional network shapefiles).
- `data/`: seven bundled case-study datasets; the large FAF5.7.csv input is distributed separately.
- `outputs/`: output destination; generated files are excluded from Git.

## Installation and execution

Requires Python 3.10+ (recommended). From the project folder:

```bash
python -m pip install -r requirements.txt
python cascading_economic_losses.py
```

The run can be computationally demanding and produces results in `outputs/`. The model was **not executed or numerically validated** as part of packaging. Users should review model assumptions and input-data formats before interpreting results.

## Reuse and assumptions

The supplied data correspond to the original case study. To analyze another region or year, replace the files in `data/` with structurally compatible inputs and review the hard-coded scenario, economic, modal, fuel, emissions and handling assumptions in `cascading_economic_losses.py` and supporting modules. For example, the original code specifies a carbon price of $50/metric ton CO2, time value of $5/hour, and 25 tons/container. These are **case-study assumptions, not universal defaults**.

The optional `pola_distances.py` expects additional rail, waterway and road network shapefiles in `data/networks/`; these were not supplied. The provided `POLA_Distances.csv` is retained for workflows that use precomputed distances.

## Required large freight dataset (not bundled)

To keep this GitHub package under 25 MB, `data/FAF5.7.csv` (approximately 217 MB) is intentionally excluded. The model may require it to run. Retrieve the original FAF5.7.csv from your project data backup or the official Freight Analysis Framework data source, ensuring that the columns and version match your original file, and place it at `data/FAF5.7.csv` before running. Do not substitute a different FAF version without checking compatibility.

The excluded original file has SHA-256 checksum:

`ebab932c23a8773d6efdf4d2e6aa160db4a3e8355da398f5b4fb039320de95ce`

## GitHub upload

Extract this ZIP and upload the contents into a new repository. The large FAF dataset is ignored by Git, so it will not accidentally exceed GitHub's file-size limit. Publish the large dataset separately if your redistribution permissions allow it, or provide a source link and instructions.

## Scope

This package preserves the existing research code rather than changing its analytical formulation. No guarantee of execution or equivalence is made without a full run.

## Reproducibility note

This is a standalone economic-impact modeling project, separate from freight optimization and routing research. The source code was reorganized for sharing and has not been executed end-to-end. The supplied files do not include the optional network shapefiles required by the distance-generation utility.
