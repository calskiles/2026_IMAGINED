# Cascading Economic Losses from Port Disruptions
# Research implementation of port-disruption scenarios and cascading economic impacts.
# Run from the repository root: python cascading_economic_losses.py
# Install dependencies first: python -m pip install -r requirements.txt
# Keep the supplied case-study data files in data/. Outputs are written to outputs/.
# Original economic, transport, disruption and simulation assumptions are retained.
# Users adapting the model should update the input data and parameter values.

import re
import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
from typing import Optional
import freight_abm
import inspect
print("freight_abm loaded from:", freight_abm.__file__)
print("compare_port_switching contains Mean POLB mode share?",
      "Mean POLB mode share" in inspect.getsource(freight_abm.compare_port_switching))
import rl_mode_shift
import os
from matplotlib.colors import LogNorm
from matplotlib import font_manager
import time
import json
import urllib.request
import zipfile
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["ps.fonttype"] = 42
plt.rcParams["figure.dpi"] = 300
plt.rcParams["savefig.dpi"] = 600
# --------------------- Font fallback helper ---------------------
# Choose a preferred font if available, otherwise pick a safe serif fallback.
_pref_fonts = ["Palatino Linotype", "Palatino", "Times New Roman", "DejaVu Serif", "serif", "DejaVu Sans"]
_installed_names = {f.name for f in font_manager.fontManager.ttflist}

for _f in _pref_fonts:
    if _f in _installed_names:
        DEFAULT_FONT = _f
        break
else:
    # final fallback: whatever rcParams currently offers (likely DejaVu)
    DEFAULT_FONT = plt.rcParams.get("font.family", ["DejaVu Sans"])
    if isinstance(DEFAULT_FONT, (list, tuple)):
        DEFAULT_FONT = DEFAULT_FONT[0]

# Set a global family so labels default to this choice (keeps behavior consistent).
plt.rcParams["font.family"] = DEFAULT_FONT
# ----------------------------------------------------------------
RUN_STABILITY_CHECKS = False
RUN_ABM_CALIBRATION = False
RUN_ABM_MAPS = True
# ========================= CONFIG: EDIT PATHS IF NEEDED ======================
PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"

# Case-study inputs: replace these files with equivalent local data for other studies.
PATHS = {
    "use":      str(DATA_DIR / "Use Sector Before.xlsx"),
    "make":     str(DATA_DIR / "Make Sector Before.xlsx"),
    "gdp_state":str(DATA_DIR / "GDP by State by Industry.xlsx"),  # sheet 'Table', year 2023
}

PATHS["us_states_shapefile_zip"] = str(DATA_DIR / "cb_2023_us_state_500k.zip")
# ---- NEW: files needed for mode-shift
PATHS["faf57"] = str(DATA_DIR / "FAF5.7.csv")
PATHS["modal_shares"] = str(DATA_DIR / "Modal_Shares.xlsx")
PATHS["abm_calibration_targets_2021"] = str(DATA_DIR / "abm_calibration_targets_2021.csv")
# ---- NEW: policy knobs (you can edit)
FROM_MODE  = "Truck"   # {"Truck","Rail","Barge"}
TO_MODE    = "Rail"    # {"Truck","Rail","Barge"} (≠ FROM_MODE)
SHIFT_PCT  = 0.10      # e.g., 0.10 = shift 10% of FROM to TO

# ---- NEW: economics & handling assumptions
CO2_PRICE_PER_TON = 50.0    # $/metric ton CO2
TIME_VALUE_PER_HR = 5.0     # $/hr
CONTAINER_TONS    = 25.0    # tons/container

# Handling (per container)
LOAD_HOURS = {("Truck","Rail"): 0.33, ("Truck","Barge"): 0.67, ("Rail","Barge"): 1.00}
LOAD_COSTS = {("Truck","Rail"): 225.0, ("Truck","Barge"): 105.0, ("Rail","Barge"): 105.0}

# Mode unit costs by fuel ($/ton-mile)
COST_TONMI = {
    "Truck": {"Diesel":0.1335, "Biodiesel":0.1339, "Electric":0.1232, "Hydrogen":0.1310},
    "Rail":  {"Diesel":0.0127, "Biodiesel":0.0126, "Electric":0.0093, "Hydrogen":0.0038},
    "Barge": {"Diesel":0.00303,"Biodiesel":0.00297,"Electric":0.0010,"Hydrogen":0.00148},
}
# CO2 (g/ton-mile)
CO2_G_TONMI = {
    "Truck": {"Diesel":65.02, "Biodiesel":56.75, "Electric":21.71, "Hydrogen":27.73},
    "Rail":  {"Diesel":25.75, "Biodiesel":22.50, "Electric":6.65,  "Hydrogen":9.43},
    "Barge": {"Diesel":10.89, "Biodiesel":9.52,  "Electric":3.29,  "Hydrogen":4.00},  # Water→Barge
}
# Fuel mix within each mode: 95% diesel, remaining 5% split equally
FUEL_MIX = {"Diesel":0.95, "Biodiesel":(0.05/3), "Electric":(0.05/3), "Hydrogen":(0.05/3)}

OUTDIR = PROJECT_ROOT / "outputs"
CA_CODE = "CA"
POLA_DEFAULT = 0.50  # 50% of CA flows via PoLA for now
RUN_CAPACITY_SENSITIVITY = False
# Contiguous 48 (no DC/AK/HI)
STATES48 = ["AL","AZ","AR","CA","CO","CT","DE","FL","GA","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA",
            "MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC",
            "SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"]

SECTORS15 = [
    "Agriculture, forestry, fishing, and hunting","Mining","Utilities","Construction","Manufacturing",
    "Wholesale trade","Retail trade","Transportation and warehousing","Information",
    "Finance, insurance, real estate, rental, and leasing","Professional and business services",
    "Educational services, health care, and social assistance",
    "Arts, entertainment, recreation, accommodation, and food services","Other services, except government","Government"
]
SECTOR_NUM = {s: i+1 for i, s in enumerate(SECTORS15)}

SECTOR_SHORT = {
    "Agriculture, forestry, fishing, and hunting":"Ag/Forestry",
    "Mining":"Mining",
    "Utilities":"Utilities",
    "Construction":"Construction",
    "Manufacturing":"Manufacturing",
    "Wholesale trade":"Wholesale",
    "Retail trade":"Retail",
    "Transportation and warehousing":"Transport",
    "Information":"Information",
    "Finance, insurance, real estate, rental, and leasing":"FIRE",
    "Professional and business services":"Prof. Svcs",
    "Educational services, health care, and social assistance":"Ed/Health",
    "Arts, entertainment, recreation, accommodation, and food services":"Leisure/Hosp",
    "Other services, except government":"Other Svcs",
    "Government":"Government",
}

# ---- Census region / division tags (same as I sent earlier)
STATE_TO_REGION = {
    "CT":"Northeast","ME":"Northeast","MA":"Northeast","NH":"Northeast","RI":"Northeast","VT":"Northeast",
    "NJ":"Northeast","NY":"Northeast","PA":"Northeast",
    "IL":"Midwest","IN":"Midwest","MI":"Midwest","OH":"Midwest","WI":"Midwest",
    "IA":"Midwest","KS":"Midwest","MN":"Midwest","MO":"Midwest","NE":"Midwest","ND":"Midwest","SD":"Midwest",
    "DE":"South","FL":"South","GA":"South","MD":"South","NC":"South","SC":"South","VA":"South","WV":"South",
    "AL":"South","KY":"South","MS":"South","TN":"South","AR":"South","LA":"South","OK":"South","TX":"South",
    "AZ":"West","CO":"West","ID":"West","MT":"West","NV":"West","NM":"West","UT":"West","WY":"West",
    "CA":"West","OR":"West","WA":"West",
}
STATE_TO_DIVISION = {
    "CT":"New England","ME":"New England","MA":"New England","NH":"New England","RI":"New England","VT":"New England",
    "NJ":"Middle Atlantic","NY":"Middle Atlantic","PA":"Middle Atlantic",
    "IL":"East North Central","IN":"East North Central","MI":"East North Central","OH":"East North Central","WI":"East North Central",
    "IA":"West North Central","KS":"West North Central","MN":"West North Central","MO":"West North Central",
    "NE":"West North Central","ND":"West North Central","SD":"West North Central",
    "DE":"South Atlantic","FL":"South Atlantic","GA":"South Atlantic","MD":"South Atlantic",
    "NC":"South Atlantic","SC":"South Atlantic","VA":"South Atlantic","WV":"South Atlantic",
    "AL":"East South Central","KY":"East South Central","MS":"East South Central","TN":"East South Central",
    "AR":"West South Central","LA":"West South Central","OK":"West South Central","TX":"West South Central",
    "AZ":"Mountain","CO":"Mountain","ID":"Mountain","MT":"Mountain","NV":"Mountain","NM":"Mountain","UT":"Mountain","WY":"Mountain",
    "CA":"Pacific","OR":"Pacific","WA":"Pacific",
}
HB = 1.6  # home_bias used to build Ri (kept in one place so labels stay correct)

def _build_W(states, same_div_mult=2.0, same_reg_mult=1.3):
    """Bilateral proximity weights W[r,s] (>=1); diag left at 1 (home-bias applied later)."""
    import numpy as np
    S = len(states)
    W = np.ones((S, S), dtype=float)
    for r_idx, r in enumerate(states):
        r_div = STATE_TO_DIVISION.get(r, "")
        r_reg = STATE_TO_REGION.get(r, "")
        for s_idx, s in enumerate(states):
            if r == s: 
                continue
            w = 1.0
            if STATE_TO_REGION.get(s,"") == r_reg:     w *= same_reg_mult
            if STATE_TO_DIVISION.get(s,"") == r_div:   w *= same_div_mult
            W[r_idx, s_idx] = w
    return W

def _ipf_balance(prior, row_targets, col_targets, tol=1e-9, max_iter=2000, eps=1e-12):
    """
    IPF/RAS to scale a nonnegative prior matrix to given row and column sums.
    Handles zero rows/cols safely. Returns balanced matrix.
    """
    import numpy as np
    T = prior.copy().astype(float)
    T[T < eps] = eps  # strictly positive to start IPF
    rows = row_targets.astype(float).copy()
    cols = col_targets.astype(float).copy()

    # Zero rows/cols → set to eps so ratios behave; we'll zero them out at the end.
    zero_row = rows <= eps
    zero_col = cols <= eps
    rows[zero_row] = eps
    cols[zero_col] = eps

    for _ in range(max_iter):
        # scale rows
        r_scale = rows / (T.sum(axis=1, keepdims=True) + eps)
        T *= r_scale
        # scale cols
        c_scale = cols / (T.sum(axis=0, keepdims=True) + eps)
        T *= c_scale

        if max(
            float(np.max(np.abs(T.sum(axis=1) - rows))),
            float(np.max(np.abs(T.sum(axis=0) - cols)))
        ) < tol:
            break

    # Zero back the truly zero targets
    T[zero_row, :] = 0.0
    T[:, zero_col] = 0.0
    return T

def save_sector_legend(path):
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.axis("off")
    rows = [f"{i+1:>2}  {SECTOR_SHORT[s]}" for i, s in enumerate(SECTORS15)]
    text = "\n".join(rows)
    ax.text(0.02, 0.98, "Sector # → Name", va="top", ha="left", fontsize=12)
    ax.text(0.02, 0.92, text, va="top", ha="left", fontsize=11, linespacing=1.25)
    fig.tight_layout()
    fig.savefig(path.with_suffix(".pdf"))
    plt.close(fig)

# ========================= 1) USE/MAKE 15×15  ================================
# --- ADD near the top (imports) ---
from typing import Optional

def _norm_sector(s: str) -> str:
    """Lowercase, replace '&' with 'and', drop punctuation, collapse spaces / NBSPs."""
    s = str(s).replace("\u00a0", " ").strip().lower()
    s = s.replace("&", "and")
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def _build_label_map(actual_labels, canonical_labels):
    """Map each canonical label to the best actual label (exact→containment→token overlap)."""
    can_norm = {c: _norm_sector(c) for c in canonical_labels}
    act_norm = {a: _norm_sector(a) for a in actual_labels}
    norm_to_actual = {}
    for a, n in act_norm.items():
        norm_to_actual.setdefault(n, []).append(a)

    mapping, unmatched = {}, []
    for c, cn in can_norm.items():
        # 1) exact normalized match
        if cn in norm_to_actual:
            mapping[c] = sorted(norm_to_actual[cn], key=len, reverse=True)[0]
            continue
        # 2) containment either way
        candidates = [a for a, an in act_norm.items() if cn in an or an in cn]
        if candidates:
            mapping[c] = sorted(candidates, key=len, reverse=True)[0]
            continue
        # 3) token overlap
        c_tokens = set(cn.split())
        best, best_score = None, 0.0
        for a, an in act_norm.items():
            a_tokens = set(an.split())
            inter = len(c_tokens & a_tokens); union = len(c_tokens | a_tokens) or 1
            score = inter / union
            if score > best_score:
                best, best_score = a, score
        if best_score >= 0.6:
            mapping[c] = best
        else:
            unmatched.append(c)
    return mapping, unmatched

def _guess_sheet(xlsx_path: str, hint: Optional[str]) -> str:
    xls = pd.ExcelFile(xlsx_path)
    names = [n.lower() for n in xls.sheet_names]
    if hint:
        for i, n in enumerate(names):
            if hint.lower() in n:
                return xls.sheet_names[i]
    return xls.sheet_names[0]

def _read_15x15_from_fixed_range(xlsx_path: str, *, hint: Optional[str]) -> pd.DataFrame:
    """
    Read exactly: header row=7; labels B8:B22; data C8:Q22 (15x15).
    Returns a 15x15 DataFrame aligned to SECTORS15 (robust label mapping).
    """
    sheet = _guess_sheet(xlsx_path, hint)
    # Header row is 7 (0-based header=6). Read columns B..Q, 15 data rows.
    raw = pd.read_excel(xlsx_path, sheet_name=sheet, header=6, usecols="B:Q", nrows=15)
    # First column is 'Name' (row labels)
    name_col = raw.columns[0]
    raw[name_col] = raw[name_col].astype(str).str.replace("\u00a0", " ").str.strip()
    df = raw.set_index(name_col)
    df = df.apply(pd.to_numeric, errors="coerce").fillna(0.0)

    # Build robust row/column maps to canonical list
    row_map, row_unmatched = _build_label_map(df.index.tolist(), SECTORS15)
    col_map, col_unmatched = _build_label_map(df.columns.tolist(), SECTORS15)
    print(f"[{Path(xlsx_path).name} :: {sheet}] Using fixed range B7:Q22 (data C8:Q22).")
    print(f"Row matches {len(row_map)}/15; Unmatched rows: {row_unmatched}")
    print(f"Col matches {len(col_map)}/15; Unmatched cols: {col_unmatched}")

    if row_unmatched or col_unmatched:
        raise ValueError("Label mismatch in fixed range — please check the 15 sector names in row 7 / col B.")

    # Slice in canonical order & relabel
    df15 = df.loc[[row_map[c] for c in SECTORS15], [col_map[c] for c in SECTORS15]].copy()
    df15.index = SECTORS15
    df15.columns = SECTORS15
    print("Extracted 15x15 from fixed range:", df15.shape)
    return df15

def read_use_make(paths: dict):
    for key in ("use","make","gdp_state"):
        if not Path(paths[key]).exists():
            raise FileNotFoundError(f"Missing file: {paths[key]}")
    Use  = _read_15x15_from_fixed_range(paths["use"],  hint="use");   print("Use shape:",  Use.shape)
    Make = _read_15x15_from_fixed_range(paths["make"], hint="make");  print("Make shape:", Make.shape)

    # Quick check on Make column totals so you can see they’re positive
    print("\nMake column totals (million $) from fixed range:")
    print(Make.sum(axis=0).to_string())
    return Use, Make


def build_A(Use: pd.DataFrame, Make: pd.DataFrame):
    x = Make.sum(axis=0).rename("x_output_million_$")
    print("x (total output) length:", len(x), "(million $)")
    if (x <= 0).any(): raise ValueError("Nonpositive sector outputs found")
    A = Use.div(x, axis=1).replace([np.inf, -np.inf], 0.0).fillna(0.0)
    print("A shape:", A.shape)
    if A.shape != (15,15): raise ValueError("A not 15x15")
    if (A.sum(axis=0).values == 0).any() or (A.sum(axis=1).values == 0).any():
        raise ValueError("A has zero-sum rows/cols")
    rho = float(np.max(np.abs(np.linalg.eigvals(A.values))))
    print("A spectral radius:", rho)
    if rho >= 1.0: raise ValueError("A spectral radius >= 1")
    return A, x

def leontief(A: pd.DataFrame):
    L = np.linalg.inv(np.eye(A.shape[0]) - A.values)
    L = pd.DataFrame(L, index=A.index, columns=A.columns)
    print("L shape:", L.shape)
    if not np.isfinite(L.values).all(): raise ValueError("L has non-finite entries")
    return L



# ========================= 2) GDP BY STATE×SECTOR (no mapping) ===============
STATE_NAME_TO_CODE = {
    "Alabama":"AL","Arizona":"AZ","Arkansas":"AR","California":"CA","Colorado":"CO","Connecticut":"CT",
    "Delaware":"DE","Florida":"FL","Georgia":"GA","Idaho":"ID","Illinois":"IL","Indiana":"IN","Iowa":"IA",
    "Kansas":"KS","Kentucky":"KY","Louisiana":"LA","Maine":"ME","Maryland":"MD","Massachusetts":"MA",
    "Michigan":"MI","Minnesota":"MN","Mississippi":"MS","Missouri":"MO","Montana":"MT","Nebraska":"NE",
    "Nevada":"NV","New Hampshire":"NH","New Jersey":"NJ","New Mexico":"NM","New York":"NY","North Carolina":"NC",
    "North Dakota":"ND","Ohio":"OH","Oklahoma":"OK","Oregon":"OR","Pennsylvania":"PA","Rhode Island":"RI",
    "South Carolina":"SC","South Dakota":"SD","Tennessee":"TN","Texas":"TX","Utah":"UT","Vermont":"VT",
    "Virginia":"VA","Washington":"WA","West Virginia":"WV","Wisconsin":"WI","Wyoming":"WY"
}

def _clean_cols(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [str(c).replace("\u00a0"," ").strip() for c in df.columns]
    return df

def _norm_series(s: pd.Series) -> pd.Series:
    return s.astype(str).str.replace("\u00a0"," ").str.strip()

def read_state_sector_48x15(path: str, sheet: Optional[str] = None, year_tag: str = "2023") -> pd.DataFrame:
    """
    Returns a 48×15 DataFrame indexed by 2-letter state codes and columns SECTORS15.
    Works with either:
      • WIDE format: columns = ['State', <15 sector columns>]
      • LONG format: columns like ['State'/'GeoName', 'Sector'/'Description', '2023'/'Value']
    """
    xls = pd.ExcelFile(path)
    sheet_name = sheet or xls.sheet_names[0]
    df = pd.read_excel(path, sheet_name=sheet_name)
    df = _clean_cols(df)
    cols_lower = {c.lower(): c for c in df.columns}

    # ---------- LONG tidy format ----------
    if ({"sector", "description"} & set(cols_lower)) and ({"state", "geoname"} & set(cols_lower)):
        # choose columns safely
        sector_col = cols_lower.get("sector") or cols_lower["description"]
        state_col  = cols_lower.get("state")  or cols_lower["geoname"]
        value_col  = cols_lower.get(year_tag) or cols_lower.get("value")
        if value_col is None:
            raise ValueError(f"Couldn't find a value column (e.g., '{year_tag}' or 'Value') in '{sheet_name}'.")

        tmp = df[[state_col, sector_col, value_col]].copy()
        tmp.columns = ["state", "sector", "value"]

        # normalize state → 2-letter code (uses your existing helpers/mapping)
        tmp["state"] = _norm_series(tmp["state"]).map(lambda s: STATE_NAME_TO_CODE.get(s, s))

        # normalize sector text and map to the canonical 15 names
        # (handles the parentheses variant: "Other services (except government)")
        canon_map = {_norm_sector(s): s for s in SECTORS15}
        sec = (
            tmp["sector"].astype(str)
            .str.replace("\u00a0", " ")
            .str.strip()
            .str.replace("(except government)", "except government", regex=False)
            .str.replace("&", "and")
            .str.replace(r"\s+", " ", regex=True)
            .str.lower()
        )
        tmp["sector"] = sec.map(lambda s: canon_map.get(_norm_sector(s)))

        # any sector rows that didn't map?
        if tmp["sector"].isna().any():
            bad = sorted(set(sec[tmp["sector"].isna()].unique()))
            raise ValueError(f"Unexpected sector names in '{sheet_name}': {bad}")

        # pivot → 48×15; reindex separately (no axis=… to avoid the pandas error)
        pt = tmp.pivot_table(index="state", columns="sector", values="value", aggfunc="sum")
        out = pt.reindex(index=STATES48).reindex(columns=SECTORS15).fillna(0.0)

        if out.shape != (48, 15):
            raise ValueError(f"Expected 48×15 after pivot, got {out.shape}")
        return out


    # ---------- WIDE 48×15 format ----------
    # State column
    state_col = None
    for cand in ("State","state","GeoName","Code"):
        if cand in df.columns: state_col = cand; break
    if state_col is None:
        state_col = df.columns[0]

    df[state_col] = _norm_series(df[state_col]).map(lambda s: STATE_NAME_TO_CODE.get(s, s))
    # Pick the 15 exact sector columns (after trimming)
    sector_cols = []
    col_map = {str(c).replace("\u00a0"," ").strip(): c for c in df.columns if c != state_col}
    for s in SECTORS15:
        if s not in col_map:
            raise ValueError(f"Missing sector column '{s}' in '{sheet_name}'.")
        sector_cols.append(col_map[s])

    out = (df[[state_col] + sector_cols]
              .rename(columns={state_col: "state"})
              .set_index("state"))
    out.columns = [str(c).replace("\u00a0"," ").strip() for c in out.columns]
    out = out.reindex(STATES48).reindex(columns=SECTORS15, axis=1).apply(pd.to_numeric, errors="coerce").fillna(0.0)
    if out.shape != (48,15):
        raise ValueError(f"Expected 48×15, got {out.shape}")
    return out

def compute_Ri_from_state_outputs_ipf(A_15x15: pd.DataFrame,
                                      base_48x15: pd.DataFrame,
                                      states=STATES48,
                                      sectors=SECTORS15,
                                      home_bias=1.6,
                                      same_div_mult=2.0,
                                      same_reg_mult=1.3,
                                      eps=1e-12):
    """
    Build R_i with IPF using a gravity prior that depends on destination demand and origin supply.
    """
    base = (base_48x15.reindex(index=states).reindex(columns=sectors).fillna(0.0))
    A = A_15x15.reindex(index=sectors, columns=sectors)

    X = base.values             # S×K (use gross output here when you have it; VA works as a proxy)
    A_np = A.values             # K×K
    D = (A_np @ X.T).T          # S×K destination demand for input i
    S_cty, K = D.shape

    S_supply = X                # S×K origin supply by sector
    states_list = list(states)
    W = _build_W(states_list, same_div_mult=same_div_mult, same_reg_mult=same_reg_mult)

    Ri = np.zeros((S_cty, S_cty, K), dtype=float)

    for i in range(K):
        d_i = D[:, i].astype(float).copy()        # length S
        s_i = S_supply[:, i].astype(float).copy() # length S
        tot_d = float(d_i.sum())
        tot_s = float(max(s_i.sum(), eps))

        if tot_d <= eps or tot_s <= eps:
            # Fallback: just use supply shares + home bias
            base_row = s_i / (tot_s + eps)
            for r in range(S_cty):
                rvec = base_row.copy()
                rvec[r] *= home_bias
                Ri[r, :, i] = rvec / (rvec.sum() + eps)
            continue

        # Column targets: use actual supplies scaled to total demand
        c_i = s_i * (tot_d / tot_s)

        # Gravity prior: depends on destination demand and origin supply, modulated by proximity weights
        prior = (np.outer(d_i, s_i) * W)  # S×S

        # Home-bias on the diagonal
        np.fill_diagonal(prior, np.diag(prior) * home_bias)

        # Balance to both margins via IPF
        T_i = _ipf_balance(prior, row_targets=d_i, col_targets=c_i, eps=eps)

        # Convert to row shares over origins
        Ri[:, :, i] = T_i / (d_i.reshape(-1, 1) + eps)

    # numeric clean-up
    Ri[Ri < 0] = 0.0
    Ri /= (Ri.sum(axis=1, keepdims=True) + eps)
    return Ri

def make_A_full_rowweighted(A_15x15: pd.DataFrame,
                            Ri: np.ndarray,
                            states=STATES48,
                            sectors=SECTORS15) -> pd.DataFrame:
    """
    Assemble A_full (S*K × S*K) where each block (r,s) scales ROW i of A by R_i[r,s,i].
    """
    A = A_15x15.reindex(index=sectors, columns=sectors).values  # K×K
    S, K = len(states), len(sectors)
    A_full = np.zeros((S*K, S*K), dtype=float)

    for r in range(S):
        for s in range(S):
            # block is K×K: row i of A scaled by Ri[r,s,i]
            block = (Ri[r, s, :].reshape(K, 1)) * A
            A_full[r*K:(r+1)*K, s*K:(s+1)*K] = block

    idx = pd.MultiIndex.from_product([states, sectors], names=["State", "Sector"])
    return pd.DataFrame(A_full, index=idx, columns=idx)

def make_L_full_from_A(A_full: pd.DataFrame) -> pd.DataFrame:
    I = np.eye(A_full.shape[0])
    L_full_np = np.linalg.inv(I - A_full.values)
    return pd.DataFrame(L_full_np, index=A_full.index, columns=A_full.columns)

def compute_inoperability_q(resp: pd.Series, base_48x15: pd.DataFrame, eps=1e-12) -> pd.DataFrame:
    """
    resp:  (S*K,) indexed by (State, Sector) — MRIO response (million $)
    base:  48×15 baseline outputs (million $) — use gross output if available
    returns: 48×15 matrix of q in [0,1+), clipped at 1.0 for display
    """
    x0 = base_48x15.stack()                       # (S*K,)
    q = (-resp).clip(lower=0) / (x0 + eps)        # elementwise
    q = q.clip(upper=1.0)
    return q.unstack()                            # 48×15

# ========================= 3) SCENARIOS & SHOCKS =============================
def make_percent_scenarios():
    z = pd.Series(0.0, index=SECTORS15)
    s1 = z.copy(); s1["Manufacturing"] = -0.10
    s2 = z.copy(); s2["Agriculture, forestry, fishing, and hunting"] = -0.20
    s3 = z.copy(); s3["Transportation and warehousing"] = -0.15; s3["Wholesale trade"] = -0.05
    s4 = z.copy(); s4["Information"] = -0.08; s4["Finance, insurance, real estate, rental, and leasing"] = -0.08
    s5 = z.copy(); s5 = s5.add(-0.05)
    Dpct = pd.DataFrame({"S1_Mfg10":s1,"S2_Ag20":s2,"S3_Trans15_Wh5":s3,"S4_InfoFIRE8":s4,"S5_All5":s5})
    print("Percent scenarios shape:", Dpct.shape)  # (15,5)
    return Dpct

def build_dollar_shock(percent_vec: pd.Series, ca_output_musd: pd.Series, pola_share=POLA_DEFAULT) -> pd.Series:
    # d_CA,k (million $) = PoLA_share * %shock_k * CA_output_k
    d_ca = float(pola_share) * percent_vec.reindex(SECTORS15).fillna(0.0) * ca_output_musd.reindex(SECTORS15).fillna(0.0)
    idx = pd.MultiIndex.from_product([STATES48, SECTORS15])
    d = pd.Series(0.0, index=idx, dtype=float)
    d.loc[pd.MultiIndex.from_product([[CA_CODE], SECTORS15])] = d_ca.values
    print("Dollar shock vector length:", d.shape[0], "nonzero:", int((d!=0).sum()), "(million $)")
    return d

# ========================= 4) VIZ HELPERS ====================================
# ---------- Figure helpers (Johnson style) ----------
from matplotlib.ticker import FuncFormatter

def plot_sector_bars(series: pd.Series, title, path, top_n=15, subtitle=None):
    s = series.astype(float).copy()
    s = s.reindex(s.abs().sort_values(ascending=True).index)
    if top_n is not None and top_n < len(s):
        s = s.iloc[-top_n:]
    y_labels = [SECTOR_NUM.get(k, k) for k in s.index]
    fig, ax = plt.subplots(figsize=(11, 7.5))
    bars = ax.barh(range(len(s)), s.values)
    ax.set_yticks(range(len(s))); ax.set_yticklabels(y_labels)
    ax.axvline(0, linewidth=1, linestyle="--", alpha=0.6)
    ax.set_xlabel("Change in output (million $)")
    ax.set_ylabel("Sector #")
    ax.set_title(title, pad=6, fontsize=14)
    for rect in bars:
        val = rect.get_width()
        y = rect.get_y() + rect.get_height()/2
        x = rect.get_x() + val
        ax.text(x + (0.015*np.sign(val) if val != 0 else 0.015), y, f"{val:,.0f}", va="center", ha="left" if val >= 0 else "right", fontsize=9)
    ax.grid(True, axis="x", linestyle=":", alpha=0.5)
    fig.tight_layout()
    fig.savefig(path.with_suffix(".pdf"))
    plt.close(fig)

def plot_state_bars(series: pd.Series, title, path, top_n=25, subtitle=None, highlight_state="CA"):
    s = series.astype(float).copy()
    s = s.reindex(s.abs().sort_values(ascending=True).index)
    if top_n is not None and top_n < len(s):
        s = s.iloc[-top_n:]
    fig, ax = plt.subplots(figsize=(11.5, 8))
    idx = range(len(s))
    bars = ax.barh(idx, s.values)
    if highlight_state in s.index:
        k = s.index.get_loc(highlight_state)
        bars[k].set_edgecolor("black"); bars[k].set_linewidth(1.5)
    ax.set_yticks(idx); ax.set_yticklabels(s.index)
    ax.axvline(0, linewidth=1, linestyle="--", alpha=0.6)
    ax.set_xlabel("Change in output (million $)")
    ax.set_ylabel("State")
    for rect, lab in zip(bars, s.index):
        val = rect.get_width()
        y = rect.get_y() + rect.get_height()/2
        x = rect.get_x() + val
        ax.text(x + (0.015*np.sign(val) if val != 0 else 0.015), y, f"{val:,.0f}", va="center", ha="left" if val >= 0 else "right", fontsize=9)
    ax.grid(True, axis="x", linestyle=":", alpha=0.5)
    fig.tight_layout()
    fig.savefig(path.with_suffix(".pdf"))
    plt.close(fig)

from matplotlib.colors import TwoSlopeNorm, SymLogNorm, Normalize, LogNorm, PowerNorm

# ========================= HEATMAP WITH TOP 3 SCALES ============================
def plot_heatmap(
    df: pd.DataFrame,
    title,
    path,
    vcenter=True,
    scale="robust",
    sort_states=True,
    subtitle=None,
    quant=0.985,
    loss_only=False,
    cbar_label=None,
    asinh_ref_q=0.8,
    vmax_q=0.9975,
    log_norm=True,
    vmin_q=0.02,
    normalize=None,   # NEW: "col", "row", or None
):
    M = df.astype(float).copy()

    if sort_states:
        if loss_only:
            order = (-M.clip(upper=0)).sum(axis=1).sort_values(ascending=False).index
        else:
            order = M.abs().sum(axis=1).sort_values(ascending=False).index
        M = M.loc[order]

    sec_nums = [SECTOR_NUM.get(c, c) for c in M.columns]
    fig, ax = plt.subplots(figsize=(12.5, 9))

    if loss_only:
        Mag = (-M.clip(upper=0)).values
        Mag = np.nan_to_num(Mag, nan=0.0, posinf=0.0, neginf=0.0)

        # ---------------- NORMALIZATION MODE ----------------
        if normalize == "col":
            scale_col = np.nanquantile(Mag, asinh_ref_q, axis=0)
            scale_col[scale_col <= 0] = 1.0
            Mag = Mag / scale_col

        elif normalize == "row":
            scale_row = np.nanquantile(Mag, asinh_ref_q, axis=1, keepdims=True)
            scale_row[scale_row <= 0] = 1.0
            Mag = Mag / scale_row

        # ---------------- ASINH SCALING ----------------
        ref = np.nanquantile(Mag[Mag > 0], asinh_ref_q) if np.any(Mag > 0) else 1.0
        T = np.arcsinh(Mag / max(ref, 1e-12))

        nz = T[T > 0]
        vmin = float(np.nanquantile(nz, vmin_q)) if nz.size else 0.0
        vmax = float(np.nanquantile(nz, vmax_q)) if nz.size else 1.0
        vmax = max(vmax, vmin * 5)

        im = ax.imshow(
            T,
            aspect="auto",
            cmap="viridis",       # changed to viridis
            interpolation="nearest",
            vmin=vmin,
            vmax=vmax,
        )

        cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.set_label(
            cbar_label or "relative loss intensity (asinh-scaled)",
            fontsize=15,
            fontweight="bold",
        )

        cbar.ax.tick_params(labelsize=14, width=2, length=6)
        for lbl in cbar.ax.get_yticklabels():
            lbl.set_fontweight("normal")
            lbl.set_fontname(DEFAULT_FONT)

    else:
        V = M.values
        if vcenter:
            vmax = float(np.nanquantile(np.abs(V), quant)) if V.size else 0.0
            vmin = -vmax
        else:
            vmin = float(np.nanquantile(V, 1 - quant)) if V.size else 0.0
            vmax = float(np.nanquantile(V, quant)) if V.size else 0.0

        im = ax.imshow(
            V,
            aspect="auto",
            cmap="viridis",       # changed to viridis
            vmin=vmin,
            vmax=vmax,
            interpolation="nearest",
        )

        cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.set_label(cbar_label or "value", fontsize=15, fontweight="bold")
        cbar.ax.tick_params(labelsize=14, width=2, length=6)
        for lbl in cbar.ax.get_yticklabels():
            lbl.set_fontweight("normal")
            lbl.set_fontname(DEFAULT_FONT)


    ax.set_xticks(range(len(M.columns)))
    # make axis tick labels non-bold and use Palatino
    ax.set_xticklabels(sec_nums, fontsize=15, fontweight="normal", fontname=DEFAULT_FONT)
    ax.set_yticks(range(len(M.index)))
    ax.set_yticklabels(M.index, fontsize=15, fontweight="normal", fontname=DEFAULT_FONT)
    ax.set_xlabel("Sector #", fontsize=15, fontweight="bold", fontname=DEFAULT_FONT)
    ax.set_ylabel("State", fontsize=15, fontweight="bold", fontname=DEFAULT_FONT)

    ax.set_xticks(np.arange(-0.5, M.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, M.shape[0], 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=0.8)
    ax.tick_params(which="minor", bottom=False, left=False)

    fig.tight_layout()
    fig.savefig(path.with_suffix(".pdf"), dpi=600, bbox_inches="tight")
    plt.close(fig)

def plot_heatmap_shift(
    df: pd.DataFrame,
    title,
    path,
    vcenter=True,
    scale="robust",
    sort_states=True,
    subtitle=None,
    quant=0.985,
    loss_only=False,
    cbar_label=None,
    asinh_ref_q=0.8,
    vmax_q=0.9975,
    log_norm=True,
    vmin_q=0.02,
    normalize=None,   # NEW: "col", "row", or None
    contrast_boost: float = 1.0,  # multiplier applied to transformed values to increase contrast
):
    M = df.astype(float).copy()

    if sort_states:
        if loss_only:
            order = (-M.clip(upper=0)).sum(axis=1).sort_values(ascending=False).index
        else:
            order = M.abs().sum(axis=1).sort_values(ascending=False).index
        M = M.loc[order]

    sec_nums = [SECTOR_NUM.get(c, c) for c in M.columns]
    fig, ax = plt.subplots(figsize=(12.5, 9))

    if loss_only:
        Mag = (-M.clip(upper=0)).values
        Mag = np.nan_to_num(Mag, nan=0.0, posinf=0.0, neginf=0.0)

        # ---------------- NORMALIZATION MODE ----------------
        if normalize == "col":
            scale_col = np.nanquantile(Mag, asinh_ref_q, axis=0)
            scale_col[scale_col <= 0] = 1.0
            Mag = Mag / scale_col

        elif normalize == "row":
            scale_row = np.nanquantile(Mag, asinh_ref_q, axis=1, keepdims=True)
            scale_row[scale_row <= 0] = 1.0
            Mag = Mag / scale_row

        # ---------------- ASINH SCALING ----------------
        ref = np.nanquantile(Mag[Mag > 0], asinh_ref_q) if np.any(Mag > 0) else 1.0
        T = np.arcsinh(Mag / max(ref, 1e-12))

        # apply optional contrast boost (amplifies differences after transform)
        if contrast_boost != 1.0:
            T = T * float(contrast_boost)

        nz = T[T > 0]
        vmin = float(np.nanquantile(nz, vmin_q)) if nz.size else 0.0
        vmax = float(np.nanquantile(nz, vmax_q)) if nz.size else 1.0
        vmax = max(vmax, vmin * 5)

        im = ax.imshow(
            T,
            aspect="auto",
            cmap="viridis",             # higher-contrast perceptual colormap for losses
            interpolation="nearest",
            vmin=vmin,
            vmax=vmax,
        )

        cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.set_label(
            cbar_label or "relative loss intensity (asinh-scaled)",
            fontsize=15,
            fontweight="bold",
        )

        cbar.ax.tick_params(labelsize=14, width=2, length=6)
        for lbl in cbar.ax.get_yticklabels():
            lbl.set_fontweight("bold")

    else:
        V = M.values
        if vcenter:
            vmax = float(np.nanquantile(np.abs(V), quant)) if V.size else 0.0
            vmin = -vmax
        else:
            vmin = float(np.nanquantile(V, 1 - quant)) if V.size else 0.0
            vmax = float(np.nanquantile(V, quant)) if V.size else 0.0

        im = ax.imshow(
            V,
            aspect="auto",
            cmap="cividis",
            vmin=vmin,
            vmax=vmax,
            interpolation="nearest",
        )

        cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.set_label(cbar_label or "value", fontsize=15, fontweight="bold")

    ax.set_xticks(range(len(M.columns)))
    ax.set_xticklabels(sec_nums, fontsize=15, fontweight="bold")
    ax.set_yticks(range(len(M.index)))
    ax.set_yticklabels(M.index, fontsize=15, fontweight="bold")
    ax.set_xlabel("Sector #", fontsize=15, fontweight="bold")
    ax.set_ylabel("State", fontsize=15, fontweight="bold")

    ax.set_xticks(np.arange(-0.5, M.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, M.shape[0], 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=0.8)
    ax.tick_params(which="minor", bottom=False, left=False)

    fig.tight_layout()
    fig.savefig(path.with_suffix(".pdf"), dpi=600, bbox_inches="tight")
    plt.close(fig)

# ========================= US-48 MAP HELPERS =================================

def _safe_file_token(s: str) -> str:
    """Safe compact token for figure filenames."""
    s = str(s)
    s = re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")
    return s[:50] if len(s) > 50 else s


def _get_us48_state_geometries(cache_zip_path: str):
    """
    Load contiguous 48-state geometries for mapping.
    Uses Census cartographic boundary state shapefile.
    Excludes Alaska, Hawaii, DC, and territories by filtering to STATES48.
    """
    try:
        import geopandas as gpd
    except ImportError as e:
        raise ImportError(
            "This map figure requires geopandas. Install it once with:\n"
            "    pip install geopandas pyogrio shapely\n"
            "or, if using conda:\n"
            "    conda install -c conda-forge geopandas pyogrio shapely"
        ) from e

    cache_zip_path = Path(cache_zip_path)
    cache_zip_path.parent.mkdir(parents=True, exist_ok=True)

    census_zip_url = "https://www2.census.gov/geo/tiger/GENZ2023/shp/cb_2023_us_state_500k.zip"

    if not cache_zip_path.exists():
        print(f"[ABM Maps] Downloading Census state boundaries to: {cache_zip_path}")
        urllib.request.urlretrieve(census_zip_url, cache_zip_path)

    gdf = gpd.read_file(f"zip://{cache_zip_path}")

    if "STUSPS" not in gdf.columns:
        raise ValueError("State shapefile is missing STUSPS column.")

    gdf = gdf[gdf["STUSPS"].isin(STATES48)].copy()

    missing = sorted(set(STATES48) - set(gdf["STUSPS"]))
    if missing:
        raise ValueError(f"Missing mainland states from shapefile: {missing}")

    # Project to NAD83 / Conus Albers for a clean lower-48 map.
    # This avoids the stretched look of latitude-longitude plotting.
    gdf = gdf.to_crs("EPSG:5070")

    # Keep the exact same order as STATES48.
    gdf["STUSPS"] = pd.Categorical(gdf["STUSPS"], categories=STATES48, ordered=True)
    gdf = gdf.sort_values("STUSPS").reset_index(drop=True)

    return gdf


def _plot_us48_choropleth(
    values_by_state: pd.Series,
    title,
    path,
    *,
    cbar_label="million $",
    cmap="viridis",
    state_label_size=8,
    show_state_labels=True,
    line_width=0.85,
):
    """
    Plot a 48-mainland-state choropleth with clear borders and a colorbar.

    values_by_state:
        pd.Series indexed by state abbreviation, values in million dollars.
    """
    gdf = _get_us48_state_geometries(PATHS["us_states_shapefile_zip"])

    vals = (
        values_by_state.reindex(STATES48)
        .apply(pd.to_numeric, errors="coerce")
        .fillna(0.0)
        .astype(float)
    )

    plot_df = gdf.merge(
        vals.rename("value_musd"),
        left_on="STUSPS",
        right_index=True,
        how="left"
    )
    plot_df["value_musd"] = plot_df["value_musd"].fillna(0.0)

    vmin = 0.0
    vmax = float(plot_df["value_musd"].max())
    if vmax <= 0:
        vmax = 1.0

    norm = Normalize(vmin=vmin, vmax=vmax)

    fig, ax = plt.subplots(figsize=(13.5, 8.2))

    plot_df.plot(
        column="value_musd",
        ax=ax,
        cmap=cmap,
        norm=norm,
        edgecolor="black",
        linewidth=line_width,
        legend=False,
        missing_kwds={
            "color": "lightgray",
            "edgecolor": "black",
            "hatch": "///",
            "label": "Missing",
        },
    )

    # Draw one additional outline layer to keep borders crisp in PDF.
    plot_df.boundary.plot(
        ax=ax,
        color="black",
        linewidth=line_width,
    )

    if show_state_labels:
        label_points = plot_df.copy()
        label_points["geometry"] = label_points.geometry.representative_point()

        for _, row in label_points.iterrows():
            ax.text(
                row.geometry.x,
                row.geometry.y,
                row["STUSPS"],
                ha="center",
                va="center",
                fontsize=state_label_size,
                fontweight="normal",
                fontname=DEFAULT_FONT,
                color="black",
            )

    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])

    cbar = fig.colorbar(sm, ax=ax, fraction=0.032, pad=0.015)
    cbar.set_label(
        cbar_label,
        fontsize=15,
        fontweight="bold",
        fontname=DEFAULT_FONT,
    )
    cbar.ax.tick_params(labelsize=14, width=2, length=6)

    for lbl in cbar.ax.get_yticklabels():
        lbl.set_fontname(DEFAULT_FONT)
        lbl.set_fontweight("normal")

    cbar.ax.yaxis.set_major_formatter(FuncFormatter(lambda x, pos: f"{x:,.0f}"))

    if title is not None:
        ax.set_title(
            title,
            fontsize=15,
            fontweight="bold",
            fontname=DEFAULT_FONT,
            pad=10,
        )

    ax.set_axis_off()
    ax.margins(0)

    fig.tight_layout()
    fig.savefig(path.with_suffix(".pdf"), dpi=600, bbox_inches="tight")
    plt.close(fig)


def plot_abm_state_impact_maps(
    abm_matrix: pd.DataFrame,
    out_dir: Path,
    *,
    show_state_labels=True,
):
    """
    Create two ABM maps from the same data used by ABM_StateSector_Matrix:

    1. Total state impact map:
       Sum across all 15 sectors for each of the 48 states.

    2. Top-sector state impact map:
       Find the sector with the largest total impact across all 48 states,
       then map that sector's state-level impacts.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    M = (
        abm_matrix.reindex(index=STATES48, columns=SECTORS15)
        .apply(pd.to_numeric, errors="coerce")
        .fillna(0.0)
        .astype(float)
    )

    # Figure 1: summed impacts over all sectors by state
    state_total = M.sum(axis=1).rename("ABM_total_state_impact_musd")

    _plot_us48_choropleth(
        state_total,
        title=None,
        path=out_dir / "ABM_State_Total_Impact_Map.png",
        cbar_label="Total ABM impact (million $)",
        cmap="viridis",
        show_state_labels=show_state_labels,
    )

    # Figure 2: top sector by national total, mapped across states
    sector_totals = M.sum(axis=0).sort_values(ascending=False)
    top_sector = sector_totals.index[0]
    top_sector_num = SECTOR_NUM[top_sector]
    top_sector_values = M[top_sector].rename(f"S{top_sector_num}_{top_sector}")

    top_sector_token = _safe_file_token(SECTOR_SHORT.get(top_sector, top_sector))

    _plot_us48_choropleth(
        top_sector_values,
        title=None,
        path=out_dir / f"ABM_TopSector_State_Impact_Map_S{top_sector_num:02d}_{top_sector_token}.png",
        cbar_label=f"Sector {top_sector_num} ABM impact (million $)",
        cmap="viridis",
        show_state_labels=show_state_labels,
    )

    # Save the data behind both maps for checking.
    map_data = pd.DataFrame({
        "total_all_sectors_musd": state_total,
        f"sector_{top_sector_num}_musd": top_sector_values,
    })

    sector_summary = pd.DataFrame({
        "sector_num": [SECTOR_NUM[s] for s in sector_totals.index],
        "sector_short": [SECTOR_SHORT.get(s, s) for s in sector_totals.index],
        "total_musd": sector_totals.values,
    }, index=sector_totals.index)
    sector_summary.index.name = "sector"

    with pd.ExcelWriter(out_dir / "ABM_Map_Data.xlsx", engine="xlsxwriter") as w:
        map_data.to_excel(w, sheet_name="Map_State_Data")
        sector_summary.to_excel(w, sheet_name="Sector_Totals")

    print("[ABM Maps] Wrote:")
    print("  ", out_dir / "ABM_State_Total_Impact_Map.pdf")
    print("  ", out_dir / f"ABM_TopSector_State_Impact_Map_S{top_sector_num:02d}_{top_sector_token}.pdf")
    print("  Top sector:", f"S{top_sector_num}", "-", top_sector)

    return {
        "state_total": state_total,
        "top_sector": top_sector,
        "top_sector_num": top_sector_num,
        "top_sector_values": top_sector_values,
        "sector_totals": sector_totals,
    }
def plot_mode_shift_selected_sectors_ranked(
    df: pd.DataFrame,
    title,
    path,
    sector_nums=(1, 2, 5, 6, 14),
    rank_basis="loss_magnitude",
    subtitle=None,
):
    """
    Mode-shift heatmap for selected sector numbers only, with states ranked
    largest to smallest by the selected-sector total.

    Parameters
    ----------
    df : pd.DataFrame
        State × sector matrix, usually delta_total_dollars from mode_shift_analysis().
    title : str
        Figure title.
    path : Path
        Output path. plot_heatmap_shift saves as PDF through path.with_suffix(".pdf").
    sector_nums : tuple
        Sector numbers to show. Default = (1, 2, 5, 6, 14).
    rank_basis : str
        "loss_magnitude" : ranks by sum of negative cost changes converted to positive magnitudes.
                           This matches your existing loss_only=True visual logic.
        "absolute"       : ranks by sum of absolute values.
        "signed"         : ranks by signed row sum, largest positive first.
    subtitle : str or None
        Kept for consistency with your other plotting calls.
    """

    # Convert requested sector numbers back to the full sector names used as df columns
    num_to_sector = {v: k for k, v in SECTOR_NUM.items()}

    missing_nums = [n for n in sector_nums if n not in num_to_sector]
    if missing_nums:
        raise ValueError(f"Unknown sector numbers requested: {missing_nums}")

    selected_cols = [num_to_sector[n] for n in sector_nums]

    missing_cols = [c for c in selected_cols if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Selected sectors are missing from dataframe columns: {missing_cols}")

    M = (
        df.reindex(index=STATES48, columns=selected_cols)
          .apply(pd.to_numeric, errors="coerce")
          .fillna(0.0)
          .astype(float)
    )

    # Rank states from large to small using the same loss-magnitude logic as plot_heatmap_shift(loss_only=True)
    if rank_basis == "loss_magnitude":
        rank_score = (-M.clip(upper=0)).sum(axis=1)

        # If all selected cells are nonnegative, the loss-only rank would be all zero.
        # Fall back to absolute magnitude so the ranking is still meaningful.
        if np.isclose(float(rank_score.sum()), 0.0):
            rank_score = M.abs().sum(axis=1)

    elif rank_basis == "absolute":
        rank_score = M.abs().sum(axis=1)

    elif rank_basis == "signed":
        rank_score = M.sum(axis=1)

    else:
        raise ValueError("rank_basis must be one of: 'loss_magnitude', 'absolute', or 'signed'.")

    state_order = rank_score.sort_values(ascending=False).index
    M_ranked = M.loc[state_order]

    # Reuse your existing mode-shift heatmap formatter.
    # Important: sort_states=False preserves the custom ranking above.
    plot_heatmap_shift(
        M_ranked,
        title,
        path,
        vcenter=False,
        scale="asinh",
        sort_states=False,
        subtitle=subtitle,
        quant=0.9,
        loss_only=True,
        normalize="col",
        asinh_ref_q=0.05,
        vmin_q=0.001,
        vmax_q=0.999,
        cbar_label="million $ (asinh-scaled)",
        contrast_boost=1.8
    )

    # Return ranked data in case you want to inspect/export it
    ranked_table = M_ranked.copy()
    ranked_table.insert(0, "Rank_score_selected_sectors", rank_score.loc[state_order])
    ranked_table.insert(0, "State_rank", np.arange(1, len(ranked_table) + 1))

    return ranked_table
def plot_sector_quantile_ribbon(x_labels, q_low, q_med, q_high, title, path, ylabel):
    fig, ax = plt.subplots(figsize=(11, 6))
    x = np.arange(len(x_labels))
    ax.fill_between(x, q_low, q_high, alpha=0.25, linewidth=0)
    ax.plot(x, q_med, linewidth=2)
    ax.set_xticks(x); ax.set_xticklabels(x_labels)
    ax.set_xlabel("Sector #"); ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(True, axis="y", linestyle=":", alpha=0.5)
    fig.tight_layout(); fig.savefig(path.with_suffix(".pdf")); plt.close(fig)

def plot_sector_spaghetti(*, samples, path, ylabel, max_lines=200):
    """
    samples: (N × 15) matrix, values assumed in million dollars.

    UPDATED: draws per-sector boxplots (whiskers=min/max) and shows mean (★).
    max_lines is kept only for backward compatibility (unused).
    """
    samples = np.asarray(samples, dtype=float)

    K = samples.shape[1]
    x = np.arange(K)

    # build per-sector arrays (drop NaNs/Infs safely)
    data = []
    for j in range(K):
        col = samples[:, j]
        col = col[np.isfinite(col)]
        data.append(col)

    fig, ax = plt.subplots(figsize=(11, 6))
    ax.margins(x=0, y=0)

    ax.boxplot(
        data,
        positions=x,
        widths=0.55,
        whis=(0, 100),        # whiskers = min/max (matches your prior min/max envelope intent)
        showmeans=True,       # show mean marker
        showfliers=False
    )

    ax.set_xticks(x)
    ax.set_xticklabels(
        [SECTOR_NUM[s] for s in SECTORS15],
        fontsize=15, fontweight="normal", fontname=DEFAULT_FONT
    )

    ax.set_xlabel("Sector #", fontsize=15, fontweight="bold", fontname=DEFAULT_FONT)
    ax.set_ylabel(ylabel, fontsize=15, fontweight="bold", fontname=DEFAULT_FONT)
    ax.set_ylim(bottom=0)

    ax.tick_params(axis="both", labelsize=15, width=2.0, length=6)
    for lbl in ax.get_yticklabels():
        lbl.set_fontname(DEFAULT_FONT)
        lbl.set_fontweight("normal")

    for spine in ax.spines.values():
        spine.set_linewidth(2.0)

    ax.grid(True, axis="y", linestyle=":", linewidth=1.0, alpha=0.6)

    fig.tight_layout()
    fig.savefig(path.with_suffix(".pdf"))
    plt.close(fig)


def plot_sector_spaghetti_billion(*, samples, path, ylabel, max_lines=200):
    """
    samples: (N × 15) matrix, values assumed in million dollars.

    UPDATED: draws per-sector boxplots (whiskers=min/max) and shows mean (★),
    converted to billion dollars.
    max_lines is kept only for backward compatibility (unused).
    """
    samples = np.asarray(samples, dtype=float) / 1000.0  # million -> billion

    K = samples.shape[1]
    x = np.arange(K)

    data = []
    for j in range(K):
        col = samples[:, j]
        col = col[np.isfinite(col)]
        data.append(col)

    fig, ax = plt.subplots(figsize=(11, 6))
    ax.margins(x=0, y=0)

    ax.boxplot(
        data,
        positions=x,
        widths=0.55,
        whis=(0, 100),
        showmeans=True,
        showfliers=False
    )

    ax.set_xticks(x)
    ax.set_xticklabels(
        [SECTOR_NUM[s] for s in SECTORS15],
        fontsize=15, fontweight="normal", fontname=DEFAULT_FONT
    )

    ax.set_xlabel("Sector #", fontsize=15, fontweight="bold", fontname=DEFAULT_FONT)
    ax.set_ylabel(ylabel, fontsize=15, fontweight="bold", fontname=DEFAULT_FONT)
    ax.set_ylim(bottom=0)

    ax.tick_params(axis="both", labelsize=15, width=2.0, length=6)
    for lbl in ax.get_yticklabels():
        lbl.set_fontname(DEFAULT_FONT)
        lbl.set_fontweight("normal")

    for spine in ax.spines.values():
        spine.set_linewidth(2.0)

    ax.grid(True, axis="y", linestyle=":", linewidth=1.0, alpha=0.6)

    fig.tight_layout()
    fig.savefig(path.with_suffix(".pdf"))
    plt.close(fig)

# ========================= 7) MODE-SHIFT HELPERS =============================
def _pair(a, b):
    if a == b: return None
    return tuple(sorted([a, b]))

def _weighted_unit_tables():
    """Blended $/ton-mi and CO2$/ton-mi for each mode using FUEL_MIX and CO2 price."""
    cost, co2d = {}, {}
    for m in ["Truck","Rail","Barge"]:
        cost[m] = sum(COST_TONMI[m][f]*FUEL_MIX[f] for f in FUEL_MIX)
        g = sum(CO2_G_TONMI[m][f]*FUEL_MIX[f] for f in FUEL_MIX)  # g/ton-mi
        co2d[m] = g * 1e-6 * CO2_PRICE_PER_TON                     # $/ton-mi
    return pd.Series(cost, name="$/ton-mi"), pd.Series(co2d, name="CO2$/ton-mi")

# --- FAF region/state + SCTG2 mapping (lightweight, same as earlier guidance)
_FIPS2_TO_STATE = {
    1:"AL",2:"AK",4:"AZ",5:"AR",6:"CA",8:"CO",9:"CT",10:"DE",11:"DC",12:"FL",13:"GA",16:"ID",17:"IL",18:"IN",19:"IA",
    20:"KS",21:"KY",22:"LA",23:"ME",24:"MD",25:"MA",26:"MI",27:"MN",28:"MS",29:"MO",30:"MT",31:"NE",32:"NV",33:"NH",
    34:"NJ",35:"NM",36:"NY",37:"NC",38:"ND",39:"OH",40:"OK",41:"OR",42:"PA",44:"RI",45:"SC",46:"SD",47:"TN",48:"TX",
    49:"UT",50:"VT",51:"VA",53:"WA",54:"WV",55:"WI",56:"WY"
}
def _faf_region_to_state(code):
    try:
        x = int(str(code).strip())
        return _FIPS2_TO_STATE.get(x//10)
    except:
        return None

_AG = {1,2,3,25}
_MINING = {10,11,12,13,14,15,16}
_MANU = set(range(4,10)) | {17,18,19} | set(range(20,41)) | {42}
_WHOLESALE = {43}
_OTHERSVCS = {41}
def _sctg2_to_sector(s):
    try: k = int(str(s).strip())
    except: return None
    if k in _AG: return "Agriculture, forestry, fishing, and hunting"
    if k in _MINING: return "Mining"
    if k in _MANU: return "Manufacturing"
    if k in _WHOLESALE: return "Wholesale trade"
    if k in _OTHERSVCS: return "Other services, except government"
    return "Manufacturing"  # safe default

def _norm_mode(m):
    s = str(m).strip().lower()
    if s in {"1","truck","trk"}: return "Truck"
    if s in {"2","rail","rl"}:   return "Rail"
    if s in {"3","water","barge","inland water","coastal","great lakes"}: return "Barge"
    return None

def _find_col(cols, cands):
    lo = {c.lower():c for c in cols}
    for k in cands:
        if k in lo: return lo[k]
    return None

def aggregate_inbound_faf_tm_and_tons(csv_path: str):
    """
    Chunk-read FAF5.7 and aggregate to (destination state × sector × mode).
    Returns dicts of 48×15 DataFrames for tons and ton-miles by mode, plus totals.
    """
    tons_acc, tm_acc = None, None
    CANDS = {
        "dest":  ["dms_dest","dest","destination","d_dst","dmsdst","DMS_DEST"],
        "mode":  ["mode","modes","dms_mode","ship_mode","shipmode","MODE"],
        "sctg2": ["sctg2","sctg_2","sctg","commodity","sctg02","sctg_code","SCTG2"],
        "tons":  ["tons","weight_tons","shipwt","shipweight","tons_2020","tons_2023","WGT"],
        "tmiles":["tmiles","ton_miles","tonmiles","tmile","tmiles_2023","TMILES"],
        "miles": ["miles","distance","dist_mi","mi","MILES"],
    }
    for chunk in pd.read_csv(csv_path, chunksize=250_000, dtype=str, low_memory=False):
        c_dest  = _find_col(chunk.columns, CANDS["dest"])
        c_mode  = _find_col(chunk.columns, CANDS["mode"])
        c_sctg2 = _find_col(chunk.columns, CANDS["sctg2"])
        c_tons  = _find_col(chunk.columns, CANDS["tons"])
        if not all([c_dest,c_mode,c_sctg2,c_tons]):
            raise ValueError("FAF5.7 is missing dest/mode/sctg2/tons columns.")

        st   = chunk[c_dest].map(_faf_region_to_state)
        mode = chunk[c_mode].map(_norm_mode)
        sec  = chunk[c_sctg2].map(_sctg2_to_sector)
        tons = pd.to_numeric(chunk[c_tons], errors="coerce")

        c_tm = _find_col(chunk.columns, CANDS["tmiles"])
        if c_tm:
            tm = pd.to_numeric(chunk[c_tm], errors="coerce")
        else:
            c_mi = _find_col(chunk.columns, CANDS["miles"])
            if not c_mi: raise ValueError("Need either TMILES or MILES in FAF5.7.")
            mi = pd.to_numeric(chunk[c_mi], errors="coerce")
            tm = mi * tons

        df = pd.DataFrame({"State":st,"Mode":mode,"Sector":sec,"tons":tons,"tm":tm})
        df = df[df["State"].isin(STATES48) & df["Sector"].isin(SECTORS15) & df["Mode"].isin(["Truck","Rail","Barge"])]

        g = df.groupby(["State","Sector","Mode"], observed=True)[["tons","tm"]].sum()
        tons_acc = g["tons"] if tons_acc is None else tons_acc.add(g["tons"], fill_value=0.0)
        tm_acc   = g["tm"]   if tm_acc   is None else tm_acc.add(g["tm"],   fill_value=0.0)

    idx = pd.MultiIndex.from_product([STATES48, SECTORS15, ["Truck","Rail","Barge"]], names=["State","Sector","Mode"])
    tons_acc = tons_acc.reindex(idx, fill_value=0.0)
    tm_acc   = tm_acc.reindex(idx, fill_value=0.0)

    tons_by_mode = {m: tons_acc.xs(m, level="Mode").unstack("Sector").reindex(index=STATES48, columns=SECTORS15)
                    for m in ["Truck","Rail","Barge"]}
    tm_by_mode   = {m: tm_acc.xs(m,   level="Mode").unstack("Sector").reindex(index=STATES48, columns=SECTORS15)
                    for m in ["Truck","Rail","Barge"]}

    tons_total = sum(tons_by_mode.values())
    tm_total   = sum(tm_by_mode.values())
    return tons_by_mode, tm_by_mode, tons_total, tm_total

def _clean_state_label(lbl: str) -> str:
    s = str(lbl).replace("\u00a0", " ").strip().upper()
    s = s.replace("(DUP)", "").replace("(COPY)", "").strip()
    s = s.split('.')[0].strip()
    return s

def _dedupe_axis(df: pd.DataFrame, axis: int, how: str = "mean") -> pd.DataFrame:
    if axis == 0:
        return getattr(df.groupby(level=0), how)()
    else:
        return getattr(df.T.groupby(level=0), how)().T

def read_modal_shares_book(path: str):
    book = {}
    for m in ["Truck", "Rail", "Barge"]:
        df = pd.read_excel(path, sheet_name=m)
        keep_cols = [c for c in df.columns if not str(c).lower().startswith("unnamed")]
        df = df[keep_cols]

        first = df.columns[0]
        df[first] = df[first].astype(str).str.replace("\u00a0", " ").str.strip()
        df = df[~df[first].eq("")]
        df = df.set_index(first)

        df.columns = [_clean_state_label(c) for c in df.columns]
        df = df[[c for c in df.columns if c in STATES48]]

        df = _dedupe_axis(df, axis=1, how="mean")

        row_map, unmatched = _build_label_map(df.index.tolist(), SECTORS15)
        if unmatched: 
            raise ValueError(f"[ModeShift] Missing sector rows in '{m}' sheet: {unmatched}")
        df = df.loc[[row_map[s] for s in SECTORS15]]


        df = _dedupe_axis(df, axis=0, how="mean")
        df = df.reindex(index=SECTORS15, columns=STATES48).fillna(0.0)

        # NEW: force numeric after alignment (kills any stringy leftovers)
        df = df.apply(pd.to_numeric, errors="coerce").fillna(0.0)

        out = df.T  # 48×15
        if out.index.duplicated().any() or out.columns.duplicated().any():
            raise RuntimeError("[ModeShift] duplicate labels after cleaning")
        book[m] = out

    max_err = float(((book["Truck"] + book["Rail"] + book["Barge"]) - 1.0).abs().max().max())
    if max_err > 1e-6:
        print(f"[ModeShift] WARN: Truck+Rail+Barge sum max error = {max_err:.3e}")
    return book




def mode_shift_analysis(L_full: pd.DataFrame,
                        from_mode: str = FROM_MODE,
                        to_mode: str   = TO_MODE,
                        shift_pct: float = SHIFT_PCT):
    assert from_mode in {"Truck","Rail","Barge"} and to_mode in {"Truck","Rail","Barge"} and from_mode != to_mode

    # ADD THIS HERE (and remove the later pct_shift block)
    if not np.isscalar(shift_pct):
        raise ValueError("[ModeShift] shift_pct must be a scalar (e.g., 0.05 for 5%).")
    shift_pct = float(shift_pct)
    if not (0.0 <= shift_pct <= 1.0):
        raise ValueError("[ModeShift] shift_pct must be between 0 and 1.")


    # 1) unit economics
    u_cost, u_co2 = _weighted_unit_tables()  # $/ton-mi each

    # 2) inbound totals (destination-only)
    tons_by_mode, tm_by_mode, tons_total, tm_total = aggregate_inbound_faf_tm_and_tons(PATHS["faf57"])

    # 3) modal shares (already QA’d)
    shares = read_modal_shares_book(PATHS["modal_shares"])  # dict of 48×15

    # 4) quantities moved: shift % of observed FROM-mode flows (tons & ton-miles)
    FROM_tm   = tm_by_mode[from_mode]
    FROM_tons = tons_by_mode[from_mode]
    moved_tm   = shift_pct * FROM_tm
    moved_tons = shift_pct * FROM_tons

    # 5) delta operating + carbon dollars on moved ton-miles
    delta_oper_dollars = moved_tm * (u_cost[to_mode] - u_cost[from_mode])
    delta_co2_dollars  = moved_tm * (u_co2[to_mode]  - u_co2[from_mode])

    # 6) transload handling on moved tons (per container)
    p = _pair(from_mode, to_mode)
    load_hr   = LOAD_HOURS.get(p, 0.0)
    load_cost = LOAD_COSTS.get(p, 0.0)
    containers = moved_tons / CONTAINER_TONS
    delta_time_dollars     = containers * load_hr * TIME_VALUE_PER_HR
    delta_handling_dollars = containers * load_cost

    # 7) total per (state,sector)
    delta_total_dollars = (delta_oper_dollars + delta_co2_dollars + delta_time_dollars + delta_handling_dollars) \
                          .reindex(index=STATES48, columns=SECTORS15).fillna(0.0)
    # Precompute selected-sector ranked table for export and plotting
    _selected_sector_nums = (1, 2, 5, 6, 14)
    _num_to_sector = {v: k for k, v in SECTOR_NUM.items()}
    _selected_cols = [_num_to_sector[n] for n in _selected_sector_nums]

    delta_total_top5 = (
        delta_total_dollars.reindex(index=STATES48, columns=_selected_cols)
        .apply(pd.to_numeric, errors="coerce")
        .fillna(0.0)
        .astype(float)
    )

    top5_rank_score = (-delta_total_top5.clip(upper=0)).sum(axis=1)
    if np.isclose(float(top5_rank_score.sum()), 0.0):
        top5_rank_score = delta_total_top5.abs().sum(axis=1)

    top5_state_order = top5_rank_score.sort_values(ascending=False).index
    delta_total_top5_ranked = delta_total_top5.loc[top5_state_order].copy()
    delta_total_top5_ranked.insert(
        0,
        "Rank_score_selected_sectors",
        top5_rank_score.loc[top5_state_order]
    )
    delta_total_top5_ranked.insert(
        0,
        "State_rank",
        np.arange(1, len(delta_total_top5_ranked) + 1)
    )
    # ---- Two MRIO views ----
    # Spend view: push the *state total* into the destination state's Transportation & Warehousing final demand
    spend_vec = pd.Series(0.0, index=L_full.index)
    # sum across sectors → 1 scalar per state
    add_by_state = delta_total_dollars.sum(axis=1)  # Series (index=state)
    for st, val in add_by_state.items():
        spend_vec.loc[(st, "Transportation and warehousing")] = float(val)


    # Burden view: subtract the same dollars from each (state,sector) final demand
    burden_vec = -delta_total_dollars.stack().reindex(L_full.index).fillna(0.0)

    # Responses
    resp_spend  = L_full @ spend_vec
    resp_burden = L_full @ burden_vec
    mat_spend   = resp_spend.unstack().reindex(index=STATES48, columns=SECTORS15).fillna(0.0)
    mat_burden  = resp_burden.unstack().reindex(index=STATES48, columns=SECTORS15).fillna(0.0)
     
    # ---- Output paths (define before writing files or figures)
    out_dir = OUTDIR / "mode_shift"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_name = f"ModeShift_{from_mode}_to_{to_mode}_{int(round(shift_pct*100))}pct.xlsx"
    out_xlsx = out_dir / out_name

    with pd.ExcelWriter(out_xlsx, engine="xlsxwriter") as w:
        # Params + unit tables
        pd.DataFrame({
            "from_mode":[from_mode], "to_mode":[to_mode], "shift_pct":[shift_pct],
            "CO2_price":[CO2_PRICE_PER_TON], "time_value":[TIME_VALUE_PER_HR], "tons_per_container":[CONTAINER_TONS]
        }).to_excel(w, sheet_name="Params", index=False)

        pd.DataFrame({"unit_cost_per_tonmi":_weighted_unit_tables()[0],
                      "unit_CO2$_per_tonmi":_weighted_unit_tables()[1]}).to_excel(w, sheet_name="Unit_dollar_per_ton-mi")

        # Baselines
        tm_total.to_excel(w, sheet_name="Inbound_TonMiles_total")
        tons_total.to_excel(w, sheet_name="Inbound_Tons_total")
        for m in ["Truck","Rail","Barge"]:
            tm_by_mode[m].to_excel(w,   sheet_name=f"TonMiles_{m}")
            tons_by_mode[m].to_excel(w, sheet_name=f"Tons_{m}")

        # Deltas (per cell)
        delta_oper_dollars.to_excel(w,     sheet_name="ΔOper_$")
        delta_co2_dollars.to_excel(w,      sheet_name="ΔCO2_$")
        delta_time_dollars.to_excel(w,     sheet_name="ΔTime_$")
        delta_handling_dollars.to_excel(w, sheet_name="ΔHandling_$")
        delta_total_dollars.to_excel(w,    sheet_name="ΔTotal_$")
        delta_total_top5_ranked.to_excel(w, sheet_name="ΔTotal_Top5_Ranked")
        # MRIO views
        spend_vec.to_frame("FD_Spend_$").to_excel(w,  sheet_name="FD_vec_Spend")
        burden_vec.to_frame("FD_Burden_$").to_excel(w, sheet_name="FD_vec_Burden")
        mat_spend.to_excel(w,  sheet_name="Resp_Spend_matrix")
        mat_burden.to_excel(w, sheet_name="Resp_Burden_matrix")

    # Figures
    subtitle = f"Shift {shift_pct:.0%} {from_mode}→{to_mode} | CO₂=${CO2_PRICE_PER_TON}/t | time=${TIME_VALUE_PER_HR}/hr"
    plot_heatmap_shift(
        delta_total_top5_ranked.drop(columns=["State_rank", "Rank_score_selected_sectors"]),
        "Δ logistics cost by ranked state × selected sectors 1, 2, 5, 6, 14",
        out_dir / f"{out_name[:-5]}_Δcost_matrix_top5sectors_state_rank.png",
        vcenter=False,
        scale="asinh",
        sort_states=False,
        subtitle=subtitle,
        quant=0.9,
        loss_only=True,
        normalize="col",
        asinh_ref_q=0.05,
        vmin_q=0.001,
        vmax_q=0.999,
        cbar_label="million $ (asinh-scaled)",
        contrast_boost=1.8
    )
    # Selected top-sector mode-shift cost matrix:
    # sectors 1, 2, 5, 6, and 14, with states ranked large-to-small
    # by total selected-sector loss magnitude.
    top5_ranked_cost = plot_mode_shift_selected_sectors_ranked(
        delta_total_dollars,
        "Δ logistics cost by ranked state × selected sectors 1, 2, 5, 6, 14",
        out_dir / f"{out_name[:-5]}_Δcost_matrix_top5sectors_state_rank.png",
        sector_nums=(1, 2, 5, 6, 14),
        rank_basis="loss_magnitude",
        subtitle=subtitle,
    )
    # ======== CALL 6: Mode-shift burden view ========
    # In mode_shift_analysis():
    plot_heatmap(mat_burden, "MRIO (Burden view) state×sector (million $) (col-normalized)",
                 out_dir / f"{out_name[:-5]}_MRIO_Burden.png",
                 vcenter=False, scale="asinh",
                 normalize="col",
                 sort_states=True, subtitle=subtitle,
                 loss_only=True, cbar_label="within-sector relative intensity")

    # ======== CALL 7: Mode-shift spend view ========
    # In mode_shift_analysis():
    plot_heatmap(mat_spend, "MRIO (Spend view) state×sector (million $)",
                 out_dir / f"{out_name[:-5]}_MRIO_Spend.png",
                 vcenter=False, scale="asinh",  # UPDATED: was "robust"
                 sort_states=True, subtitle=subtitle,
                 quant=0.9, loss_only=False, cbar_label="million $")

    print(f"[ModeShift] Wrote: {out_xlsx}")
    return {
        "Δ_total": delta_total_dollars, "Δ_oper": delta_oper_dollars, "Δ_CO2": delta_co2_dollars,
        "Δ_time": delta_time_dollars, "Δ_hand": delta_handling_dollars,
        "resp_spend": resp_spend, "resp_burden": resp_burden
    }

def run_mode_shift(L_full: pd.DataFrame):
    try:
        mode_shift_analysis(L_full, FROM_MODE, TO_MODE, SHIFT_PCT)
    except Exception as e:
        print("[ModeShift] ERROR:", e)

# ========================= DIAGNOSTICS BLOCK =========================
def _fmt_shape(t):
    return f"{t[0]}x{t[1]}"

def _diag_add(rows, metric, value, ok, note=""):
    rows.append({"metric": metric, "value": value, "pass": bool(ok), "note": note})

def _as_df(rows, name):
    df = pd.DataFrame(rows)
    df.index.name = name
    return df

def run_core_diagnostics(Use, Make, A, L_nat, x_nat, base_48x15, Ri, A_full, L_full):
    out = {}

    rows = []
    _diag_add(rows, "Use_shape", _fmt_shape(Use.shape), Use.shape == (15,15))
    _diag_add(rows, "Make_shape", _fmt_shape(Make.shape), Make.shape == (15,15))
    _diag_add(rows, "Use_min", float(np.nanmin(Use.values)), np.nanmin(Use.values) >= 0)
    _diag_add(rows, "Make_min", float(np.nanmin(Make.values)), np.nanmin(Make.values) >= 0)
    a_cs = A.sum(axis=0).values
    _diag_add(rows, "A_shape", _fmt_shape(A.shape), A.shape == (15,15))
    _diag_add(rows, "A_colsum_min", float(a_cs.min()), a_cs.min() > 0)
    _diag_add(rows, "A_colsum_max", float(a_cs.max()), a_cs.max() < 1)
    rhoA = float(np.max(np.abs(np.linalg.eigvals(A.values))))
    _diag_add(rows, "rho(A)", rhoA, rhoA < 1)
    _diag_add(rows, "L_nat_shape", _fmt_shape(L_nat.shape), L_nat.shape == (15,15))
    _diag_add(rows, "L_nat_min", float(L_nat.values.min()), L_nat.values.min() >= 0)
    _diag_add(rows, "x_nat_len", int(x_nat.shape[0]), x_nat.shape[0] == 15)
    _diag_add(rows, "x_nat_min", float(x_nat.min()), x_nat.min() > 0)
    _diag_add(rows, "base_48x15_shape", _fmt_shape(base_48x15.shape), base_48x15.shape == (48,15))

    Ri_shape_ok = Ri.shape == (48,48,15)
    _diag_add(rows, "Ri_shape", f"{Ri.shape}", Ri_shape_ok)
    Ri_neg = (Ri < -1e-12).sum()
    _diag_add(rows, "Ri_negatives", int(Ri_neg), Ri_neg == 0)
    Ri_row_norm_err = float(np.abs(Ri.sum(axis=1) - 1.0).max())
    _diag_add(rows, "max|sum_s Ri[r,s,i]-1|", Ri_row_norm_err, Ri_row_norm_err < 1e-10)

    _diag_add(rows, "A_full_shape", _fmt_shape(A_full.shape), A_full.shape == (48*15,48*15))
    rhoAf = float(np.max(np.abs(np.linalg.eigvals(A_full.values))))
    _diag_add(rows, "rho(A_full)", rhoAf, rhoAf < 1)

    af_cs = A_full.sum(axis=0).values
    _diag_add(rows, "A_full_colsum_min", float(af_cs.min()), True, "info")
    _diag_add(rows, "A_full_colsum_max", float(af_cs.max()), True, "info (no <1 requirement)")
    _diag_add(rows, "A_full_colsum_mean", float(af_cs.mean()), True, "info")

    _diag_add(rows, "A_full_colsum_std", float(af_cs.std(ddof=0)), True)

    _diag_add(rows, "L_full_shape", _fmt_shape(L_full.shape), L_full.shape == (48*15,48*15))
    Lmin = float(L_full.values.min())
    _diag_add(rows, "L_full_min", Lmin, Lmin >= 0)
    Ldiag_min = float(np.diag(L_full.values).min())
    _diag_add(rows, "L_full_diag_min", Ldiag_min, Ldiag_min >= 1.0)
    try:
        M = np.eye(L_full.shape[0]) - A_full.values
        svals = np.linalg.svd(M, compute_uv=False)
        cond = float(svals.max() / max(svals.min(), 1e-16))
    except Exception:
        cond = float("nan")
    _diag_add(rows, "cond(I-A_full)", cond, np.isfinite(cond))

    summary = _as_df(rows, "diagnostics")
    out["Diag_Summary"] = summary

    df_A_colsums = pd.DataFrame({"A_colsum": A.sum(axis=0)}, index=A.columns)
    out["Diag_A_ColSums"] = df_A_colsums

    cols = pd.MultiIndex.from_product([STATES48, SECTORS15], names=["State","Sector"])
    af_colsum_ser = pd.Series(af_cs, index=cols, name="A_full_colsum")
    out["Diag_A_full_ColSums"] = af_colsum_ser.to_frame()

    A_colsum_vec = A.sum(axis=0).reindex(SECTORS15).values
    A_colsum_vec = np.where(A_colsum_vec == 0, np.nan, A_colsum_vec)
    ratios = af_cs.reshape(48,15) / A_colsum_vec.reshape(1,15)
    ratios_df = pd.DataFrame(ratios, index=STATES48, columns=SECTORS15)
    out["Diag_Afull_to_A_Colsum_Ratio_48x15"] = ratios_df

    Aij = A.reindex(index=SECTORS15, columns=SECTORS15).values
    w_ij = Aij / (Aij.sum(axis=0, keepdims=True) + 1e-12)
    Srs_i = Ri.sum(axis=1)  # 48x15 over r
    ratio_est = np.einsum("si,ij->sj", Srs_i, w_ij)
    out["Diag_Ratio_Est_48x15"] = pd.DataFrame(ratio_est, index=STATES48, columns=SECTORS15)
    out["Diag_Ratio_Est_Error_48x15"] = pd.DataFrame(ratios - ratio_est, index=STATES48, columns=SECTORS15)

    D_np = (A.values @ base_48x15.values.T).T
    w = D_np / (D_np.sum(axis=1, keepdims=True) + 1e-12)
    R_bar = (Ri * w[:, None, :]).sum(axis=2)
    Rbar_df = pd.DataFrame(R_bar, index=STATES48, columns=STATES48)
    out["Diag_Rbar_48x48"] = Rbar_df
    out["Diag_Rbar_RowSumErr"] = pd.Series(np.abs(R_bar.sum(axis=1) - 1.0), index=STATES48, name="abs(row_sum-1)")

    top_cols = (af_colsum_ser.sort_values(ascending=False).head(25)).to_frame()
    out["Diag_A_full_Top25_Colsums"] = top_cols


    return out

def scenario_diagnostics(name, d_vec, resp, by_state, by_sector, mat):
    out = {}
    rows = []
    tot_d = float(d_vec.sum())
    tot_resp = float(resp.sum())
    _diag_add(rows, "scenario", name, True)
    _diag_add(rows, "d_sum_musd", tot_d, True)
    _diag_add(rows, "resp_sum_musd", tot_resp, True)
    _diag_add(rows, "sign_check", "OK" if (tot_d <= 0 and tot_resp <= 0) or np.isclose(tot_resp,0) else "Warn", True)
    _diag_add(rows, "nonzero_d", int((d_vec!=0).sum()), True)
    _diag_add(rows, "nonneg_L", "OK" if (mat.values.min() >= -1e-9) else "NegEntries", True)
    out["Diag_"+name+"_Summary"] = _as_df(rows, "scenario_diag")

    out["Diag_"+name+"_TopStates"] = by_state.sort_values(ascending=True).head(25).to_frame(name="delta_output_musd")
    out["Diag_"+name+"_TopSectors"] = by_sector.sort_values(ascending=True).head(25).to_frame(name="delta_output_musd")
    out["Diag_"+name+"_Matrix"] = mat

    return out

def write_diagnostics_to_excel(writer, diag_dict):
    used = set()
    def _safe(name: str) -> str:
        s = str(name)
        s = re.sub(r"[:\\/?*\[\]]", "_", s).strip() or "Sheet"
        if len(s) > 31: s = s[:31]
        base, i = s, 1
        while s in used:
            suf = f"~{i}"
            s = base[:31 - len(suf)] + suf
            i += 1
        used.add(s)
        return s
    for k, v in diag_dict.items():
        sheet = _safe(k)
        if isinstance(v, pd.Series):
            v.to_excel(writer, sheet_name=sheet)
        else:
            v.to_excel(writer, sheet_name=sheet)

# ======================= END DIAGNOSTICS BLOCK =======================

 # ========================= 6) STOCHASTIC DISRUPTIONS =========================
# Advanced Monte Carlo with sector-network correlation + heavy tails.
# - Correlation across sector shocks comes from the symmetrized A (technology) matrix.
# - Heavy tails via Student-t scaling of the latent Gaussian (nu degrees of freedom).
# - Marginals are logit-normal in [0, max_k]; sector-specific (mu, sigma) control mean/tails.
# - Vectorized propagation: resp_all = - (L_full @ M) @ S', where S is (N×15) shock fractions.

def _sector_corr_from_A(A_15x15: pd.DataFrame, rho: float = 0.65, eps: float = 1e-12) -> np.ndarray:
    """
    Build a positive semidefinite 15x15 correlation matrix from A.
    Uses a diffusion-style kernel on the symmetrized matrix, then projects to Corr.
    """
    A = A_15x15.reindex(index=SECTORS15, columns=SECTORS15).values.astype(float)
    W = 0.5 * (A + A.T)
    # Normalize W to [0,1] scale
    if W.max() > 0:
        W = W / (W.max() + eps)
    # Diffusion kernel: K = (I - lambda*W)^(-1)  (well-defined for lambda<1)
    lam = 0.6
    I = np.eye(W.shape[0])
    K = np.linalg.inv(I - lam * W)
    # Convert to correlation
    S = K @ K.T
    d = np.sqrt(np.clip(np.diag(S), eps, None))
    Corr = (S / d[:, None]) / d[None, :]
    # Blend with identity to guarantee well-conditioned & PSD
    Corr = rho * Corr + (1 - rho) * I
    # Eigen clip (numerical PSD)
    w, V = np.linalg.eigh(Corr)
    w = np.clip(w, 1e-6, None)
    Corr = (V * w) @ V.T
    # Rescale to exact correlation
    d = np.sqrt(np.clip(np.diag(Corr), eps, None))
    Corr = (Corr / d[:, None]) / d[None, :]
    return Corr

def _sample_latent_shocks(
    N: int,
    Corr: np.ndarray,
    mode: str = "correlated_t",
    nu: int = 5,
    rng=None,
) -> np.ndarray:
    """
    Returns latent Y of shape (N, K).
    mode:
      - 'independent'   : iid Gaussian
      - 'correlated_gaussian'
      - 'correlated_t'
      - 'common_factor'
    """
    rng = np.random.default_rng() if rng is None else rng
    K = Corr.shape[0]

    if mode == "independent":
        return rng.standard_normal(size=(N, K))

    if mode == "common_factor":
        f = rng.standard_normal(size=(N, 1))
        e = rng.standard_normal(size=(N, K))
        return 0.8 * f + 0.2 * e

    w, V = np.linalg.eigh(Corr)
    L = V @ np.diag(np.sqrt(np.clip(w, 1e-9, None)))
    Z = rng.standard_normal(size=(N, K))
    G = Z @ L.T

    if mode == "correlated_gaussian":
        return G

    if mode == "correlated_t":
        chi = rng.chisquare(df=nu, size=N) / nu
        return G / np.sqrt(chi)[:, None]

    raise ValueError(f"Unknown latent shock mode: {mode}")

def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))

def _build_stochastic_params(A_15x15: pd.DataFrame,
                             ca_output_musd: pd.Series) -> dict:
    # Max fraction caps (edit if you wish)
    max_frac = pd.Series(0.35, index=SECTORS15)
    max_frac["Transportation and warehousing"] = 0.50  # keep headroom where shocks can be large
    N_plot_samples= 200  # how many draws to show in spaghetti charts

    # Neutral sector means — let the network tell us what matters
    mean_frac = pd.Series(0.04, index=SECTORS15)

    # Convert to approximate logit-normal mu, set sigma for heavy tails
    mu = (mean_frac.clip(1e-4, 1-1e-4) / (1 - mean_frac.clip(1e-4, 1-1e-4))).apply(np.log)
    sigma = pd.Series(0.9, index=SECTORS15)

    return {
        "max_frac": max_frac,
        "mu": mu,
        "sigma": sigma,
        "rho_corr": 0.65,
        "nu_df": 5,
        "N_sims": 2000,        # CA-only PoLA MC
        "N_sims_all": 2000,    # All-origins MC
        "lam_states": 3.0,     # mean # of origin states per scenario in all-origins
        "seed": 42
    }


def _precompute_response_kernel(L_full: pd.DataFrame,
                                ca_output_musd: pd.Series,
                                states=STATES48,
                                sectors=SECTORS15,
                                pola_share=POLA_DEFAULT) -> np.ndarray:
    """
    Build G = L_full @ M, where M maps a 15-vector of sector shock fractions 's' to
    a 720-vector 'd' with entries only in (CA, k):  d_CA,k = pola_share * s_k * CA_output_k.
    Note we define s_k >= 0 here and apply negative sign when multiplying later.
    """
    K = len(sectors)
    SK = len(states) * K
    M = np.zeros((SK, K), dtype=float)
    ca_idx0 = states.index(CA_CODE) * K
    for j, sec in enumerate(sectors):
        M[ca_idx0 + j, j] = float(pola_share) * float(ca_output_musd.get(sec, 0.0))
    G = L_full.values @ M
    return G  # shape 720×15

def _precompute_kernel_allorigins(L_full: pd.DataFrame,
                                  X_go: pd.DataFrame,
                                  states=STATES48,
                                  sectors=SECTORS15) -> np.ndarray:
    """
    Build H (720×720) so that for a vector s (720,) of *fractions* at each (state,sector),
    the direct-demand vector is d = diag(X_go_stack) @ s, and RESP = -(L_full @ d) = -(H @ s).
    """
    X0 = X_go.reindex(index=states, columns=sectors).stack().astype(float).values  # (720,)
    M = np.diag(X0)  # 720×720
    H = L_full.values @ M
    return H

def _sample_all_origin_shocks(N: int,
                              Corr: np.ndarray,
                              X_go: pd.DataFrame,
                              params: dict,
                              rng=None) -> np.ndarray:
    """
    Returns S_all of shape (N, 48*15) with per-(state,sector) fractions in [0,1).
    In each scenario:
      - draw m ~ Poisson(lam_states), choose m states weighted by state GO
      - draw a single sector profile via correlated-t latent shocks -> logit-normal
      - give each active state its own severity scalar a_r (lognormal)
    """
    rng = np.random.default_rng(params.get("seed", None)) if rng is None else rng
    K = len(SECTORS15)
    S = len(STATES48)

    # state weights ∝ size
    w_state = X_go.sum(axis=1).reindex(STATES48).astype(float).values
    w_state = w_state / (w_state.sum() if w_state.sum() > 0 else 1.0)

    # sector marginals
    mu_vec = params["mu"].reindex(SECTORS15).values
    sg_vec = params["sigma"].reindex(SECTORS15).values
    max_vec = params["max_frac"].reindex(SECTORS15).values

    # latent sector copula for all-origins experiment
    Y = _sample_latent_shocks(
        N,
        Corr,
        mode="correlated_t",
        nu=params["nu_df"],
        rng=rng,
    )
    U = _sigmoid(mu_vec[None, :] + sg_vec[None, :] * Y)
    base_sec = np.clip(U * max_vec[None, :], 0.0, 0.999)

    S_all = np.zeros((N, S * K), dtype=float)
    for n in range(N):
        m = max(1, rng.poisson(params.get("lam_states", 3.0)))
        m = min(m, S)
        active = rng.choice(np.arange(S), size=m, replace=False, p=w_state)
        a = np.exp(rng.normal(loc=0.0, scale=0.5, size=m))  # lognormal(0,0.5)

        for j, r in enumerate(active):
            row = np.clip(a[j] * base_sec[n, :], 0.0, 0.999)
            S_all[n, r*K:(r+1)*K] = row

    return S_all

def _perm_test_group_means(X: np.ndarray, B: int = 1000, rng=None):
    """
    X: N×G nonnegative contributions per scenario×group (e.g., sectors or states).
    Returns (obs_means, pvals) where pvals are right-tail permutation p-values.
    """
    rng = np.random.default_rng() if rng is None else rng
    N, G = X.shape
    obs = X.mean(axis=0)
    # permute labels within each scenario
    count = np.zeros(G, dtype=int)
    for _ in range(B):
        acc = np.zeros(G, dtype=float)
        for n in range(N):
            perm = rng.permutation(G)
            acc += X[n, perm]
        m_perm = acc / N
        count += (m_perm >= obs).astype(int)
    p = (count + 1) / (B + 1)
    return obs, p

def _bh_fdr(pvals: np.ndarray, alpha: float = 0.10):
    """Benjamini–Hochberg FDR; returns boolean mask of discoveries."""
    idx = np.argsort(pvals)
    m = len(pvals)
    thresh = alpha * (np.arange(1, m+1) / m)
    passed = np.zeros(m, dtype=bool)
    passed[idx] = pvals[idx] <= thresh
    return passed


def _stats(arr, axis=0, q=(5, 50, 95)):
    """
    Return mean and (p5, p50, p95) along axis.
    """
    mean = np.nanmean(arr, axis=axis)
    qs = np.nanpercentile(arr, q, axis=axis)
    return mean, qs  # qs.shape = (len(q), ...)
def plot_concentration_without_top_direct_shock(
    S_frac: np.ndarray,          # N×15 direct shock fractions (your S_frac)
    by_sector_all: np.ndarray,   # 15×N total losses by destination sector (your by_sector_all)
    path,
    top_k: int = 3,
):
    """
    Bar chart of P(sector in top-k LOSSES | sector not in top-k DIRECT shocks).
    Overlays unconditional P(sector in top-k LOSSES) as black dots.
    Returns a DataFrame with the probabilities and denominators.
    """
    direct = np.asarray(S_frac, dtype=float)             # N×K
    loss   = np.asarray(-by_sector_all.T, dtype=float)   # N×K (magnitudes; positive)

    N, K = direct.shape
    if loss.shape != (N, K):
        raise ValueError(f"Shape mismatch: direct {direct.shape} vs loss {loss.shape}")

    def _topk_mask(M, k):
        k = max(1, min(int(k), M.shape[1]))
        idx = np.argpartition(M, -k, axis=1)[:, -k:]     # N×k (unordered)
        mask = np.zeros_like(M, dtype=bool)
        rows = np.arange(M.shape[0])[:, None]
        mask[rows, idx] = True
        return mask

    top_shock = _topk_mask(direct, top_k)
    top_loss  = _topk_mask(loss,   top_k)

    eligible = ~top_shock  # scenarios where sector is NOT in top-k direct shocks
    denom = eligible.sum(axis=0).astype(float)
    denom = np.where(denom <= 0, np.nan, denom)

    cond_prob  = (top_loss & eligible).sum(axis=0) / denom
    uncond_prob = top_loss.mean(axis=0)

    # order sectors by conditional probability (descending)
    order = np.argsort(np.nan_to_num(cond_prob, nan=-1.0))[::-1]

    labels = [str(SECTOR_NUM[s]) for s in SECTORS15]  # sector numbers on x-axis
    x = np.arange(K)

    fig, ax = plt.subplots(figsize=(11.5, 5.8))
    ax.bar(x, cond_prob[order])
    ax.scatter(x, uncond_prob[order], s=35, marker="o", color="black",
               label=f"Unconditional P(top {top_k} loss)")

    ax.set_xticks(x)
    ax.set_xticklabels([labels[i] for i in order],
                       fontsize=13, fontweight="normal", fontname=DEFAULT_FONT)

    ax.set_ylim(0, 1)
    ax.set_xlabel("Sector # (sorted by conditional probability)",
                  fontsize=14, fontweight="bold", fontname=DEFAULT_FONT)
    ax.set_ylabel(f"P(sector in top {top_k} losses | not top {top_k} direct shocks)",
                  fontsize=14, fontweight="bold", fontname=DEFAULT_FONT)
    ax.grid(True, axis="y", linestyle=":", alpha=0.6)
    ax.legend(frameon=False, fontsize=12)

    fig.tight_layout()
    fig.savefig(path.with_suffix(".pdf"))
    plt.close(fig)

    out = pd.DataFrame({
        "sector": SECTORS15,
        "sector_num": [SECTOR_NUM[s] for s in SECTORS15],
        f"cond_P_top{top_k}loss_given_not_top{top_k}shock": cond_prob,
        f"uncond_P_top{top_k}loss": uncond_prob,
        f"eligible_count_not_top{top_k}shock": eligible.sum(axis=0),
    }).set_index("sector")

    return out

def run_stochastic(A_15x15: pd.DataFrame,
                   L_full: pd.DataFrame,
                   X_go: pd.DataFrame,
                   base_48x15: pd.DataFrame,
                   ca_output_musd: pd.Series,
                   outdir: Path,
                   subdir: Path):
    """
    Main stochastic engine.
    Outputs:
      - Excel: 'Stochastic_Disruptions.xlsx' under subdir
      - Figures: mean/p95 heatmaps, total-loss histogram, influence plots, sample panels
      - New dependence comparison: independent vs correlated Gaussian vs correlated t
    """
    subdir.mkdir(parents=True, exist_ok=True)

    params = _build_stochastic_params(A_15x15, ca_output_musd)
    N = int(params["N_sims"])
    N2 = int(params.get("N_sims_all", N))
    rng = np.random.default_rng(params["seed"])

    Corr = _sector_corr_from_A(A_15x15, rho=params["rho_corr"])

    shock_regimes = {
        "independent": "independent",
        "correlated_gaussian": "correlated_gaussian",
        "correlated_t": "correlated_t",
    }

    regime_outputs = {}

    mu_vec = params["mu"].reindex(SECTORS15).values
    sg_vec = params["sigma"].reindex(SECTORS15).values
    max_vec = params["max_frac"].reindex(SECTORS15).values

    G = _precompute_response_kernel(L_full, ca_output_musd, STATES48, SECTORS15, POLA_DEFAULT)

    for regime_name, latent_mode in shock_regimes.items():
        Y = _sample_latent_shocks(
            N,
            Corr,
            mode=latent_mode,
            nu=params["nu_df"],
            rng=rng,
        )

        U = _sigmoid(mu_vec[None, :] + sg_vec[None, :] * Y)
        S_frac = np.clip(U * max_vec[None, :], 0.0, 0.999)

        RESP = -(G @ S_frac.T)  # 720 x N
        R3 = RESP.reshape((len(STATES48), len(SECTORS15), N))

        by_state_all = R3.sum(axis=1)    # 48 x N
        by_sector_all = R3.sum(axis=0)   # 15 x N
        total_all = by_state_all.sum(axis=0)

        X0 = X_go.reindex(index=STATES48, columns=SECTORS15).values
        X0[X0 <= 0] = np.nan
        Q3 = np.clip((-R3) / X0[:, :, None], 0.0, 1.0)

        mean_mat, q_mat = _stats(R3, axis=2, q=(5, 50, 95))
        mean_q, q_q = _stats(Q3, axis=2, q=(5, 50, 95))
        mean_state, q_state = _stats(by_state_all, axis=1, q=(5, 50, 95))
        mean_sector, q_sector = _stats(by_sector_all, axis=1, q=(5, 50, 95))
        total_loss_all = np.clip(-total_all, 0.0, None)
        mean_total = float(np.nanmean(total_loss_all))
        q_total = np.nanpercentile(total_loss_all, [5, 50, 95])

        regime_outputs[regime_name] = {
            "S_frac": S_frac,
            "R3": R3,
            "Q3": Q3,
            "by_state_all": by_state_all,
            "by_sector_all": by_sector_all,
            "total_all": total_all,
            "df_mean": pd.DataFrame(mean_mat, index=STATES48, columns=SECTORS15),
            "df_p05": pd.DataFrame(q_mat[0], index=STATES48, columns=SECTORS15),
            "df_p50": pd.DataFrame(q_mat[1], index=STATES48, columns=SECTORS15),
            "df_p95": pd.DataFrame(q_mat[2], index=STATES48, columns=SECTORS15),
            "df_q_mean": pd.DataFrame(mean_q, index=STATES48, columns=SECTORS15),
            "df_q_p95": pd.DataFrame(q_q[2], index=STATES48, columns=SECTORS15),
            "df_state_stats": pd.DataFrame(
                {"mean": mean_state, "p05": q_state[0], "p50": q_state[1], "p95": q_state[2]},
                index=STATES48
            ),
            "df_sector_stats": pd.DataFrame(
                {"mean": mean_sector, "p05": q_sector[0], "p50": q_sector[1], "p95": q_sector[2]},
                index=SECTORS15
            ),
            "mean_total": mean_total,
            "q_total": q_total,
        }

    # choose correlated-t as the main baseline regime for all legacy outputs
    baseline_regime = "correlated_t"
    base_out = regime_outputs[baseline_regime]

    S_frac = base_out["S_frac"]
    R3 = base_out["R3"]
    Q3 = base_out["Q3"]
    by_state_all = base_out["by_state_all"]
    by_sector_all = base_out["by_sector_all"]
    total_all = base_out["total_all"]

    df_mean = base_out["df_mean"]
    df_p05 = base_out["df_p05"]
    df_p50 = base_out["df_p50"]
    df_p95 = base_out["df_p95"]
    df_q_mean = base_out["df_q_mean"]
    df_q_p95 = base_out["df_q_p95"]
    df_state_stats = base_out["df_state_stats"]
    df_sector_stats = base_out["df_sector_stats"]
    mean_total = base_out["mean_total"]
    q_total = base_out["q_total"]

    comparison_rows = []
    for regime_name, out in regime_outputs.items():
        total_reg_signed = np.asarray(out["total_all"], dtype=float)   # signed MRIO response
        by_sector_reg = np.asarray(out["by_sector_all"], dtype=float)  # 15 x N signed

        # Convert to positive loss magnitudes for interpretation
        total_loss_reg = np.clip(-total_reg_signed, 0.0, None)         # N
        loss_sector_reg = np.clip(-by_sector_reg.T, 0.0, None)         # N x 15

        top3 = np.argsort(loss_sector_reg, axis=1)[:, -3:]

        mfg_idx = SECTORS15.index("Manufacturing")
        tw_idx = SECTORS15.index("Transportation and warehousing")

        mfg_top3 = np.mean(np.any(top3 == mfg_idx, axis=1))
        tw_top3 = np.mean(np.any(top3 == tw_idx, axis=1))

        p50 = float(np.nanpercentile(total_loss_reg, 50))
        p95 = float(np.nanpercentile(total_loss_reg, 95))
        mean_loss = float(np.nanmean(total_loss_reg))
        concentration = p95 / max(p50, 1e-9)

        comparison_rows.append({
            "regime": regime_name,
            "mean_total_loss_musd": mean_loss,
            "p50_total_loss_musd": p50,
            "p95_total_loss_musd": p95,
            "p95_over_p50": concentration,
            "mfg_top3_freq": float(mfg_top3),
            "tw_top3_freq": float(tw_top3),
        })

    df_regime_compare = pd.DataFrame(comparison_rows)

    sec_nums = [f"{SECTOR_NUM[s]}" for s in SECTORS15]

    shock_pct = 100.0 * S_frac
    q_shock = np.percentile(shock_pct, [5, 50, 95], axis=0)

    plot_sector_quantile_ribbon(
        sec_nums, q_shock[0], q_shock[1], q_shock[2],
        "CA-only stochastic sector disruptions (p05-p95 band; median)",
        subdir / "CAonly_sector_shock_quantile_ribbon.png",
        ylabel="% disruption"
    )

    loss_sector = (-by_sector_all.T)
    q_loss = np.percentile(loss_sector, [5, 50, 95], axis=0)

    plot_sector_quantile_ribbon(
        sec_nums, q_loss[0], q_loss[1], q_loss[2],
        "CA-only stochastic national losses by sector (p05-p95 band; median)",
        subdir / "CAonly_sector_loss_quantile_ribbon.png",
        ylabel="million $ loss"
    )

    plot_sector_spaghetti_billion(
        samples=loss_sector[:params.get("N_plot_samples", 200), :],
        path=subdir / "CAonly_sector_loss_spaghetti.png",
        ylabel="National loss (billion $)",
        max_lines=params.get("N_plot_samples", 200)
    )

    plot_sector_spaghetti(
        samples=shock_pct[:params.get("N_plot_samples", 200), :],
        path=subdir / "CAonly_sector_shock_spaghetti.png",
        ylabel="Direct sectoral shock (%)",
        max_lines=params.get("N_plot_samples", 200)
    )

    mean_flat_dest = df_mean.stack().sort_values(ascending=True)
    top_pairs_dest = mean_flat_dest.head(200).rename("mean_loss_musd").to_frame()

    w_ca = G.sum(axis=0)
    contrib_ca = S_frac * w_ca[None, :]
    df_ca_influence = pd.DataFrame({
        "mean_contrib_musd": contrib_ca.mean(axis=0),
        "p95_contrib_musd": np.percentile(contrib_ca, 95, axis=0),
        "multiplier_per_1pct_musd": 0.01 * w_ca,
    }, index=pd.Index(SECTORS15, name="Sector")).sort_values("mean_contrib_musd", ascending=False)

    H = _precompute_kernel_allorigins(L_full, X_go, STATES48, SECTORS15)
    S_all = _sample_all_origin_shocks(N2, Corr, X_go, params, rng=rng)
    RESP_all = -(H @ S_all.T)
    R3_all = RESP_all.reshape(len(STATES48), len(SECTORS15), N2)

    w_all = H.sum(axis=0)
    contrib_all = S_all * w_all[None, :]

    K = len(SECTORS15)
    S = len(STATES48)

    contrib_all_sec = contrib_all.reshape(N2, S, K).sum(axis=1)
    df_all_sec = pd.DataFrame({
        "mean_contrib_musd": contrib_all_sec.mean(axis=0),
        "p95_contrib_musd": np.percentile(contrib_all_sec, 95, axis=0),
        "multiplier_per_1pct_musd": 0.01 * w_all.reshape(S, K).sum(axis=0),
    }, index=pd.Index(SECTORS15, name="Sector")).sort_values("mean_contrib_musd", ascending=False)

    contrib_all_state = contrib_all.reshape(N2, S, K).sum(axis=2)
    df_all_state = pd.DataFrame({
        "mean_contrib_musd": contrib_all_state.mean(axis=0),
        "p95_contrib_musd": np.percentile(contrib_all_state, 95, axis=0),
        "multiplier_per_1pct_musd": 0.01 * w_all.reshape(S, K).sum(axis=1),
    }, index=pd.Index(STATES48, name="State")).sort_values("mean_contrib_musd", ascending=False)

    regions = pd.Index([STATE_TO_REGION[s] for s in STATES48], name="Region")
    Rnames = regions.unique().tolist()
    Rmap = pd.DataFrame(0, index=Rnames, columns=STATES48, dtype=int)
    for s_name, r_name in zip(STATES48, regions):
        Rmap.loc[r_name, s_name] = 1

    contrib_all_region = (contrib_all_state @ Rmap.T.values)
    df_all_region = pd.DataFrame({
        "mean_contrib_musd": contrib_all_region.mean(axis=0),
        "p95_contrib_musd": np.percentile(contrib_all_region, 95, axis=0),
    }, index=pd.Index(Rnames, name="Region")).sort_values("mean_contrib_musd", ascending=False)

    w_rs = w_all.reshape(S, K)
    df_inf_rs = pd.DataFrame(w_rs, index=STATES48, columns=SECTORS15)
    df_inf_rs_region = pd.DataFrame(Rmap.values @ df_inf_rs.values, index=Rnames, columns=SECTORS15)

    mean_pair_origin = contrib_all.mean(axis=0)
    idx_pairs = pd.MultiIndex.from_product([STATES48, SECTORS15], names=["State", "Sector"])
    df_top_pairs_origin = (
        pd.Series(mean_pair_origin, index=idx_pairs, name="mean_contrib_musd")
        .sort_values(ascending=False)
        .head(200)
        .to_frame()
    )

    obs_sec, p_sec = _perm_test_group_means(contrib_all_sec, B=1000, rng=rng)
    obs_state, p_state = _perm_test_group_means(contrib_all_state, B=1000, rng=rng)
    sig_sec = _bh_fdr(p_sec, alpha=0.10)
    sig_state = _bh_fdr(p_state, alpha=0.10)

    df_perm_sector = pd.DataFrame(
        {"mean_contrib_musd": obs_sec, "p_value": p_sec, "FDR10%": sig_sec},
        index=pd.Index(SECTORS15, name="Sector")
    ).sort_values("mean_contrib_musd", ascending=False)

    df_perm_state = pd.DataFrame(
        {"mean_contrib_musd": obs_state, "p_value": p_state, "FDR10%": sig_state},
        index=pd.Index(STATES48, name="State")
    ).sort_values("mean_contrib_musd", ascending=False)

    xls_path = subdir / "Stochastic_Disruptions.xlsx"
    with pd.ExcelWriter(xls_path, engine="xlsxwriter") as writer:
        pd.DataFrame({
            "value": [
                POLA_DEFAULT,
                HB if "HB" in globals() else np.nan,
                params["rho_corr"],
                params["nu_df"],
                params["N_sims"],
                params.get("N_sims_all", np.nan),
            ],
            "note": [
                "PoLA share",
                "home_bias used in Ri",
                "sector-shock correlation blend rho",
                "Student-t df",
                "CA-only MC draws",
                "All-origins MC draws",
            ],
        }, index=["pola_share", "home_bias", "rho_corr", "nu_df", "N_sims", "N_sims_all"]).to_excel(writer, sheet_name="Params")

        pd.DataFrame({"max_frac": params["max_frac"], "mu": params["mu"], "sigma": params["sigma"]}).to_excel(
            writer, sheet_name="Sector_Params"
        )

        pd.DataFrame(q_shock.T, index=SECTORS15, columns=["p05_%", "p50_%", "p95_%"]).to_excel(
            writer, sheet_name="ShockSector_quantiles_pct"
        )
        pd.DataFrame(q_loss.T, index=SECTORS15, columns=["p05_musd", "p50_musd", "p95_musd"]).to_excel(
            writer, sheet_name="LossBySector_quantiles"
        )

        df_regime_compare.to_excel(writer, sheet_name="Dependence_Comparison", index=False)
        for regime_name, out in regime_outputs.items():
            out["df_mean"].to_excel(writer, sheet_name=f"{regime_name[:12]}_Mean")
            out["df_p95"].to_excel(writer, sheet_name=f"{regime_name[:12]}_P95")

        df_state_stats.to_excel(writer, sheet_name="ByState_stats")
        df_sector_stats.to_excel(writer, sheet_name="BySector_stats")
        df_mean.to_excel(writer, sheet_name="Mean_StateSector")
        df_p95.to_excel(writer, sheet_name="P95_StateSector")
        df_q_mean.to_excel(writer, sheet_name="Mean_q")
        df_q_p95.to_excel(writer, sheet_name="P95_q")
        top_pairs_dest.to_excel(writer, sheet_name="Top200_DestinationPairs")

        df_ca_influence.to_excel(writer, sheet_name="CAonly_Influence_Sector")
        df_all_sec.to_excel(writer, sheet_name="AllOrigins_Influence_Sector")
        df_all_state.to_excel(writer, sheet_name="AllOrigins_Influence_State")
        df_all_region.to_excel(writer, sheet_name="AllOrigins_Influence_Region")
        df_inf_rs_region.to_excel(writer, sheet_name="AllOrigins_RegionxSector")
        df_top_pairs_origin.to_excel(writer, sheet_name="AllOrigins_Top200_OriginPairs")
        df_perm_sector.to_excel(writer, sheet_name="PermTest_Sector_All")
        df_perm_state.to_excel(writer, sheet_name="PermTest_State_All")

        pd.DataFrame(S_frac, columns=SECTORS15).head(200).to_excel(
            writer, sheet_name="ShockSamples_CAonly_head", index=False
        )

        pd.DataFrame({
            "mean_total_loss": [mean_total],
            "p05_total": [q_total[0]],
            "p50_total": [q_total[1]],
            "p95_total": [q_total[2]],
        }).to_excel(writer, sheet_name="TotalLoss_CAonly_summary", index=False)

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(df_regime_compare["regime"], df_regime_compare["p95_over_p50"])
    ax.set_xlabel("Shock dependence regime")
    ax.set_ylabel("p95 / p50 total loss")
    ax.set_title("Loss concentration by shock dependence regime")
    ax.grid(True, axis="y", linestyle=":", alpha=0.5)
    plt.tight_layout()
    plt.savefig((subdir / "Dependence_Regime_Comparison").with_suffix(".pdf"))
    plt.close(fig)

    def _hmap(M, path, cbar_label="within-sector relative intensity",
              sort_states=True, use_regional=False):
        norm_mode = "col" if use_regional else None
        plot_heatmap(
            pd.DataFrame(M, index=STATES48, columns=SECTORS15),
            None,
            path,
            vcenter=False,
            scale="asinh",
            normalize=norm_mode,
            sort_states=sort_states,
            loss_only=True,
            cbar_label=cbar_label
        )

    _hmap(df_mean, subdir / "Stoch_Mean_matrix_REGIONAL.png", use_regional=True)
    _hmap(df_p95, subdir / "Stoch_P95_matrix_REGIONAL.png", use_regional=True)
    _hmap(df_mean, subdir / "Stoch_Mean_matrix_GLOBAL.png", use_regional=False)

    fig, ax = plt.subplots(figsize=(9, 5.5))
    ax.hist(total_loss_all, bins=40)
    ax.set_xlabel("Total loss (million $)")
    ax.set_ylabel("count")
    ax.grid(True, axis="y", linestyle=":", alpha=0.5)
    fig.tight_layout()
    fig.savefig((subdir / "Stoch_TotalLoss_hist_CAonly").with_suffix(".pdf"))
    plt.close(fig)

    plot_sector_bars(
        pd.Series(0.01 * w_ca, index=SECTORS15),
        "CA-only: influence per 1% sector shock (million $)",
        subdir / "CAonly_influence_per1pct_sectors.png",
        top_n=15,
        subtitle="Loss per 1% fractional CA disruption in sector k"
    )

    inf_rs_per1pct = pd.DataFrame(0.01 * w_all.reshape(S, K), index=STATES48, columns=SECTORS15)
    plot_heatmap(
        inf_rs_per1pct,
        "All-origins: influence per 1% at origin (statexsector)",
        subdir / "AllOrigins_influence_per1pct_matrix.png",
        vcenter=False, scale="asinh",
        sort_states=True, quant=0.985,
        loss_only=True, cbar_label="million $ per 1% origin shock"
    )

    plot_state_bars(
        df_all_state["mean_contrib_musd"].sort_values(),
        "All-origins: mean origin-state contribution (million $)",
        subdir / "AllOrigins_mean_contrib_states.png",
        top_n=25
    )

    example_ids = [0, 1, 2, 3, 4, 5] if N >= 6 else list(range(min(N, 3)))
    for sid in example_ids:
        s_row = (100.0 * S_frac[sid, :]).astype(float)
        fig, ax = plt.subplots(figsize=(10, 4.3))
        labs = [f"{SECTOR_NUM[s]}" for s in SECTORS15]
        ax.bar(range(15), s_row)
        ax.set_xticks(range(15))
        ax.set_xticklabels(labs)
        ax.set_ylabel("% disruption")
        ax.set_xlabel("Sector #")
        ax.grid(True, axis="y", linestyle=":", alpha=0.5)
        fig.tight_layout()
        fig.savefig(subdir / f"Sample_{sid}_shocks.png", dpi=300)
        plt.close(fig)

        mat_sid = R3[:, :, sid]
        plot_heatmap(
            pd.DataFrame(mat_sid, index=STATES48, columns=SECTORS15),
            f"Sample {sid}: StatexSector losses (million $) - CA-only",
            subdir / f"Sample_{sid}_impact.png",
            vcenter=False, scale="asinh",
            sort_states=True, quant=0.985, loss_only=True,
            subtitle=f"PoLA share={POLA_DEFAULT:.0%} | stochastic draw {sid}",
            cbar_label="million $ loss"
        )

    print("[Stochastic/CA-only] top sectors by mean contribution (million $):")
    print(df_ca_influence.head(10).to_string(float_format=lambda x: f"{x:,.1f}"))
    print("[All-origins] top sectors by mean contribution (million $):")
    print(df_all_sec.head(10).to_string(float_format=lambda x: f"{x:,.1f}"))
    print("[All-origins] top states by mean contribution (million $):")
    print(df_all_state.head(10).to_string(float_format=lambda x: f"{x:,.1f}"))
    print("[All-origins] permutation test (sector) - FDR 10% discoveries:",
          list(df_perm_sector.index[df_perm_sector["FDR10%"]]))
    print("[All-origins] permutation test (state) - FDR 10% discoveries:",
          list(df_perm_state.index[df_perm_state["FDR10%"]]))
    print("Stochastic results saved:")
    print("  Excel:", str(xls_path))
    print("  Figures in:", str(subdir))


def run_Afull_column_symmetry_diagnostics(A_15x15: pd.DataFrame,
                                         Ri: np.ndarray,
                                         A_full: pd.DataFrame,
                                         states=STATES48,
                                         sectors=SECTORS15,
                                         top_n: int = 30):
    K = len(sectors)
    S = len(states)

    A = A_15x15.reindex(index=sectors, columns=sectors).values.astype(float)

    # ---- 1) Actual A_full column sums reshaped to (dest_state × dest_sector)
    af_cs = A_full.sum(axis=0).values.astype(float)              # length S*K
    af_cs_mat = af_cs.reshape(S, K)
    af_cs_df = pd.DataFrame(af_cs_mat, index=states, columns=sectors)

    # ---- 2) Inbound mixing mass implied by Ri:  M[s,i] = sum_r Ri[r,s,i]
    M_si = Ri.sum(axis=0)                                        # (dest_state s) × (row-sector i)  => S×K
    M_df = pd.DataFrame(M_si, index=states, columns=sectors)

    # ---- 3) Predicted column sums from identity:
    # A_full column (s,j) sum = sum_i [ A[i,j] * M[s,i] ].
    pred_cs_mat = M_si @ A                                       # (S×K) @ (K×K) = S×K
    pred_cs_df = pd.DataFrame(pred_cs_mat, index=states, columns=sectors)

    # ---- 4) Error maps
    err_mat = af_cs_mat - pred_cs_mat
    abs_err_mat = np.abs(err_mat)
    err_df = pd.DataFrame(err_mat, index=states, columns=sectors)
    abs_err_df = pd.DataFrame(abs_err_mat, index=states, columns=sectors)

    max_abs = float(abs_err_mat.max())
    arg = np.unravel_index(np.argmax(abs_err_mat), abs_err_mat.shape)
    worst_state = states[arg[0]]
    worst_sector = sectors[arg[1]]
    worst_signed = float(err_mat[arg])

    # ---- 5) Flat top offenders (by |error|)
    idx_cols = pd.MultiIndex.from_product([states, sectors], names=["DestState", "DestSector"])
    top_offenders = (
        pd.Series(abs_err_mat.reshape(-1), index=idx_cols, name="abs_error")
        .sort_values(ascending=False)
        .head(top_n)
        .to_frame()
    )
    top_offenders["signed_error"] = pd.Series(err_mat.reshape(-1), index=idx_cols).loc[top_offenders.index].values
    top_offenders["Afull_colsum"] = pd.Series(af_cs, index=idx_cols).loc[top_offenders.index].values
    top_offenders["Pred_colsum"]  = pd.Series(pred_cs_mat.reshape(-1), index=idx_cols).loc[top_offenders.index].values

    # ---- 6) How “non-uniform” inbound mixing is across destination states
    M_stats = pd.DataFrame({
        "M_sum_over_states": M_df.sum(axis=0).values,
        "M_min_over_states": M_df.min(axis=0).values,
        "M_max_over_states": M_df.max(axis=0).values,
        "M_std_over_states": M_df.std(axis=0).values,
    }, index=pd.Index(sectors, name="RowSector_i"))

    # ---- 7) Column-sum drivers by destination state (aggregate over destination sectors)
    # State-level total predicted colsum = sum_j pred_cs[s,j]
    state_totals = pd.DataFrame({
        "Afull_total_colsum": af_cs_df.sum(axis=1),
        "Pred_total_colsum":  pred_cs_df.sum(axis=1),
        "Total_error":        (af_cs_df.sum(axis=1) - pred_cs_df.sum(axis=1)),
    }, index=pd.Index(states, name="DestState"))

    # ---- 8) Sector-level totals over states (aggregate over destination states)
    sector_totals = pd.DataFrame({
        "Afull_total_colsum": af_cs_df.sum(axis=0),
        "Pred_total_colsum":  pred_cs_df.sum(axis=0),
        "Total_error":        (af_cs_df.sum(axis=0) - pred_cs_df.sum(axis=0)),
    }, index=pd.Index(sectors, name="DestSector_j"))

    # ---- 9) Summary scalars
    summary = pd.DataFrame([
        ["Afull_colsum_max_abs_error", max_abs, True, f"worst at ({worst_state}, {worst_sector}), signed={worst_signed:.6g}"],
        ["Afull_colsum_mean_abs_error", float(abs_err_mat.mean()), True, ""],
        ["Afull_colsum_median_abs_error", float(np.median(abs_err_mat)), True, ""],
        ["M_si_row_norm_err_max", float(np.abs(Ri.sum(axis=1) - 1.0).max()), True, "should be ~0 (your existing check)"],
        ["M_si_range_max", float((M_df.max(axis=0) - M_df.min(axis=0)).max()), True, "large => destination states receive very different inbound mass"],
    ], columns=["metric", "value", "info", "note"])

    return {
        "Diag_AfullColSum_Summary": summary,
        "Diag_Afull_ColSums_Actual_48x15": af_cs_df,
        "Diag_Afull_ColSums_Pred_48x15": pred_cs_df,
        "Diag_Afull_ColSums_Error_48x15": err_df,
        "Diag_Afull_ColSums_AbsError_48x15": abs_err_df,
        "Diag_Ri_InboundMass_M_si_48x15": M_df,
        "Diag_Ri_InboundMass_Stats_byRowSector": M_stats,
        "Diag_AfullColSum_TopOffenders": top_offenders,
        "Diag_AfullColSum_StateTotals": state_totals.sort_values("Afull_total_colsum", ascending=False),
        "Diag_AfullColSum_SectorTotals": sector_totals.sort_values("Afull_total_colsum", ascending=False),
    }

def unit_impulse_test(L_full):
    d = pd.Series(0.0, index=L_full.index)
    d.loc[("CA", "Manufacturing")] = -1.0

    resp = L_full @ d
    mat = resp.unstack().reindex(index=STATES48, columns=SECTORS15).fillna(0.0)

    plot_heatmap(
        mat,
        "Unit impulse propagation: CA Manufacturing → all (col-normalized)",
        OUTDIR / "unit_impulse_CA_Mfg.png",
        vcenter=False,
        scale="asinh",
        normalize="col",
        loss_only=True,
        sort_states=True,
        cbar_label="within-sector relative intensity"
    )

def timed_call(name, func, *args, **kwargs):
    t0 = time.perf_counter()
    out = func(*args, **kwargs)
    dt = time.perf_counter() - t0
    print(f"[Timing] {name}: {dt:,.2f} sec")
    return out, dt
def run_stability_checks(L_full: pd.DataFrame, n_rep: int = 10) -> pd.DataFrame:
    """
    Re-run the ABM and RL paired comparison under multiple seeds to document
    stability of key outputs for reproducibility / reviewer response.
    """
    rows = []

    for sd in range(n_rep):
        abm_res = freight_abm.run_abm(
            include_inbound=True,
            abm_params={"seed": int(sd)},
            run_polb_switching=False,
        )

        rl_res = freight_abm.run_rl_paired_comparison(
            abm_baseline_results=abm_res,
            L_full=L_full,
            n_realizations=1000,
            seed=int(sd),
            out_dir=None,
        )

        row = {
            "seed": int(sd),
            "abm_total_loss_musd": float(abm_res["abm_sector_loss"].sum()),
            "mriim_total_loss_musd": float(abm_res["mriim_matrix"].values.sum()),
        }

        for _, r in rl_res.iterrows():
            sev = str(r["severity_bin"]).lower()
            row[f"rl_pct_reduction_{sev}"] = float(r["pct_reduction"])

        rows.append(row)

    df = pd.DataFrame(rows)

    summary = pd.DataFrame({
        "metric": [c for c in df.columns if c != "seed"],
        "mean": [df[c].mean() for c in df.columns if c != "seed"],
        "std": [df[c].std(ddof=0) for c in df.columns if c != "seed"],
        "cv_pct": [
            100.0 * df[c].std(ddof=0) / max(abs(df[c].mean()), 1e-12)
            for c in df.columns if c != "seed"
        ],
    })

    summary.to_excel(OUTDIR / "Seed_Stability_Summary.xlsx", index=False)
    return df


# ========================= 5) MAIN ===========================================
def run():
    OUTDIR.mkdir(parents=True, exist_ok=True)

    Use, Make = read_use_make(PATHS)
    A, x_nat  = build_A(Use, Make)
    L_nat     = leontief(A)

    base_48x15     = read_state_sector_48x15(PATHS["gdp_state"], sheet="Aggregated", year_tag="2023")
    ca_output_musd = base_48x15.loc[CA_CODE].rename("CA_Output_2023")
    # --- ABM input: state × sector activity shares (columns sum to 1)
    STATE_SECTOR_SHARES = (
        base_48x15
        .div(base_48x15.sum(axis=0), axis=1)
        .fillna(0.0)
    )

    # sanity check (fail fast)
    if not np.allclose(STATE_SECTOR_SHARES.sum(axis=0).values, 1.0, atol=1e-8):
        raise ValueError("STATE_SECTOR_SHARES columns do not sum to 1")

    # Approximate gross output by state–sector using national GO/VA ratios
    go_nat = Make.sum(axis=0)
    va_nat = (go_nat - Use.sum(axis=0)).replace(0, np.nan)
    go_va_ratio = (go_nat / va_nat).replace([np.inf, -np.inf], np.nan).fillna(1.0)
    X_go = base_48x15.mul(go_va_ratio.reindex(base_48x15.columns), axis=1)

    # Build Ri with pseudo-GO
    Ri = compute_Ri_from_state_outputs_ipf(
        A, X_go, STATES48, SECTORS15, home_bias=HB, same_div_mult=2.0, same_reg_mult=1.3
    )
    A_full = make_A_full_rowweighted(A, Ri, STATES48, SECTORS15)
    af_sym_diag = run_Afull_column_symmetry_diagnostics(A, Ri, A_full, STATES48, SECTORS15, top_n=30)

    rho_full = float(np.max(np.abs(np.linalg.eigvals(A_full.values))))
    print("A_full spectral radius:", rho_full)
    if rho_full >= 1.0:
        raise ValueError("A_full spectral radius >= 1. Try lowering home_bias or review inputs.")

    L_full = make_L_full_from_A(A_full)
    unit_impulse_test(L_full)
    if RUN_STABILITY_CHECKS:
        print("\n[Diagnostics] Running seed stability checks...")
        stab = run_stability_checks(L_full, n_rep=10)
        stab.to_excel(OUTDIR / "Seed_Stability_Checks.xlsx", index=False)
    Dpct   = make_percent_scenarios()
    # ========================= ABM: STANDALONE =========================
    print("\n[ABM] Running freight ABM (standalone)…")

    abm_dir = OUTDIR / "abm"
    abm_dir.mkdir(parents=True, exist_ok=True)

    abm_results, t_abm = timed_call(
        "ABM standalone",
        freight_abm.run_abm,
        include_inbound=True,
        run_polb_switching=False,
        polb_out_dir=str(OUTDIR / "polb_switching"),
        polb_seed=0,
        polb_severity_list=[0.25, 0.50, 0.75],
        polb_seeds=[0, 1, 2, 3, 4],
        polb_utility_bonus=5.0,
        polb_switch_cost_per_ton=10.0,
        logistics_penalty_weight=0.05,
        truck_cap_sw=60_000.0,
        utility_cost_scale=1e6,
        utility_temp=1.5,
    )
    # ========================= ABM CALIBRATION =========================
    if RUN_ABM_CALIBRATION:
        print("\n[ABM] Running empirical calibration against 2021 congestion targets...")

        calib_dir = OUTDIR / "abm_calibration"
        calib_dir.mkdir(parents=True, exist_ok=True)

        calib_df, t_calib = timed_call(
            "ABM calibration",
            freight_abm.run_abm_calibration,
            targets_csv=PATHS["abm_calibration_targets_2021"],
            out_dir=str(calib_dir),
            seeds=(0,),
            include_inbound=True,
            run_polb_switching=False,
        )
    # ========================= RL PAIRED COMPARISON (Table 2 / your LaTeX table) =========================
    rl_out = OUTDIR / "rl"
    rl_out.mkdir(parents=True, exist_ok=True)

    rl_df, t_rl = timed_call(
        "RL paired comparison",
        freight_abm.run_rl_paired_comparison,
        abm_baseline_results=abm_results,
        L_full=L_full,
        n_realizations=2000,
        seed=42,
        out_dir=str(rl_out),
    )

    # Save for record
    rl_out = OUTDIR / "rl"
    rl_out.mkdir(parents=True, exist_ok=True)
    rl_df.to_excel(rl_out / "RL_Paired_Results.xlsx", index=False)

    print("\n=== RL paired results (copy into paper) ===")
    print(rl_df)

    # Print LaTeX-ready rows
    label_map = {
        "low":      r"Low (0--25\% capacity loss)",
        "moderate": r"Moderate (25--50\% capacity loss)",
        "high":     r"High (50--100\% capacity loss)",
    }

    for _, row in rl_df.iterrows():
        sev = str(row["severity_bin"])
        base = float(row["baseline_mean_loss_musd"])
        rll  = float(row["rl_mean_loss_musd"])
        pct  = float(row["pct_reduction"])
        ci_lo = float(row.get("ci_low_pct", float("nan")))
        ci_hi = float(row.get("ci_high_pct", float("nan")))
        print(f"{label_map.get(sev, sev)} & {base:.2f} & {rll:.2f} & {pct:.1f}\\% & [{ci_lo:.1f},{ci_hi:.1f}] \\\\")

    # --------------------------------------------------
    # ABM diagnostics & figures (audit_viz_v2)
    # --------------------------------------------------
    from audit_viz_v2 import (
        plot_mode_shares,
        plot_congestion,
        plot_utility_distributions,
        plot_cost_accumulation,
        plot_abm_shock_bar,
        plot_mode_heatmap,
        plot_route_diversity,
    )

    abm_diag_dir = str(OUTDIR / "abm" / "diagnostics")
    os.makedirs(abm_diag_dir, exist_ok=True)

    plot_mode_shares(abm_results, abm_diag_dir)
    plot_congestion(abm_results, abm_diag_dir)
    plot_utility_distributions(abm_results, abm_diag_dir)
    plot_cost_accumulation(abm_results, abm_diag_dir)
    plot_abm_shock_bar(abm_results, abm_diag_dir)
    plot_mode_heatmap(abm_results, abm_diag_dir)
    plot_route_diversity(abm_results, abm_diag_dir)


    abm_matrix = abm_results["abm_matrix"]


    abm_state_loss  = abm_matrix.sum(axis=1)
    abm_sector_loss = abm_matrix.sum(axis=0)


    print("[ABM] matrix min/max:", float(abm_matrix.min().min()), float(abm_matrix.max().max()))
    print("[ABM] state_loss min/max:", float(abm_state_loss.min()), float(abm_state_loss.max()))
    print("[ABM] sector_loss min/max:", float(abm_sector_loss.min()), float(abm_sector_loss.max()))

    chk_state = abm_matrix.sum(axis=1)
    chk_sector = abm_matrix.sum(axis=0)

    print("[ABM] max |state_loss - sum_rows|:", float((abm_state_loss - chk_state).abs().max()))
    print("[ABM] max |sector_loss - sum_cols|:", float((abm_sector_loss - chk_sector).abs().max()))

    abm_sector_loss.to_excel(abm_dir / "ABM_Sector_Losses.xlsx")
    abm_state_loss.to_excel(abm_dir / "ABM_State_Losses.xlsx")
    abm_matrix.to_excel(abm_dir / "ABM_StateSector_Losses.xlsx")

    core_diag = run_core_diagnostics(Use, Make, A, L_nat, x_nat, base_48x15, Ri, A_full, L_full)

    # ========================= ABM → MRIIM =========================
    print("\n[ABM→MRIIM] Propagating ABM losses through MRIO…")

    # Build full 720-vector demand shock from ABM (negative)
    d_abm = (-abm_matrix).stack().reindex(L_full.index).fillna(0.0)

    resp_abm = L_full @ d_abm

    abm_mrio = resp_abm.unstack(level=1).reindex(
        index=STATES48, columns=SECTORS15
    ).fillna(0.0)

    abm_mrio.to_excel(abm_dir / "ABM_MRIO_StateSector.xlsx")

    plot_heatmap(
        abm_matrix.reindex(columns=SECTORS15),
        "ABM-only state×sector losses (million $)",
        abm_dir / "ABM_StateSector_Matrix.png",
        vcenter=False,
        scale="asinh",
        sort_states=True,
        loss_only=False,
        cbar_label="million $"
    )
    # ABM maps using the same data as ABM_StateSector_Matrix.
    # These are post-processing only; they do not rerun the ABM.
    if RUN_ABM_MAPS:
        abm_map_outputs = plot_abm_state_impact_maps(
            abm_matrix=abm_matrix.reindex(index=STATES48, columns=SECTORS15),
            out_dir=abm_dir,
            show_state_labels=True,
        )


    # ---- Deterministic workbook + figures
    with pd.ExcelWriter(OUTDIR / "MRIIM_PoLA_FromFiles.xlsx", engine="xlsxwriter") as writer:
        write_diagnostics_to_excel(writer, core_diag)

        Use.to_excel(writer, sheet_name="Use_15x15")
        Make.to_excel(writer, sheet_name="Make_15x15")
        A.to_excel(writer,   sheet_name="A_15x15")
        L_nat.to_excel(writer, sheet_name="Leontief_15x15")
        x_nat.to_excel(writer, sheet_name="National_Output_Vector")
        base_48x15.to_excel(writer, sheet_name="Base_2023_State×Sector")
        ca_output_musd.to_excel(writer, sheet_name="CA_Output_2023")
        Dpct.to_excel(writer, sheet_name="Percent_Scenarios")
        A_full.to_excel(writer, sheet_name="A_full_720x720", merge_cells=False)

        meta = pd.DataFrame(
            {"value":[HB, rho_full],
             "note":["home_bias used in Ri","spectral radius of A_full"]},
            index=["home_bias","rho(A_full)"]
        )
        meta.to_excel(writer, sheet_name="MRIO_Diagnostics")

        # Document the pseudo-GO
        X_go.to_excel(writer, sheet_name="Base_2023_GO_State×Sector")

        # Demand-weighted average interstate shares R̄
        D_np = (A.values @ X_go.values.T).T
        w    = D_np / (D_np.sum(axis=1, keepdims=True) + 1e-12)
        R_bar = (Ri * w[:, None, :]).sum(axis=2)
        pd.DataFrame(R_bar, index=STATES48, columns=STATES48).to_excel(writer, sheet_name="Rbar_48x48")
        pd.Series(np.diag(R_bar), index=STATES48, name="Intrastate_share").to_excel(writer, sheet_name="Rbar_Intrastate")

        pd.DataFrame({"State": STATES48}).to_excel(writer, sheet_name="Index_States", index=False)
        pd.DataFrame({"Sector": SECTORS15}).to_excel(writer, sheet_name="Index_Sectors", index=False)

        # ========================= ABM FIGURES =========================
        plot_sector_bars(
            abm_sector_loss,
            "ABM-only national sector losses (million $)",
            abm_dir / "ABM_Sector_Losses.png",
            top_n=4,
        )

        plot_state_bars(
            abm_state_loss,
            "ABM-only state losses (million $)",
            abm_dir / "ABM_State_Losses.png",
            top_n=5,

        )

        # ---- Deterministic scenarios (PoLA CA-origin)
        for name in Dpct.columns:
            d = build_dollar_shock(Dpct[name], ca_output_musd, POLA_DEFAULT).reindex(L_full.index)
            resp = L_full @ d  # million $

            by_state  = resp.groupby(level=0).sum()
            by_sector = resp.groupby(level=1).sum()
            mat = resp.unstack(level=1).reindex(index=STATES48, columns=SECTORS15).fillna(0.0)

            by_state.name  = name + "_ByState_million_$"
            by_sector.name = name + "_BySector_million_$"

            by_state.to_excel(writer,  sheet_name=f"{name}_ByState")
            by_sector.to_excel(writer, sheet_name=f"{name}_BySector")
            mat.to_excel(writer,       sheet_name=f"{name}_StateSector")

            # Inoperability: q = max(0, -Δx / X_go)
            q_mat = compute_inoperability_q(resp, X_go)
            q_mat.to_excel(writer, sheet_name=f"{name}_q")

            subtitle = f"PoLA share={POLA_DEFAULT:.0%} | home_bias={HB} | shock={name}"
            plot_sector_bars(by_sector, f"{name} Sector Losses (million $) PoLA",
                             OUTDIR / f"{name}_sectors.png", top_n=15, subtitle=subtitle)
            plot_state_bars(by_state,   f"{name} State Losses (million $) PoLA",
                             OUTDIR / f"{name}_states.png",  top_n=25, subtitle=subtitle, highlight_state=CA_CODE)

            # Loss-only $ heatmap
            plot_heatmap(mat, f"{name} State×Sector losses (million $) PoLA",
                         OUTDIR / f"{name}_matrix.png",
                         vcenter=False, scale="asinh",  # UPDATED: was "robust"
                         sort_states=True, subtitle=subtitle,
                         quant=0.985, loss_only=True, cbar_label="million $ loss")

            # Inoperability heatmap
            plot_heatmap(q_mat, f"{name} Inoperability q (fraction)",
                         OUTDIR / f"{name}_q_matrix.png",
                         vcenter=False, scale="asinh",  # UPDATED: was "robust"
                         sort_states=True, subtitle=subtitle,
                         quant=0.985, loss_only=True, cbar_label="fraction (q)")

    # ========================= CAPACITY SENSITIVITY =========================
    # ========================= CAPACITY SENSITIVITY =========================
    if RUN_CAPACITY_SENSITIVITY:
        print("\n[ABM] Running capacity-threshold sensitivity analysis...")
        cap_dir = OUTDIR / "capacity_sensitivity"
        cap_dir.mkdir(parents=True, exist_ok=True)

        freight_abm.run_capacity_sensitivity(
            out_dir=str(cap_dir),
            include_inbound=True,
            port_caps=(40000.0, 50000.0, 60000.0, 70000.0, 80000.0),
            rail_caps=(60000.0, 75000.0, 90000.0, 105000.0, 120000.0),
            seeds=(0, 1, 2, 3, 4),
            run_polb_switching=False,
        )
    # ---- Stochastic (run ONCE, after deterministic workbook is closed)
    stoch_dir = OUTDIR / "stochastic"
    stoch_dir.mkdir(parents=True, exist_ok=True)

    _, t_stoch = timed_call(
        "Stochastic engine",
        run_stochastic,
        A_15x15=A,
        L_full=L_full,
        X_go=X_go,
        base_48x15=base_48x15,
        ca_output_musd=ca_output_musd,
        outdir=OUTDIR,
        subdir=stoch_dir
    )

    _, t_mode = timed_call(
        "Mode shift",
        run_mode_shift,
        L_full=L_full
    )

    # Legend + console notes
    save_sector_legend(OUTDIR / "sector_legend.png")
    print("Saved:", str(OUTDIR / "MRIIM_PoLA_FromFiles.xlsx"))
    print("PNGs in:", str(OUTDIR)) 
    runtime_summary = pd.DataFrame([
        {"component": "ABM standalone", "time_sec": float(t_abm)},
        {"component": "ABM calibration", "time_sec": float(t_calib) if "t_calib" in locals() else np.nan},
        {"component": "RL paired comparison", "time_sec": float(t_rl)},
        {"component": "Stochastic engine", "time_sec": float(t_stoch)},
        {"component": "Mode shift", "time_sec": float(t_mode)},
    ])
    runtime_summary.to_excel(OUTDIR / "Runtime_Summary.xlsx", index=False)
    manifest = {
        "timestamp": pd.Timestamp.now().isoformat(),
        "seeds": {
            "main_seed": 42,
            "rl_seed": 42,
            "polb_seed": 0,
            "calibration_seeds": [0, 1, 2],
        },
        "timings_sec": {
            "abm": float(t_abm) if "t_abm" in locals() else None,
            "abm_calibration": float(t_calib) if "t_calib" in locals() else None,
            "rl": float(t_rl) if "t_rl" in locals() else None,
            "stochastic": float(t_stoch) if "t_stoch" in locals() else None,
            "mode_shift": float(t_mode) if "t_mode" in locals() else None,
        },
        "core_assumptions": {
            "POLA_default_share": POLA_DEFAULT,
            "home_bias": HB,
            "from_mode": FROM_MODE,
            "to_mode": TO_MODE,
            "shift_pct": SHIFT_PCT,
        },
        "calibration_file": str(PATHS.get("abm_calibration_targets_2021", "")),
    }
    with open(OUTDIR / "reproducibility_manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)

if __name__ == "__main__":
    run()


   