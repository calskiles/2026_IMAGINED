# Intermodal Freight Optimization and Routing Model (INFORM)

**Lower Mississippi River case study**

This repository packages a best-effort Python/DOcplex translation of the original IBM CPLEX OPL model, together with the Lower Mississippi River Excel input workbook. The original OPL equations are embedded in the Python source for traceability. The Upper River case is **not** included.

## Repository contents

- `INFORM.py` — single Python source file with the model translation, source OPL expressions, documented assumptions, and command-line instructions.
- `22 OD Pair Model new.xlsx` — Lower Mississippi River case-study workbook used as the default input.
- `README.md` — project overview and setup instructions (this file).

## Requirements

Python 3.10+ and the packages `openpyxl`, `docplex`, and `cplex`. A compatible IBM CPLEX installation and license may be required.

```bash
python -m pip install openpyxl docplex cplex
```

## Usage

Keep the three files in the same folder and run the commands from that folder.

Inspect the embedded OPL expression parser without attempting optimization:

```bash
python INFORM.py --check-source
```

Attempt to build the model (does not solve):

```bash
python INFORM.py --weight-costs 1 --weight-emissions 2 --weight-time 1
```

Attempt to build and solve:

```bash
python INFORM.py --solve --time-limit 3600 --weight-costs 1 --weight-emissions 2 --weight-time 1
```

The objective weights above are **illustrative**, not verified Lower Mississippi case-study weights. Replace them with values appropriate to the analysis. A different workbook may be supplied with `--workbook "path/to/your.xlsx"`.

## Original study assumptions

The source script documents the case-study dimensions (22 OD pairs, 13 routing alternatives per pair, 158 truck facilities, 99 rail facilities, 45 ports, 100 candidate facilities, and 4 fuel technologies), the original freight-flow upper bound (105,000), a 43-hour congestion parameter, and a declared long-distance penalty (0.0851). Other numerical assumptions are read from the workbook. These values are provided for reproducibility and should be reviewed and replaced for other applications.

## Scope and limitations

This is a **best-effort translation, not a validated reproduction**. No solve test or numerical equivalence check has been performed. The original model may contain indexing inconsistencies, repeated constraints, nonlinear terms, and candidate-facility activation issues; they have not been silently corrected. Some workbook range mappings and objective weights require review. The script does **not** automatically export results back to Excel. Running the commands may fail until these issues are addressed.

The source OPL model and the workbook are provided as supplied/adapted for the Lower Mississippi River case. Review model assumptions, data rights, and solver licensing before public redistribution.
