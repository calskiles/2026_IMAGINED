"""INTERMODAL FREIGHT OPTIMIZATION AND ROUTING MODEL (INFORM)
LOWER MISSISSIPPI RIVER CASE — PYTHON TRANSLATION

PURPOSE
-------
This file combines the original OPL model text, the Excel data mappings,
and the Python/DOcplex translation machinery in ONE Python source file.
It is a best-effort transcription of the original equations, NOT a verified
or mathematically corrected optimization model. No optimization test was
requested or performed. The embedded OPL source is included for traceability;
the code attempts to build its Python equivalent at runtime.

HOW TO RUN
----------
1. Install Python 3.10 or newer and the required Python packages:
       python -m pip install openpyxl docplex cplex
   IBM CPLEX must be installed/licensed as applicable to your environment.
2. Put this .py file and your Excel workbook in the SAME directory.
   The default workbook is: 22 OD Pair Model new.xlsx
   Alternatively supply a different workbook using --workbook.
3. Open a terminal in that directory.
4. Check that the embedded original OPL expressions can be parsed:
       python INFORM.py --check-source
   This is a syntax/translation check, NOT an optimization run.
5. To attempt to construct the model WITHOUT solving it:
       python INFORM.py --weight-costs 1 --weight-emissions 2 --weight-time 1
6. To attempt to construct and solve it:
       python INFORM.py --solve --time-limit 3600 --weight-costs 1 --weight-emissions 2 --weight-time 1
   The weights above are illustrative; choose the appropriate Lower
   Mississippi study weights. Do not assume Upper River weights apply.
7. For a differently named workbook, add:
       --workbook "your_workbook.xlsx"

ORIGINAL STUDY ASSUMPTIONS — REPLACE FOR YOUR OWN STUDY
------------------------------------------------------
22 origin-destination pairs; 13 routing variables per pair; 158 existing
truck facilities; 99 existing rail facilities; 45 ports; 100 candidate
facilities; 4 fuel technologies. The original model specified a freight-flow
upper bound of 105,000, a congestion assumption of 43 hours per truck, and a
long-distance penalty of 0.0851 (declared but not used in the objective).
Other inputs, such as facility capacities, distances, costs, speeds, emissions,
and disruptions, are read from the workbook rather than fixed in Python.
Users must replace the workbook values and review range mappings when
adapting the model to another region.

IMPORTANT LIMITATIONS
---------------------
- The source OPL equations have been preserved, including possible indexing
  errors, duplicated constraints, and binary-by-continuous products.
- The source is a toy-model formulation with hardcoded dimensions originally
  set to 25/25/25/50; Python dimensions have been adapted to the supplied
  Lower Mississippi workbook, which is a case adaptation, not literal OPL
  equivalence.
- Some Lower Mississippi Excel ranges and objective weights may need review.
- The model may fail to build or solve; this file does not guarantee a valid
  MILP, a feasible model, or results matching OPL.
- This script does not automatically write results back into the workbook.
"""
from pathlib import Path
from openpyxl import load_workbook

WORKBOOK = Path(__file__).resolve().parent / "22 OD Pair Model new.xlsx"
N_OD, N_ROUTE, N_TSA, N_FRS, N_PORT, N_CANDIDATE, N_FUEL = 22, 13, 158, 99, 45, 100, 4
FLOW_UPPER_BOUND = 105000  # Original OPL bound 105000; user should select a valid bound for this case.
LONG_DISTANCE_PENALTY = 0.0851  # Original OPL assumption; unused in source objective.
CONGESTION_HOURS_PER_TRUCK = 43  # Original OPL assumption; review interpretation.

# Each mapping below preserves the exact Excel cell range in the OPL .dat file.
# Values are loaded at runtime, not hardcoded, so another researcher can
# substitute their own workbook and retain the case-study assumptions as comments.
INPUT_RANGES = {
    'ODPairsTonnage': ('OD Pairs', 'D2:D23'),
    'ODPairsNofTrucks': ('OD Pairs', 'S2:S23'),
    'ODPairsNofRailCars': ('OD Pairs', 'T2:T23'),
    'ODPairsNofBarges': ('OD Pairs', 'U2:U23'),
    'numcontainers': ('OD Pairs', 'W2:W23'),
    'numTrucks': ('Cluster of Nodes', 'G146:G303'),
    'numRailCars': ('Cluster of Nodes', 'H2:H100'),
    'numBarges': ('Cluster of Nodes', 'I101:I145'),
    'p0': ('Cluster of Nodes', 'J101:J145'),
    'r0': ('Cluster of Nodes', 'K2:K100'),
    'MinAnnualCapacity': ('Detailed Cost Calculations', 'E2'),
    'AnnualCost': ('Detailed Cost Calculations', 'F2'),
    'numRailCarsCandidate': ('Candidate Capacities', 'B2:B101'),
    'numBargesCandidate': ('Candidate Capacities', 'C2:C101'),
    'FixedTruckProportion': ('Fuel technology', 'B3:FC6'),
    'FixedRailCarProportion': ('Fuel technology', 'B10:CV13'),
    'FixedBargeProportion': ('Fuel technology', 'B17:AT20'),
    'disruptionTSA': ('Disruptions', 'B2:B159'),
    'disruptionFRS': ('Disruptions', 'C2:C100'),
    'disruptionPorts': ('Disruptions', 'D2:D46'),
    'FixedCandidateRailCarProportion': ('Candidate Facilities', 'E2:H101'),
    'FixedCandidateBargeProportion': ('Candidate Facilities', 'I2:L101'),
    'ODPairsDirectDeliveryDistance': ('OD Pairs', 'V2:V23'),
    'ODPairsPickupDistance': ('Pickup distance miles', 'C2:FD23'),
    'OrigintoFRSdistances': ('Origin to FRS Port distance', 'B2:CV23'),
    'OrigintoPortsdistances': ('Origin to FRS Port distance', 'CW2:EO23'),
    'freightstationsdistances': ('Freight Distances mile', 'B2:CV100'),
    'portsdistances': ('Waterway Distances mile', 'B2:AT46'),
    'FRStoDestinationdistances': ('FRS Port to Destination mil', 'B2:CV23'),
    'PortstoDestinationdistances': ('FRS Port to Destination mil', 'CW2:EO23'),
    'CandidatePickupDistances': ('Candidate-Origin distances', 'B2:CW23'),
    'CandidateDistances': ('Candidate Nodes Distances Miles', 'B2:CW101'),
    'CandidateToDestinationDistances': ('Candidate-Destinations dist', 'B2:CW23'),
    'upstreamindexpp': ('Upstream Matrix', 'CX102:DP146'),
    'upstreamindexcc': ('Upstream Matrix', 'B2:CW101'),
    'upstreamindexpc': ('Upstream Matrix', 'B102:CW146'),
    'upstreamindexcp': ('Upstream Matrix', 'CX2:DP101'),
    'CandidatePortsDistances': ('Candidate to Facilities', 'CW2:EO101'),
    'CandidateRailDistances': ('Candidate to Facilities', 'B2:CV101'),
    'AverageTruckSpeed': ('Multipliers', 'G2'),
    'AverageSpeedRail': ('Multipliers', 'G3'),
    'AverageSpeedBarge': ('Multipliers', 'G4'),
    'TruckToRailTime': ('Multipliers', 'O2'),
    'TruckToBargeTime': ('Multipliers', 'Q2'),
    'RailToBargeTime': ('Multipliers', 'Q3'),
    'TruckLoadingTime': ('Multipliers', 'T2'),
    'TruckGWP': ('Multipliers', 'B2:E2'),
    'RailCarGWP': ('Multipliers', 'B3:E3'),
    'BargeGWP': ('Multipliers', 'B4:E4'),
    'DeliveryUnloadingGWP': ('Multipliers', 'S2'),
    'TruckRailUnloadingGWP': ('Multipliers', 'M2'),
    'TruckBargeUnloadingGWP': ('Multipliers', 'P2'),
    'RailBargeUnloadingGWP': ('Multipliers', 'P3'),
    'CarbonTax': ('Multipliers', 'B65'),
    'TimeToMoneyFactor': ('Multipliers', 'B66'),
    'TruckOperatingCost': ('Detailed Cost Calculations', 'B54:E54'),
    'RailOperatingCost': ('Detailed Cost Calculations', 'B55:E55'),
    'BargeOperatingCost': ('Detailed Cost Calculations', 'B56:E56'),
    'TruckRailUnloadingCost': ('Multipliers', 'L2'),
    'TruckBargeUnloadingCost': ('Multipliers', 'O2'),
    'RailBargeUnloadingCost': ('Multipliers', 'O3'),
    'PickupLoadingCost': ('Multipliers', 'R2'),
    'DeliveryUnloadingCost': ('Multipliers', 'R2'),
}

def load_inputs(workbook=WORKBOOK, weights=None):
    """Read every original .dat input; reject blank or nonnumeric entries."""
    wb = load_workbook(workbook, read_only=True, data_only=True)
    data = {}
    try:
        for name, (sheet, area) in INPUT_RANGES.items():
            selection = wb[sheet][area]
            rows = [[selection.value]] if hasattr(selection, "value") else [[cell.value for cell in row] for row in selection]
            if not rows or any(not isinstance(x, (int, float)) for row in rows for x in row):
                raise ValueError(f"Missing/non-numeric input: {name} at {sheet}!{area}")
            data[name] = rows[0][0] if len(rows) == 1 and len(rows[0]) == 1 else (
                [row[0] for row in rows] if len(rows[0]) == 1 else (
                    rows[0] if len(rows) == 1 else rows))
        # The new workbook does not populate the former OPL objective-weight cells.
        # These values MUST be provided by the user; never borrow another case's weights.
        if weights:
            data.update(weights)
        for key in ('weightcosts', 'weightemissions', 'weighttime'):
            if key not in data:
                raise ValueError(f"Missing objective weight {key}: supply an explicit Lower Mississippi River case value")
        return data
    finally:
        wb.close()


ORIGINAL_OPL = 'execute {\n    cplex.workmem = 30000; // Allocate 50 GB of memory\n    cplex.threads = 20; // Use 18 threads\n    cplex.nodefileind = 3; // Store branch-and-bound nodes on disk\n    cplex.preind = 1; // Enable preprocessing (correct syntax for OPL)\n    cplex.parallelmode= -1;}\n\n//OD Pairs Information\nint NODpairs = ...;\nint NVarsPerOD = ...;\nrange RODP = 1..NODpairs; \nrange RVars = 1..NVarsPerOD;\nfloat ODPairsTonnage[RODP]=...;\nint ODPairsNofTrucks[RODP]=...;\nint ODPairsNofRailCars[RODP]=...;\nint ODPairsNofBarges[RODP]=...;\nfloat numcontainers[RODP]=...;\nfloat weightemissions=...;\nfloat weighttime=...;\nfloat weightcosts=...;\n\n//Linearization Upper & Lower Limits\nfloat U_w=...;  \nfloat L_w=...;  \nfloat U_y=...;  \nfloat L_y=...; \n\n//Facilities \nint NTSA= 25; // change later \nint NFRS= 25; // change later \nint NPorts= 25; // change later \nrange RTSA = 1..NTSA;\nrange RFRS = 1..NFRS;\nrange RPorts = 1..NPorts;\nint numTrucks[RTSA]=...;\nint numRailCars[RFRS]=...;\nint numBarges[RPorts]=...;\nint p0[RPorts]=...; //these should be boolean but cplex allows only decision variables to be so\nint r0[RFRS]=...; //these should be boolean but cplex allows only decision variables to be so\nint fueltechnologies = 4; // Number of fuel technologies\nrange Rfueltechnologies = 1..fueltechnologies; // Range for fuel technologies\nrange FlatCompoundIndex = 1..(NODpairs * NVarsPerOD);\nfloat FixedTruckProportion[Rfueltechnologies][RTSA]=...; //changed\nfloat FixedRailCarProportion[Rfueltechnologies][RFRS]=...; //changed\nfloat FixedBargeProportion[Rfueltechnologies][RPorts]=...; //changed\nint numcandidatefacilities = 50;  // Number of candidate facilities for the toy model\nrange rnumcandidatefacilities = 1..numcandidatefacilities; // Range of candidate facilities\nfloat MinAnnualCapacity= ...; // Import from cell E2 in "Detailed Cost Calculations"\nfloat AnnualCost= ...; // Import from cell F2 in "Detailed Cost Calculations"\nint numRailCarsCandidate[rnumcandidatefacilities]=...;\nint numBargesCandidate[rnumcandidatefacilities]=...;\nrange FlatCompoundIndexTruck = 1..(NTSA * fueltechnologies);\nrange FlatCompoundIndexRail = 1..(NFRS * fueltechnologies);\nrange FlatCompoundIndexBarge = 1..(NPorts * fueltechnologies);\nrange FlatCompoundIndexCandidateRail= 1..(numcandidatefacilities * fueltechnologies);\nrange FlatCompoundIndexCandidateBarge= 1..(numcandidatefacilities * fueltechnologies);\nfloat disruptionTSA[RTSA]=...;\nfloat disruptionFRS[RFRS]=...;\nfloat disruptionPorts[RPorts]=...;\nfloat FixedCandidateBargeProportion[Rfueltechnologies][rnumcandidatefacilities]=...; //changed\nfloat FixedCandidateRailCarProportion[Rfueltechnologies][rnumcandidatefacilities]=...; //changed\n\n//Distances\nfloat ODPairsDirectDeliveryDistance[RODP]=...;\nfloat ODPairsPickupDistance[RODP][RTSA]=...;\nfloat OrigintoFRSdistances[RODP][RFRS]=...;\nfloat OrigintoPortsdistances[RODP][RPorts]=...;\nfloat freightstationsdistances[RFRS][RFRS]=...;\nfloat portsdistances[RPorts][RPorts]=...;\nfloat FRStoDestinationdistances[RODP][RFRS]=...;\nfloat PortstoDestinationdistances[RODP][RPorts]=...;\nint AverageTruckSpeed = ...; \nfloat AverageSpeedRail = ...;  \nfloat CandidatePickupDistances[RODP][rnumcandidatefacilities] = ... ;\nfloat CandidateDistances[rnumcandidatefacilities][rnumcandidatefacilities]=...;\nfloat CandidatePortsDistances[rnumcandidatefacilities][RPorts]=...;\nfloat CandidateRailDistances[rnumcandidatefacilities][RFRS]=...;\nfloat CandidateToDestinationDistances[rnumcandidatefacilities][RODP]=...;\nint upstreamindexpp[RPorts][RPorts]=...;\nint upstreamindexcc[rnumcandidatefacilities][rnumcandidatefacilities]=...;\nint upstreamindexpc[RPorts][rnumcandidatefacilities]=...;\nint upstreamindexcp[rnumcandidatefacilities][RPorts]=...;\n\n//Times\nfloat AverageSpeedBarge = ...; \nfloat TimeToMoneyFactor=...;  \nfloat TruckToRailTime = ...; \nfloat TruckToBargeTime = ...; \nfloat RailToBargeTime = ...; \nfloat TruckLoadingTime = ...; \n\n//GWP\nfloat TruckGWP[Rfueltechnologies] = ...;  \nfloat RailCarGWP[Rfueltechnologies] = ...;  \nfloat BargeGWP[Rfueltechnologies] = ...;  \nfloat DeliveryUnloadingGWP=...;\nfloat TruckRailUnloadingGWP=...;\nfloat TruckBargeUnloadingGWP=...;\nfloat RailBargeUnloadingGWP=...;\nfloat CarbonTax=...;\n\n//Operating Costs\n// Operating Costs for each fuel technology\nfloat TruckOperatingCost[Rfueltechnologies] = ...;  \nfloat RailOperatingCost[Rfueltechnologies] = ...;  \nfloat BargeOperatingCost[Rfueltechnologies] = ...; \nfloat LongDistancePenalty= 0.0851;\n\n//Loading/Unloading Costs\nfloat TruckRailUnloadingCost=...;\nfloat TruckBargeUnloadingCost=...;\nfloat RailBargeUnloadingCost=...;\nfloat PickupLoadingCost=...;\nfloat DeliveryUnloadingCost=...;\n\n//Dummy Variables\nint index1 = 1;\nint index2 = 2;\nint index3 = 3;\nint index4 = 4;\nint index5 = 5;\nint index6 = 6;\nint index7 = 7;\nint index8 = 8;\nint index9 = 9;\nint index10 = 10;\nint index11 = 11;\nint index12 = 12;\nint index13 = 13;\n\n//Decision Variables\ndvar boolean y[RODP][RVars];\ndvar float+ w[RODP][RVars];\ndvar float+ z[RODP][RVars];  \ndvar boolean TSAassignment[FlatCompoundIndexTruck][FlatCompoundIndex];\ndvar boolean FRSassignment[FlatCompoundIndexRail][FlatCompoundIndex];\ndvar boolean Portassignment[FlatCompoundIndexBarge][FlatCompoundIndex];\ndvar boolean CF[rnumcandidatefacilities];\ndvar boolean CandidateTSAassignment[FlatCompoundIndexTruck][FlatCompoundIndex];\ndvar boolean CandidateRailAssignment[FlatCompoundIndexCandidateRail][FlatCompoundIndex];\ndvar boolean CandidateBargeAssignment[FlatCompoundIndexCandidateBarge][FlatCompoundIndex];\ndvar boolean ycandidate[RODP][RVars];\ndvar float+ wcandidate[RODP][RVars];\n\n// Define the objective function components using dexpr to simplify the overall expression\n// Truck Emissions\ndexpr float truck_emissions =\n    sum(i in RODP, f in Rfueltechnologies, k in RTSA)(\n        (TruckGWP[(k - 1) mod fueltechnologies + 1] * ODPairsDirectDeliveryDistance[i] \n         * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 1] * w[i][index1]) / 1000000\n\n        + (TruckGWP[(k - 1) mod fueltechnologies + 1] * ODPairsPickupDistance[i][k]\n            * (   TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 1] * w[i][index1]\n                + TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 2] * w[i][index2]\n                + TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 3] * w[i][index3])) / 1000000)\n\n    + sum(i in RODP, f in Rfueltechnologies, k in RTSA, l in RFRS)(\n        (TruckGWP[(l - 1) mod fueltechnologies + 1] * OrigintoFRSdistances[i][l]\n         * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 2] * w[i][index2]) / 1000000\n\n        + (TruckGWP[(l - 1) mod fueltechnologies + 1] * FRStoDestinationdistances[i][l]\n            * (   TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 8] * w[i][index8]\n                + TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 12] * w[i][index12])) / 1000000)\n\n    + sum(i in RODP, f in Rfueltechnologies, k in RTSA, m in RPorts)(\n        (TruckGWP[(m - 1) mod fueltechnologies + 1] * OrigintoPortsdistances[i][m]\n            * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 3] * w[i][index3]) / 1000000\n\n       + (TruckGWP[(m - 1) mod fueltechnologies + 1] * PortstoDestinationdistances[i][m]\n            * (   TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 9] * w[i][index9]\n                + TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 13] * w[i][index13])) / 1000000)\n\n    + sum(i in RODP, c in rnumcandidatefacilities, k in RTSA, f in Rfueltechnologies)(\n        (TruckGWP[(c - 1) mod fueltechnologies + 1] * CandidatePickupDistances[i][c]\n            * (wcandidate[i][index2] * CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 2]\n            + wcandidate[i][index3] * CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 3])) / 1000000)\n\n    + sum(i in RODP,  k in RTSA, f in Rfueltechnologies, c1 in rnumcandidatefacilities, c2 in rnumcandidatefacilities : c1 != c2)(\n        (TruckGWP[(c1 - 1) mod fueltechnologies + 1] * CandidateDistances[c1][c2] * (\n              wcandidate[i][index4] *  CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 4]\n            + wcandidate[i][index7] * CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7])) / 1000000)\n\n    + sum(i in RODP, c in rnumcandidatefacilities, k in RTSA, f in Rfueltechnologies)(\n        (TruckGWP[(c - 1) mod fueltechnologies + 1] * CandidateToDestinationDistances[c][i] * (\n                wcandidate[i][index8] * CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 8]\n                + wcandidate[i][index9] * CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 9]\n                + wcandidate[i][index12] * CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 12]\n                + wcandidate[i][index13] * CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 13])) / 1000000);\n\ndexpr float rail_emissions = \n    // Existing FRS assignments (FRS → FRS)\n    sum(i in RODP, l1 in RFRS, l2 in RFRS, f in Rfueltechnologies: l1 != l2)(\n        RailCarGWP[f] * freightstationsdistances[l1][l2]  \n        * (   FRSassignment[(l1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 4] * w[i][index4]\n            + FRSassignment[(l1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 5] * w[i][index5]\n            + FRSassignment[(l1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 10] * w[i][index10])) / 1000000\n\n    // Existing Rail Facility → Candidate Facility (RC)\n    + sum(i in RODP, l in RFRS, c in rnumcandidatefacilities, f in Rfueltechnologies)(\n        RailCarGWP[f] * CandidateRailDistances[c][l]  \n        * (   FRSassignment[(l - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 4] * wcandidate[i][index4] \n            + FRSassignment[(l - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 5] * wcandidate[i][index5] \n            + FRSassignment[(l - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 10] * wcandidate[i][index10])) / 1000000\n\n    // Candidate Facility → Existing Rail Facility (CR)\n    + sum(i in RODP, c in rnumcandidatefacilities, l in FlatCompoundIndexRail, f in Rfueltechnologies)(\n        RailCarGWP[f] * CandidateRailDistances[c][(l - 1) div fueltechnologies + 1]\n        * (    CandidateRailAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 4] * wcandidate[i][index4] \n            +  CandidateRailAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 5] * wcandidate[i][index5] \n            +  CandidateRailAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 10] * wcandidate[i][index10])) / 1000000\n\n    // Candidate Facility → Candidate Facility (CC)\n    + sum(i in RODP, c1 in rnumcandidatefacilities, c2 in rnumcandidatefacilities, f in Rfueltechnologies: c1 != c2)(\n        RailCarGWP[f] * CandidateDistances[c1][c2]\n        * (    CandidateRailAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 4] * wcandidate[i][index4] \n            +  CandidateRailAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 5] * wcandidate[i][index5] \n            +  CandidateRailAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 10] * wcandidate[i][index10])) / 1000000;\n   \ndexpr float barge_emissions =\n    // Port-to-Port (PP)\n    sum(i in RODP, m1 in RPorts, m2 in RPorts, f in Rfueltechnologies: m1!= m2)(\n        BargeGWP[f] * portsdistances[m1][m2] * upstreamindexpp[m1][m2]\n        * (   w[i][index6] * Portassignment[(m1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] \n            + w[i][index7] * Portassignment[(m1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] \n            + w[i][index11] * Portassignment[(m1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11])) / 1000000\n\n    // Port-to-Candidate (PC)\n    + sum(i in RODP, m in RPorts, c in rnumcandidatefacilities, f in Rfueltechnologies)(\n        BargeGWP[f] * CandidatePortsDistances[c][m] * upstreamindexpc[m][c]\n        * (   CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] * wcandidate[i][index6] \n            + CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] * wcandidate[i][index7] \n            + CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11] * wcandidate[i][index11])) / 1000000\n\n    // Candidate-to-Port (CP)\n    + sum(i in RODP, c in rnumcandidatefacilities, m in RPorts, f in Rfueltechnologies)(\n        BargeGWP[f] * CandidatePortsDistances[c][m] * upstreamindexcp[c][m]\n        * (   CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] * wcandidate[i][index6] \n            + CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] * wcandidate[i][index7] \n            + CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11] * wcandidate[i][index11])) / 1000000\n\n    // Candidate-to-Candidate (CC)\n    + sum(i in RODP, c1 in rnumcandidatefacilities, c2 in rnumcandidatefacilities, f in Rfueltechnologies: c1!=c2)(\n        BargeGWP[f] * CandidateDistances[c1][c2] * upstreamindexcc[c1][c2]\n        * (   CandidateBargeAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] * wcandidate[i][index6] \n            + CandidateBargeAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] * wcandidate[i][index7] \n            + CandidateBargeAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11] * wcandidate[i][index11])) / 1000000;\n\ndexpr float loading_emissions = \n    (sum(i in RODP)(\n          TruckRailUnloadingGWP * ODPairsNofRailCars[i] * (y[i][index2] + y[i][index8] +  y[i][index12]) /1000 // Truck to Rail and Rail to Truck\n        + TruckBargeUnloadingGWP * ODPairsNofBarges[i] *(y[i][index3] + y[i][index9] +  y[i][index13])  /1000 // Truck to Barge and Barge to Truck\n        + RailBargeUnloadingGWP * ODPairsNofBarges[i] *(y[i][index4] + y[i][index7]) /1000 // Rail to Barge and Barge to Rail\n        + TruckRailUnloadingGWP * ODPairsNofRailCars[i]*(ycandidate[i][index2] + ycandidate[i][index8] + ycandidate[i][index12]) /1000 // Candidate Truck to Rail and Rail to Truck\n        + TruckBargeUnloadingGWP * ODPairsNofBarges[i] *(ycandidate[i][index3] + ycandidate[i][index9] + ycandidate[i][index13]) /1000 // Candidate Truck to Barge and Barge to Truck\n        + RailBargeUnloadingGWP * ODPairsNofBarges[i] *(ycandidate[i][index4] + ycandidate[i][index7]) /1000 // Candidate Rail to Barge and Barge to Rail\n        + 2 * DeliveryUnloadingGWP  * ODPairsNofTrucks[i])/1000) ;\n\n// Truck Operating Costs\ndexpr float truck_Operating_costs = \n     sum(i in RODP, f in Rfueltechnologies, k in RTSA, c in rnumcandidatefacilities)(\n        TruckOperatingCost[(k - 1) mod fueltechnologies + 1] * \n        (ODPairsPickupDistance[i][k] *  \n        (  TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 1] * w[i][index1] \n         + TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 2] * w[i][index2] \n         + TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 3] * w[i][index3]) \n         + CandidatePickupDistances[i][c] * \n        (  CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 2] * wcandidate[i][index2] \n         + CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 3] * wcandidate[i][index3])))\n    + sum(i in RODP, f in Rfueltechnologies, k in RTSA)(\n        ODPairsDirectDeliveryDistance[i] * w[i][index1]  \n        * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 1] * TruckOperatingCost[(i - 1) mod fueltechnologies + 1]) \n        + sum(i in RODP, f in Rfueltechnologies, l in RFRS, k in RTSA)(\n        TruckOperatingCost[(l - 1) mod fueltechnologies + 1] *  \n        (  OrigintoFRSdistances[i][l] * w[i][index2] * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 2]  \n         + FRStoDestinationdistances[i][l] * w[i][index8] * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 8]  \n         + FRStoDestinationdistances[i][l] * w[i][index12] * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 12])) \n    + sum(i in RODP, f in Rfueltechnologies, m in RPorts, k in RTSA)(\n        TruckOperatingCost[(m - 1) mod fueltechnologies + 1] * \n        (  OrigintoPortsdistances[i][m] * w[i][index3] * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 3] \n         + PortstoDestinationdistances[i][m] * w[i][index9] * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 9]\n         + PortstoDestinationdistances[i][m] * w[i][index13] * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 13])) \n    + sum(i in RODP, f in Rfueltechnologies, c in rnumcandidatefacilities)(\n        TruckOperatingCost[(c - 1) mod fueltechnologies + 1] *  CandidateToDestinationDistances[c][i] *\n        (wcandidate[i][index8] +  wcandidate[i][index9] + wcandidate[i][index12] + wcandidate[i][index13])) / 1000;\n\n// Rail Operating Costs\ndexpr float rail_Operating_costs = \n    // Existing Rail Facility → Existing Rail Facility (RR)\n    sum(i in RODP, l1 in RFRS, l2 in RFRS:l1 != l2)(\n        RailOperatingCost[(l1 - 1) mod fueltechnologies + 1] * freightstationsdistances[l1][l2]\n        * (  FRSassignment[l1][(i - 1) * NVarsPerOD + 4] * z[i][index4] \n           + FRSassignment[l1][(i - 1) * NVarsPerOD + 5] * z[i][index5] \n           + FRSassignment[l1][(i - 1) * NVarsPerOD + 10] * z[i][index10]))\n\n    // Existing Rail Facility → Candidate Facility (RC)\n    + sum(i in RODP, l in RFRS, c in rnumcandidatefacilities)(\n        RailOperatingCost[(l - 1) mod fueltechnologies + 1] * CandidateRailDistances[c][l]\n        * (  FRSassignment[l][(i - 1) * NVarsPerOD + 4] * z[i][index4] \n           + FRSassignment[l][(i - 1) * NVarsPerOD + 5] * z[i][index5] \n           + FRSassignment[l][(i - 1) * NVarsPerOD + 10] * z[i][index10]))\n\n    // Candidate Facility → Existing Rail Facility (CR)\n    + sum(i in RODP, c in rnumcandidatefacilities, l in RFRS)(\n        RailOperatingCost[(l - 1) mod fueltechnologies + 1] * CandidateRailDistances[c][l]\n        * (  CandidateRailAssignment[c][(i - 1) * NVarsPerOD + 4] * wcandidate[i][index4] \n           + CandidateRailAssignment[c][(i - 1) * NVarsPerOD + 5] * wcandidate[i][index5] \n           + CandidateRailAssignment[c][(i - 1) * NVarsPerOD + 10] * wcandidate[i][index10]))\n\n    // Candidate Facility → Candidate Facility (CC)\n    + sum(i in RODP, c1 in rnumcandidatefacilities, c2 in rnumcandidatefacilities: c1 != c2)(\n        RailOperatingCost[(c1 - 1) mod fueltechnologies + 1] * CandidateDistances[c1][c2]\n        * (  CandidateRailAssignment[c1][(i - 1) * NVarsPerOD + 4] * wcandidate[i][index4] \n           + CandidateRailAssignment[c1][(i - 1) * NVarsPerOD + 5] * wcandidate[i][index5] \n           + CandidateRailAssignment[c1][(i - 1) * NVarsPerOD + 10] * wcandidate[i][index10]));\n\ndexpr float barge_Operating_costs =\n    // Port-to-Port (PP)\n    sum(i in RODP, m1 in RPorts, m2 in RPorts, f in Rfueltechnologies: m1 != m2)(\n        BargeOperatingCost[f] * portsdistances[m1][m2] \n        * (   w[i][index6] * Portassignment[(m1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] \n           +  w[i][index7] * Portassignment[(m1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] \n           +  w[i][index11] * Portassignment[(m1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11])) \n\n    // Port-to-Candidate (PC)\n    + sum(i in RODP, m in RPorts, c in rnumcandidatefacilities, f in Rfueltechnologies)(\n        BargeOperatingCost[f] * CandidatePortsDistances[c][m]\n        * (   CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] * wcandidate[i][index6] \n           +  CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] * wcandidate[i][index7] \n           + CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11] * wcandidate[i][index11])) \n\n    // Candidate-to-Port (CP)\n    + sum(i in RODP, c in rnumcandidatefacilities, m in RPorts, f in Rfueltechnologies)(\n        BargeOperatingCost[f] * CandidatePortsDistances[c][m]\n        * (  CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] * wcandidate[i][index6] \n           + CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] * wcandidate[i][index7] \n           +  CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11] * wcandidate[i][index11])) \n\n    // Candidate-to-Candidate (CC)\n    + sum(i in RODP, c1 in rnumcandidatefacilities, c2 in rnumcandidatefacilities, f in Rfueltechnologies: c1 != c2)(\n        BargeOperatingCost[f] * CandidateDistances[c1][c2]\n        * (  CandidateBargeAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] * wcandidate[i][index6] \n           + CandidateBargeAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] * wcandidate[i][index7] \n           + CandidateBargeAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11] * wcandidate[i][index11]));\n\ndexpr float trucktime =\n    // Pickup  \n    sum(i in RODP, k in RTSA, c in rnumcandidatefacilities, f in Rfueltechnologies)(\n        (ODPairsPickupDistance[i][k] / AverageTruckSpeed) * \n         (   TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 1]\n           + TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 2] \n           + TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 3])\n        + (CandidatePickupDistances[i][c] / AverageTruckSpeed) * \n        (    CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 2]  \n           + CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 3] )\n        \n    )\n    // Direct Delivery\n    + sum(i in RODP, k in RTSA, f in Rfueltechnologies)(\n        (ODPairsDirectDeliveryDistance[i] / AverageTruckSpeed) * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 1])\n    // Origin to FRS  \n    + sum(i in RODP, k in RTSA, l in RFRS, f in Rfueltechnologies)(\n        (OrigintoFRSdistances[i][l] / AverageTruckSpeed) * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 2]) \n    // FRS to Destination (1-stage Transit)  \n    + sum(i in RODP, k in RTSA, l in RFRS, f in Rfueltechnologies)(\n        (FRStoDestinationdistances[i][l] / AverageTruckSpeed) * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 8]) \n    // FRS to Destination (2-stage Transit)  \n    + sum(i in RODP, k in RTSA, l in RFRS, f in Rfueltechnologies)(\n        (FRStoDestinationdistances[i][l] / AverageTruckSpeed) * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 12]) \n\t// Origin to Port  \n    + sum(i in RODP, k in RTSA, m in RPorts, f in Rfueltechnologies)(\n        (OrigintoPortsdistances[i][m] / AverageTruckSpeed) * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 3]) \n    // Port to Destination (1-stage Transit)  \n    + sum(i in RODP, k in RTSA, m in RPorts, f in Rfueltechnologies)(\n        (PortstoDestinationdistances[i][m] / AverageTruckSpeed) * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 9]) \n    // Port to Destination (2-stage Transit)  \n    + sum(i in RODP, k in RTSA, m in RPorts, f in Rfueltechnologies)(\n        (PortstoDestinationdistances[i][m] / AverageTruckSpeed) * TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 13])    \n        // Add road congestion delay (assuming an average delay of 43 hours per truck annually)\n    + sum(i in RODP,j in RVars)((43) * (y[i][index1]+y[i][index2]+y[i][index3]+y[i][index8]+y[i][index9]+y[i][index12]+y[i][index13]) * ODPairsNofTrucks[i]);\n        \ndexpr float railtime =\n    // Between FRS Facilities (RR)\n    sum(i in RODP, f in Rfueltechnologies, m in RPorts, l1 in RFRS, l2 in RFRS : l1 != l2)(\n        (freightstationsdistances[l1][l2] / AverageSpeedRail)\n        * (   FRSassignment[(l1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 4]  \n            + FRSassignment[(l1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 5]   \n            + FRSassignment[(l1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 10] ))\n\n    // Between Candidate Facilities (CC)\n    + sum(i in RODP, f in Rfueltechnologies, c1 in rnumcandidatefacilities, c2 in rnumcandidatefacilities : c1 != c2)(\n        (CandidateDistances[c1][c2] / AverageSpeedRail)\n        * (  CandidateRailAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 4]  \n           + CandidateRailAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 5]  \n           + CandidateRailAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 10]))\n\n    // Candidate-to-FRS (CR)\n    + sum(i in RODP, f in Rfueltechnologies, c in rnumcandidatefacilities, m in RPorts, l in RFRS)(\n        (CandidateRailDistances[c][l] / AverageSpeedRail)\n        * (  CandidateRailAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 4] \n           + CandidateRailAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 5]   \n           + CandidateRailAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 10]))\n\n    // FRS-to-Candidate (RC)\n    + sum(i in RODP, f in Rfueltechnologies, c in rnumcandidatefacilities, l in RFRS)(\n        (CandidateRailDistances[c][l] / AverageSpeedRail)\n        * (  FRSassignment[(l - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 4]  \n           + FRSassignment[(l - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 5]   \n           + FRSassignment[(l - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 10]));\n\ndexpr float bargetime =\n    // Between Ports for the initial barge segment (PP)\n    sum(i in RODP, f in Rfueltechnologies, m1 in RPorts, m2 in RPorts, l1 in RFRS : m1 != m2)(\n        (portsdistances[m1][m2] / AverageSpeedBarge)\n        * (  Portassignment[(m1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] \n           + Portassignment[(m1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] \n           + Portassignment[(m1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11]))\n\n    // Between Candidate Facilities (CC)\n    + sum(i in RODP, f in Rfueltechnologies, c1 in rnumcandidatefacilities, c2 in rnumcandidatefacilities : c1 != c2)(\n        (CandidateDistances[c1][c2] / AverageSpeedBarge)\n        * (  CandidateBargeAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] \n           + CandidateBargeAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] \n           + CandidateBargeAssignment[(c1 - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11]))\n\n    // Candidate-to-Port (CP)\n    + sum(i in RODP, c in rnumcandidatefacilities, m in RPorts, l in RFRS, f in Rfueltechnologies)(\n        (CandidatePortsDistances[c][m] / AverageSpeedBarge)\n        * (  CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] \n           + CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] \n           + CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11]))\n\n    // Port-to-Candidate (PC)\n    + sum(i in RODP, c in rnumcandidatefacilities, m in RPorts, l in RFRS, f in Rfueltechnologies)(\n        (CandidatePortsDistances[c][m] / AverageSpeedBarge)\n        * (  Portassignment[(m - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 6] \n           + Portassignment[(m - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 7] \n           + Portassignment[(m - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + 11]));\n\ndexpr float loadingtime = TruckLoadingTime * 2 * NODpairs +\n    sum(i in RODP)(\n        TruckToRailTime * (y[i][index2] + y[i][index5] + y[i][index8] + y[i][index10] + y[i][index12] ) \n        + TruckToBargeTime * (y[i][index3] + y[i][index6] + y[i][index9] + y[i][index11]  +   y[i][index13]) \n        + RailToBargeTime * (y[i][index4] + y[i][index7]))\n    + sum(i in RODP)(\n        TruckToRailTime * (ycandidate[i][index2] + ycandidate[i][index5] + ycandidate[i][index8] + ycandidate[i][index10] + ycandidate[i][index12]) \n        + TruckToBargeTime * (ycandidate[i][index3] + ycandidate[i][index6] + ycandidate[i][index9] + ycandidate[i][index11] + ycandidate[i][index13])\n        + RailToBargeTime * (ycandidate[i][index4] + ycandidate[i][index7]));\n    \ndexpr float loadingcost =\n    sum(i in RODP)(\n        PickupLoadingCost * 2 * ODPairsNofTrucks[i]\n        + TruckRailUnloadingCost * (y[i][index2] + y[i][index5] + y[i][index8] + y[i][index10] + y[i][index12]) * ODPairsNofRailCars[i] \n        + TruckBargeUnloadingCost * (y[i][index3] + y[i][index6] + y[i][index9] + y[i][index11] + y[i][index13]) * ODPairsNofRailCars[i] \n        + RailBargeUnloadingCost * (y[i][index4] + y[i][index7]) * ODPairsNofBarges[i] \n        + TruckRailUnloadingCost * (ycandidate[i][index2] + ycandidate[i][index5] + ycandidate[i][index8] + ycandidate[i][index10] + ycandidate[i][index12]) * ODPairsNofRailCars[i]\n        + TruckBargeUnloadingCost * (ycandidate[i][index3] + ycandidate[i][index6] + ycandidate[i][index9] + ycandidate[i][index11] + ycandidate[i][index13]) * ODPairsNofRailCars[i]\n        + RailBargeUnloadingCost * (ycandidate[i][index4] + ycandidate[i][index7]) * ODPairsNofBarges[i]\n        + PickupLoadingCost * 2);   \n\ndexpr float CandidateFacilityCosts = sum(c in rnumcandidatefacilities) CF[c] * AnnualCost;\n\ndexpr float OF = weightemissions * CarbonTax * ((truck_emissions + rail_emissions + barge_emissions + loading_emissions)) \n    + weightcosts * (truck_Operating_costs + rail_Operating_costs + barge_Operating_costs + CandidateFacilityCosts + loadingcost)\n    + weighttime * TimeToMoneyFactor * (trucktime + railtime + bargetime + loadingtime);\n    \n// Combine the decision expressions into a final minimize expression\nminimize OF;\n\nsubject to {\n forall (i in RODP) {\n    // Direct delivery constraints (y1 corresponds to a TSA assignment)\n    sum(k in RTSA) TSAassignment[k][(i - 1) * NVarsPerOD + 1] == y[i][index1];\n\n    // Rail shipping (y2 corresponds to TSA and FRS assignments)\n    sum(l in RFRS) FRSassignment[l][(i - 1) * NVarsPerOD + 2] == y[i][index2]; \n    sum(k in RTSA) TSAassignment[k][(i - 1) * NVarsPerOD + 2]  == y[i][index2];\n\n    // Barge shipping (y3 corresponds to TSA and Port assignments)\n    sum(m in RPorts) Portassignment[m][(i - 1) * NVarsPerOD + 3] == y[i][index3];\n    sum(k in RTSA) TSAassignment[k][(i - 1) * NVarsPerOD + 3]  == y[i][index3];\n\n    // FRS to Port (y4 corresponds to FRS and Port assignments)\n    sum(l in RFRS) FRSassignment[l][(i - 1) * NVarsPerOD + 4] == y[i][index4];\n    sum(m in RPorts) Portassignment[m][(i - 1) * NVarsPerOD + 4] == y[i][index4];\n\n    // TSA and FRS together (y5 corresponds to TSA and FRS assignments)\n    sum(l in RFRS) FRSassignment[l][(i - 1) * NVarsPerOD + 5] == y[i][index5];\n\n    // TSA and Port together (y6 corresponds to TSA and Port assignments)\n    sum(m in RPorts) Portassignment[m][(i - 1) * NVarsPerOD + 6] == y[i][index6];\n\n    // FRS and Port together (y7 corresponds to FRS and Port assignments)\n    sum(l in RFRS) FRSassignment[l][(i - 1) * NVarsPerOD + 7] == y[i][index7];\n    sum(m in RPorts) Portassignment[m][(i - 1) * NVarsPerOD + 7] == y[i][index7];\n\n    // TSA and FRS for destination (y8 corresponds to TSA and FRS assignments)\n    sum(k in RTSA) TSAassignment[k][(i - 1) * NVarsPerOD + 8]  == y[i][index8];\n\n    // TSA and Port for destination (y9 corresponds to TSA and Port assignments)\n    sum(k in RTSA) TSAassignment[k][(i - 1) * NVarsPerOD + 9]  == y[i][index9];\n\n    // TSA and FRS for additional segment (y10 corresponds to TSA and FRS assignments)\n    sum(l in RFRS) FRSassignment[l][(i - 1) * NVarsPerOD + 10] == y[i][index10];\n\n    // TSA and Port for additional segment (y11 corresponds to TSA and Port assignments)\n    sum(m in RPorts) Portassignment[m][(i - 1) * NVarsPerOD + 11] == y[i][index11];\n\n    // TSA and FRS for final segment (y12 corresponds to TSA and FRS assignments)\n    sum(k in RTSA) TSAassignment[k][(i - 1) * NVarsPerOD + 12] == y[i][index12];\n\n    // TSA and Port for final segment (y13 corresponds to TSA and Port assignments)\n    sum(k in RTSA) TSAassignment[k][(i - 1) * NVarsPerOD + 13] == y[i][index13];}\n\n\tforall (i in RODP) {\n    // Rail shipping (ycandidate2 corresponds to Candidate Truck and Candidate Rail Assignments)\n    sum(c in rnumcandidatefacilities) CandidateRailAssignment[c][(i - 1) * NVarsPerOD + 2] == ycandidate[i][index2];\n    sum(k in RTSA) CandidateTSAassignment[k][(i - 1) * NVarsPerOD + 2] == 2 * ycandidate[i][index2];\n\n    // Barge shipping (ycandidate3 corresponds to Candidate Truck and Candidate Barge Assignments)\n    sum(c in rnumcandidatefacilities) CandidateBargeAssignment[c][(i - 1) * NVarsPerOD + 3] == ycandidate[i][index3];\n    sum(k in RTSA) CandidateTSAassignment[k][(i - 1) * NVarsPerOD + 3] == ycandidate[i][index3];\n\n    // Candidate to port (ycandidate4 corresponds to Candidate Rail and Candidate Barge Assignments)\n    sum(c in rnumcandidatefacilities) CandidateRailAssignment[c][(i - 1) * NVarsPerOD + 4] == ycandidate[i][index4];\n    sum(c in rnumcandidatefacilities) CandidateBargeAssignment[c][(i - 1) * NVarsPerOD + 4] == ycandidate[i][index4];\n\n    // Candidate and rail together (ycandidate5 corresponds to Candidate Rail Assignment)\n    sum(c in rnumcandidatefacilities) CandidateRailAssignment[c][(i - 1) * NVarsPerOD + 5] == ycandidate[i][index5];\n\n    // Candidate and barge together (ycandidate6 corresponds to Candidate Barge Assignment)\n    sum(c in rnumcandidatefacilities) CandidateBargeAssignment[c][(i - 1) * NVarsPerOD + 6] == ycandidate[i][index6];\n\n    // Candidate and port together (ycandidate7 corresponds to Candidate Rail and Candidate Barge Assignments)\n    sum(c in rnumcandidatefacilities) CandidateRailAssignment[c][(i - 1) * NVarsPerOD + 7] == ycandidate[i][index7];\n    sum(c in rnumcandidatefacilities) CandidateBargeAssignment[c][(i - 1) * NVarsPerOD + 7] == ycandidate[i][index7];\n\n    // Candidate and rail for destination (ycandidate8 corresponds to Candidate Rail Assignment)\n    sum(k in RTSA) CandidateTSAassignment[k][(i - 1) * NVarsPerOD + 8] == ycandidate[i][index8];\n\n    // Candidate and barge for destination (ycandidate9 corresponds to Candidate Barge Assignment)\n    sum(k in RTSA) CandidateTSAassignment[k][(i - 1) * NVarsPerOD + 9] == ycandidate[i][index9];\n\n    // Candidate and rail for additional segment (ycandidate10 corresponds to Candidate Rail Assignment)\n    sum(c in rnumcandidatefacilities) CandidateRailAssignment[c][(i - 1) * NVarsPerOD + 10] == ycandidate[i][index10];\n\n    // Candidate and barge for additional segment (ycandidate11 corresponds to Candidate Barge Assignment)\n    sum(c in rnumcandidatefacilities) CandidateBargeAssignment[c][(i - 1) * NVarsPerOD + 11] == ycandidate[i][index11];\n\n    // Candidate and rail for final segment (ycandidate12 corresponds to Candidate Rail Assignment)\n    sum(k in RTSA) CandidateTSAassignment[k][(i - 1) * NVarsPerOD + 12] == ycandidate[i][index12];\n\n    // Candidate and barge for final segment (ycandidate13 corresponds to Candidate Barge Assignment)\n    sum(k in RTSA) CandidateTSAassignment[k][(i - 1) * NVarsPerOD + 13] == ycandidate[i][index13];}\n \n\tforall (i in RODP, j in RVars, k in RTSA, l in RFRS, m in RPorts) {\n    (y[i][index1] + y[i][index2] + y[i][index3] + ycandidate[i][index2] + ycandidate[i][index3]) == 1; //constraint1\n     y[i][index2] + ycandidate[i][index2] ==  r0[l] * y[i][index4] + y[i][index5]+ ycandidate[i][index4]+ ycandidate[i][index5];  //constraint2\n     y[i][index3] + ycandidate[i][index3] == y[i][index6] + p0[m] * y[i][index7]+ ycandidate[i][index6]+ ycandidate[i][index7]; //constraint3\n     y[i][index4] + ycandidate[i][index4]== y[i][index11] + ycandidate[i][index11]; //constraint4\n     y[i][index7] + ycandidate[i][index7] == y[i][index10] + ycandidate[i][index10]; //constraint5\n     y[i][index10] + ycandidate[i][index10] == y[i][index12] + ycandidate[i][index12]; //constraint6\n     y[i][index11] + ycandidate[i][index11]== y[i][index13] + ycandidate[i][index13]; //constraint7\n     y[i][index5] + ycandidate[i][index5]== y[i][index8] + ycandidate[i][index8]; //constraint8\n     y[i][index6] + ycandidate[i][index6]== y[i][index9] + ycandidate[i][index9]; //constrain9\n     y[i][index1] + y[i][index8] +y[i][index9] + y[i][index12] +  y[i][index13]+\n     ycandidate[i][index8] +ycandidate[i][index9] + ycandidate[i][index12] +  ycandidate[i][index13] == 1;   //constraint10\n     w[i][j] == y[i][j] * ODPairsTonnage[i]; //constraint15\n     wcandidate[i][j] == ycandidate[i][j] * ODPairsTonnage[i]; //constraint16 \n     }\n     \n   \t forall (i in RODP, j in RVars) {\n        z[i][j] >= 0; // Lower bound constraint 1 (z >= L_w * y + L_y * w - L_w * L_y)\n        z[i][j] >= U_w * y[i][j] + w[i][j] - U_w; // Lower bound constraint 2 (z >= U_w * y + U_y * w - U_x * U_y)\n        z[i][j] <= U_w * y[i][j]; // Upper bound constraint 1 (z <= U_w * y + L_y * w - U_w * L_y)\n        z[i][j] <= w[i][j]; // Upper bound constraint 2 (z <= U_y * w + L_w * y - L_w * U_y)}\n     }     \n\t\n\t// TSA Capacity Constraints\n\tforall (k in RTSA, f in Rfueltechnologies) {\n\t    sum(i in RODP)(ODPairsNofTrucks[i] * FixedTruckProportion[f][k] * (\n\t            sum(j in 1..NVarsPerOD) (TSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + j]\n\t                + CandidateTSAassignment[(k - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + j]))) <= numTrucks[k];}\n\t\n\t// FRS Capacity Constraints\n\tforall (l in RFRS, f in Rfueltechnologies) {\n\t    sum(i in RODP)( ODPairsNofRailCars[i] * FixedRailCarProportion[f][l] * (\n\t            sum(j in 1..NVarsPerOD) (FRSassignment[(l - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + j]))) <= numRailCars[l];}\n\t\n\t// Port Capacity Constraints\n\tforall (m in RPorts, f in Rfueltechnologies) {\n\t    sum(i in RODP)(ODPairsNofBarges[i] * FixedBargeProportion[f][m] * (\n\t            sum(j in 1..NVarsPerOD) (Portassignment[(m - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + j]))) <= numBarges[m];}\n\t\n\t// Candidate Rail Capacity\n\tforall (c in rnumcandidatefacilities, f in Rfueltechnologies) {\n    sum(i in RODP)(ODPairsNofRailCars[i] * FixedCandidateRailCarProportion[f][c] * (sum(j in 1..NVarsPerOD)(\n                CandidateRailAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + j]))) <= numRailCarsCandidate[c] * CF[c];}\n\n\t// Candidate Barge Capacity\n\tforall (c in rnumcandidatefacilities, f in Rfueltechnologies) {\n\t    sum(i in RODP)(ODPairsNofBarges[i] * FixedCandidateBargeProportion[f][c] * (sum(j in 1..NVarsPerOD)(\n\t                CandidateBargeAssignment[(c - 1) * fueltechnologies + f][(i - 1) * NVarsPerOD + j]))) <= numBargesCandidate[c] * CF[c];}\n\t\t                \n\tforall (l in RFRS, f in Rfueltechnologies, i in RODP, j in FlatCompoundIndex) {\n\t    FRSassignment[(l - 1) * fueltechnologies + f][j] <= disruptionFRS[l];}\n\t\n\tforall (m in RPorts, f in Rfueltechnologies, i in RODP, j in FlatCompoundIndex) {\n\t    Portassignment[(m - 1) * fueltechnologies + f][j] <= disruptionPorts[m];}\n\t\n\tforall (k in RTSA, f in Rfueltechnologies, i in RODP, j in FlatCompoundIndex) {\n\t    TSAassignment[(k - 1) * fueltechnologies + f][j] <= disruptionTSA[k];}\n\t    \t\n\tforall (i in FlatCompoundIndexTruck, j in FlatCompoundIndex, c in rnumcandidatefacilities) {\n    TSAassignment[i][j] <= 4;\n    CandidateTSAassignment[i][j] <= 4* CF[c];}\n\n\tforall (i in FlatCompoundIndexRail, j in FlatCompoundIndex, c in rnumcandidatefacilities) {\n\tFRSassignment[i][j] <= 4;\n\tCandidateRailAssignment[i][j] <= 4*CF[c];}\n\n\tforall (i in FlatCompoundIndexBarge, j in FlatCompoundIndex, c in rnumcandidatefacilities) {\n\tPortassignment[i][j] <= 4;\n\tCandidateBargeAssignment[i][j] <= 4* CF[c];}\n\t\t\n\tforall (c1 in rnumcandidatefacilities) {\n    sum(i in RODP, j in RVars) (\n        numcontainers[i] * (\n            CandidateBargeAssignment[c1][(i - 1) * NVarsPerOD + 3] +\n            CandidateBargeAssignment[c1][(i - 1) * NVarsPerOD + 4] +\n            CandidateBargeAssignment[c1][(i - 1) * NVarsPerOD + 6] +\n            CandidateBargeAssignment[c1][(i - 1) * NVarsPerOD + 7] +\n            CandidateBargeAssignment[c1][(i - 1) * NVarsPerOD + 11] +\n            CandidateRailAssignment[c1][(i - 1) * NVarsPerOD + 4] +\n            CandidateRailAssignment[c1][(i - 1) * NVarsPerOD + 5] +\n            CandidateRailAssignment[c1][(i - 1) * NVarsPerOD + 7] +\n            CandidateRailAssignment[c1][(i - 1) * NVarsPerOD + 10]\n        )\n    ) >= MinAnnualCapacity * CF[c1];\n}\n}\n'


# ---------------------------------------------------------------------------
# Faithful OPL expression and constraint translator.
# The original algebra is embedded below to avoid manually changing equations.
# OPL uses 1-based indices; the adapters below retain that convention.
# IMPORTANT: This is an experimental direct translator, NOT a validated MILP.
# Products of assignment binaries and flow variables remain quadratic.
# ---------------------------------------------------------------------------
import re
import itertools
import argparse

class OneBased:
    """Allow OPL-style a[1][2] indexing over nested Python arrays."""
    def __init__(self, value): self.value = value
    def __getitem__(self, index):
        if isinstance(self.value, dict):
            v = self.value[index]
        else:
            v = self.value[index - 1]
        return OneBased(v) if isinstance(v, (list, tuple, dict)) else v


def balanced(text, start, opening='(', closing=')'):
    assert text[start] == opening
    depth = 0
    for k in range(start, len(text)):
        if text[k] == opening: depth += 1
        elif text[k] == closing:
            depth -= 1
            if depth == 0: return text[start + 1:k], k + 1
    raise ValueError('Unbalanced OPL expression')


def split_top(text, sep=','):
    depth = 0
    result, begin = [], 0
    for k, ch in enumerate(text):
        if ch in '([': depth += 1
        elif ch in ')]': depth -= 1
        elif ch == sep and depth == 0:
            result.append(text[begin:k].strip()); begin = k + 1
    result.append(text[begin:].strip())
    return result


def compile_expression(source):
    """Convert OPL sum(...) and arithmetic to a Python expression."""
    source = re.sub(r'//[^\n]*', '', source)
    chunks = []
    cursor = 0
    while True:
        match = re.search(r'\bsum\s*\(', source[cursor:])
        if not match: chunks.append(source[cursor:]); break
        start = cursor + match.start()
        chunks.append(source[cursor:start])
        header, after = balanced(source, source.index('(', start))
        pos = after
        while pos < len(source) and source[pos].isspace(): pos += 1
        if pos >= len(source) or source[pos] != '(':
            # OPL permits an unparenthesized single-term summand.
            depth = 0
            end = pos
            while end < len(source):
                ch = source[end]
                if ch in '[(': depth += 1
                elif ch in '])': depth -= 1
                if depth == 0 and (source.startswith('==',end) or source.startswith('<=',end) or source.startswith('>=',end)):
                    break
                end += 1
            body = source[pos:end].strip()
        else:
            body, end = balanced(source, pos)
        condition = None
        if ':' in header: header, condition = header.split(':', 1)
        terms = []
        for declaration in split_top(header):
            m = re.fullmatch(r'(\w+)\s+in\s+(.+)', declaration.strip(), re.S)
            if not m: raise ValueError('Invalid sum declaration: '+declaration)
            var, domain = m.groups()
            terms.append(f'for {var} in {compile_expression(domain)}')
        filter_text = ' if ' + compile_expression(condition) if condition else ''
        chunks.append('(sum((' + compile_expression(body) + ') ' + ' '.join(terms) + filter_text + '))')
        cursor = end
    text = ''.join(chunks)
    text = re.sub(r'\b(\d+)\s*\.\.\s*(\w+)\b', r'range(\1, \2+1)', text)
    text = re.sub(r'\bmod\b', '%', text)
    text = re.sub(r'\bdiv\b', '//', text)
    text = re.sub(r'(?<![<>=!])==(?![=])', '==', text)
    return " ".join(text.split())


def remove_comments(s):
    return re.sub(r'//[^\n]*', '', s)


def extract_objectives(text):
    cleaned = remove_comments(text)
    matches = list(re.finditer(r'\bdexpr\s+float\s+(\w+)\s*=', cleaned))
    result = []
    for match in matches:
        expression = cleaned[match.end():cleaned.index(';', match.end())]
        if match.group(1) == 'CandidateFacilityCosts':
            expression = re.sub(r'(sum\(c in rnumcandidatefacilities\))\s*(CF\[c\] \* AnnualCost)', r'\1 (\2)', expression)
        result.append((match.group(1), expression.strip()))
    return result


def walk_constraints(text):
    """Yield (active forall declarations, constraint) from nested OPL blocks."""
    start = text.index('subject to')
    cleaned = remove_comments(text[start:])
    cleaned = cleaned[cleaned.index('{')+1:]
    def visit(s, context):
        cursor = 0
        while cursor < len(s):
            while cursor < len(s) and s[cursor].isspace(): cursor += 1
            if cursor >= len(s): break
            if s.startswith('forall', cursor):
                header_start = s.index('(', cursor)
                header, after = balanced(s, header_start)
                body_start = s.index('{', after)
                body, end = balanced(s, body_start, '{', '}')
                yield from visit(body, context + [header]); cursor = end
            elif s[cursor] == '}': cursor += 1
            else:
                semi = s.find(';', cursor)
                if semi == -1: break
                statement = s[cursor:semi].strip()
                if statement: yield context, statement
                cursor = semi + 1
    yield from visit(cleaned, [])


def create_environment(data, variables, model):
    # All indices in the source remain 1-based, including flattened indices.
    env = {name: OneBased(value) if isinstance(value, list) else value
           for name, value in data.items()}
    env.update({name: OneBased(value) for name, value in variables.items()})
    env.update(dict(NODpairs=N_OD, NVarsPerOD=N_ROUTE, NTSA=N_TSA,
        NFRS=N_FRS, NPorts=N_PORT, fueltechnologies=N_FUEL,
        numcandidatefacilities=N_CANDIDATE, U_w=FLOW_UPPER_BOUND,
        L_w=0, U_y=1, L_y=0, LongDistancePenalty=LONG_DISTANCE_PENALTY))
    for name, n in [('RODP',N_OD),('RVars',N_ROUTE),('RTSA',N_TSA),
                    ('RFRS',N_FRS),('RPorts',N_PORT),('Rfueltechnologies',N_FUEL),
                    ('rnumcandidatefacilities',N_CANDIDATE),
                    ('FlatCompoundIndex',N_OD*N_ROUTE),
                    ('FlatCompoundIndexTruck',N_TSA*N_FUEL),
                    ('FlatCompoundIndexRail',N_FRS*N_FUEL),
                    ('FlatCompoundIndexBarge',N_PORT*N_FUEL),
                    ('FlatCompoundIndexCandidateRail',N_CANDIDATE*N_FUEL),
                    ('FlatCompoundIndexCandidateBarge',N_CANDIDATE*N_FUEL)]:
        env[name] = range(1, n+1)
    for j in range(1, N_ROUTE+1): env[f'index{j}'] = j
    env['sum'] = model.sum
    return env


def build_variables(model):
    def grid(name, nrows, ncols, binary=True):
        factory = model.binary_var if binary else model.continuous_var
        return {i:{j:factory(name=f'{name}_{i}_{j}', **({} if binary else {'lb':0}))
                   for j in range(1,ncols+1)} for i in range(1,nrows+1)}
    v = {name:grid(name,N_OD,N_ROUTE,name not in ('w','z','wcandidate'))
         for name in ('y','w','z','ycandidate','wcandidate')}
    for name, count in [('TSAassignment',N_TSA),('FRSassignment',N_FRS),
                        ('Portassignment',N_PORT),('CandidateTSAassignment',N_TSA),
                        ('CandidateRailAssignment',N_CANDIDATE),
                        ('CandidateBargeAssignment',N_CANDIDATE)]:
        v[name] = grid(name,count*N_FUEL,N_OD*N_ROUTE)
    v['CF'] = {i:model.binary_var(name=f'CF_{i}') for i in range(1,N_CANDIDATE+1)}
    return v


def apply_objective(model, env):
    components = {}
    for name, expression in extract_objectives(ORIGINAL_OPL):
        compiled = compile_expression(expression)
        try: components[name] = eval(compiled, env | {'__builtins__': {}})
        except Exception as exc: raise RuntimeError(f'Objective component {name}: {exc}') from exc
        env[name] = components[name]
        print('Constructed objective component:', name, flush=True)
    model.minimize(components['OF'])
    return components


def expand_declarations(declarations, env):
    # Generate all combinations of forall indices, retaining source semantics.
    local_contexts = [dict()]
    for header in declarations:
        new_contexts = []
        for decl in split_top(header):
            m = re.fullmatch(r'(\w+)\s+in\s+(.+)', decl, re.S)
            if not m: raise ValueError('Unsupported forall index: '+decl)
            variable, domain = m.groups()
            for context in local_contexts:
                for index in eval(compile_expression(domain), env | context | {'__builtins__':{}}):
                    new_contexts.append(context | {variable:index})
            local_contexts = new_contexts; new_contexts = []
    return local_contexts


def apply_constraints(model, env):
    total = 0
    for declarations, statement in walk_constraints(ORIGINAL_OPL):
        # The source uses both == and >= / <= for its constraints.
        expr = compile_expression(statement)
        for local in expand_declarations(declarations, env):
            try:
                constraint = eval(expr, env | local | {'__builtins__':{}})
                model.add_constraint(constraint)
            except Exception as exc:
                raise RuntimeError(f'Constraint {statement[:120]!r} at {local}: {exc}') from exc
            total += 1
    return total


def run(workbook, solve=False, time_limit=None, weights=None):
    try:
        from docplex.mp.model import Model
    except ImportError as exc:
        raise SystemExit('Install docplex and IBM CPLEX before constructing the model') from exc
    data = load_inputs(workbook, weights=weights)
    with Model(name='lower_mississippi_faithful_opl_translation') as model:
        model.context.cplex_parameters.threads = 20  # Original OPL: 20 threads.
        model.context.cplex_parameters.workmem = 30000  # Original: 30000 MB (not 50 GB).
        model.context.cplex_parameters.preprocessing.presolve = 1
        if time_limit: model.set_time_limit(time_limit)
        variables = build_variables(model)
        env = create_environment(data, variables, model)
        components = apply_objective(model, env)
        print('Added constraints:', apply_constraints(model, env))
        if not solve:
            print('Model constructed; not solved. Use --solve to attempt optimization.')
            return
        solution = model.solve(log_output=True)
        if solution is None:
            print('No solution returned. Review the formulation and solver log.')
            return
        print('Objective:', solution.objective_value)
        for name, expr in components.items():
            try: print(name, expr.solution_value)
            except Exception: pass
        # Deliberately do not overwrite the original workbook automatically.
        # Users should validate the translated model before exporting results.


def main():
    parser = argparse.ArgumentParser(description='Experimental faithful OPL to Python model')
    parser.add_argument('--workbook', type=Path, default=WORKBOOK)
    parser.add_argument('--solve', action='store_true')
    parser.add_argument('--time-limit', type=float, default=None)
    parser.add_argument('--check-source', action='store_true',
                        help='Parse and syntax-check source expressions without CPLEX')
    parser.add_argument('--weight-costs', type=float)
    parser.add_argument('--weight-emissions', type=float)
    parser.add_argument('--weight-time', type=float)
    args = parser.parse_args()
    if args.check_source:
        objs = extract_objectives(ORIGINAL_OPL)
        constraints = list(walk_constraints(ORIGINAL_OPL))
        for name, expr in objs: compile(compile_expression(expr), '<objective '+name+'>', 'eval')
        for decls, expr in constraints:
            compile(compile_expression(expr), '<constraint>', 'eval')
            for header in decls:
                for d in split_top(header):
                    m = re.fullmatch(r'(\w+)\s+in\s+(.+)', d, re.S)
                    if not m: raise ValueError(d)
                    compile(compile_expression(m.group(2)), '<range>', 'eval')
        print(f'Source parsed: {len(objs)} objective components and {len(constraints)} constraint templates.')
        return
    run(args.workbook, solve=args.solve, time_limit=args.time_limit, weights={k:v for k,v in [('weightcosts',args.weight_costs),('weightemissions',args.weight_emissions),('weighttime',args.weight_time)] if v is not None})

if __name__ == '__main__': main()
